// Cliente mínimo da API do Mercado Pago (Pix), sem dependências externas.
// Documentação: https://www.mercadopago.com.br/developers/pt/reference/payments/_payments/post
import crypto from 'node:crypto';
import { config } from '../config.js';
import { mpAccessToken, mpWebhookSecret } from './settings.js';
import { HttpError } from '../http.js';

async function call(method, path, body, { idempotencyKey, token } = {}) {
  const accessToken = token || (await mpAccessToken());
  if (!accessToken) throw new HttpError(503, 'Pagamento via Pix indisponível: o estúdio ainda não configurou o Mercado Pago.');
  const headers = { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' };
  if (idempotencyKey) headers['X-Idempotency-Key'] = idempotencyKey;
  let res;
  try {
    res = await fetch(`${config.mpApiBase}${path}`, {
      method, headers, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000),
    });
  } catch (e) {
    throw new HttpError(502, 'Não foi possível falar com o Mercado Pago agora. Tente novamente em instantes.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.message || data?.error || `HTTP ${res.status}`;
    const err = new HttpError(res.status === 401 ? 502 : 502, `Mercado Pago recusou a operação: ${msg}`);
    err.provider = data;
    err.providerStatus = res.status;
    throw err;
  }
  return data;
}

export async function createPixPayment({ amountCents, description, payerEmail, payerName, externalReference, expiresAt, idempotencyKey }) {
  const body = {
    transaction_amount: Number((amountCents / 100).toFixed(2)),
    description: description.slice(0, 250),
    payment_method_id: 'pix',
    external_reference: externalReference,
    date_of_expiration: toMpDate(expiresAt),
    payer: { email: payerEmail, first_name: (payerName || '').split(/\s+/)[0] || 'Cliente' },
  };
  // O Mercado Pago exige HTTPS público no notification_url; em ambiente local o webhook é omitido.
  if (config.appUrl.startsWith('https://')) body.notification_url = `${config.appUrl}/api/webhooks/mercadopago`;
  return call('POST', '/v1/payments', body, { idempotencyKey });
}

export const getPayment = (id) => call('GET', `/v1/payments/${encodeURIComponent(id)}`);
export const cancelPayment = (id) => call('PUT', `/v1/payments/${encodeURIComponent(id)}`, { status: 'cancelled' });
export async function testCredentials(token) {
  const me = await call('GET', '/users/me', null, { token });
  return me?.nickname || me?.email || String(me?.id || 'desconhecida');
}

function toMpDate(iso) {
  // Formato aceito: yyyy-MM-dd'T'HH:mm:ss.SSSZ com offset (ex.: -03:00)
  const d = new Date(iso);
  const pad = (n, l = 2) => String(n).padStart(l, '0');
  const t = new Date(d.getTime() - 3 * 3600000);
  return `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}T${pad(t.getUTCHours())}:${pad(t.getUTCMinutes())}:${pad(t.getUTCSeconds())}.${pad(t.getUTCMilliseconds(), 3)}-03:00`;
}

export function pixData(mp) {
  const td = mp?.point_of_interaction?.transaction_data || {};
  return { qrCode: td.qr_code || null, qrCodeBase64: td.qr_code_base64 || null, ticketUrl: td.ticket_url || null };
}

/**
 * Validação da assinatura do webhook (cabeçalho x-signature: "ts=...,v1=...").
 * Manifesto: id:<data.id>;request-id:<x-request-id>;ts:<ts>;
 * Retorna: true (válida), false (inválida), null (segredo não configurado).
 */
export async function verifyWebhookSignature(headers, dataId) {
  const secret = await mpWebhookSecret();
  if (!secret) return null;
  const sig = String(headers['x-signature'] || '');
  const reqId = String(headers['x-request-id'] || '');
  const parts = Object.fromEntries(sig.split(',').map((p) => p.trim().split('=')));
  if (!parts.ts || !parts.v1) return false;
  const id = /^[a-z0-9]+$/i.test(String(dataId)) ? String(dataId).toLowerCase() : String(dataId);
  let manifest = `id:${id};`;
  if (reqId) manifest += `request-id:${reqId};`;
  manifest += `ts:${parts.ts};`;
  const expected = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(parts.v1));
  } catch {
    return false;
  }
}
