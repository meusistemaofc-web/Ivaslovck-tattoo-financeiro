-- Cobranças Pix genéricas (cartão presente e, depois, parcelas, upgrades e taxas) e Cartão Presente.
CREATE TABLE gift_cards (
  id BIGSERIAL PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  token TEXT NOT NULL UNIQUE,
  buyer_id BIGINT NOT NULL REFERENCES users(id),
  recipient_id BIGINT REFERENCES users(id),
  recipient_name TEXT NOT NULL,
  sender_name TEXT NOT NULL,
  message TEXT NOT NULL DEFAULT '',
  model_key TEXT NOT NULL,
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  delivery TEXT NOT NULL DEFAULT 'now' CHECK (delivery IN ('now','later')),
  status TEXT NOT NULL DEFAULT 'awaiting_payment' CHECK (status IN ('awaiting_payment','paid','redeemed','expired','cancelled')),
  idempotency_key TEXT NOT NULL,
  expires_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  redeemed_at TIMESTAMPTZ,
  ledger_id BIGINT REFERENCES wallet_ledger(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (buyer_id, idempotency_key)
);
CREATE INDEX idx_gift_cards_buyer ON gift_cards(buyer_id);
CREATE INDEX idx_gift_cards_recipient ON gift_cards(recipient_id);

CREATE TABLE gift_events (
  id BIGSERIAL PRIMARY KEY,
  card_id BIGINT REFERENCES gift_cards(id),
  kind TEXT NOT NULL,
  actor_id BIGINT REFERENCES users(id),
  detail TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE charges (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL CHECK (kind IN ('gift_card','installment','upgrade_fee','card_fee')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','expired','cancelled','failed')),
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  gift_card_id BIGINT REFERENCES gift_cards(id),
  installment_id BIGINT,
  upgrade_request_id BIGINT,
  card_request_id BIGINT,
  provider_payment_id TEXT UNIQUE,
  idempotency_key TEXT NOT NULL,
  qr_code TEXT,
  qr_code_base64 TEXT,
  ticket_url TEXT,
  expires_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  provider_status TEXT,
  provider_amount_cents BIGINT,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, idempotency_key)
);
CREATE INDEX idx_charges_user ON charges(user_id);
CREATE INDEX idx_charges_status ON charges(status);
