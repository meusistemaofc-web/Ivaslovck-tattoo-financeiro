// Verifica se os saldos armazenados conferem com os livros-razão. Não altera nada.
// Uso: npm run integrity   (na VPS: docker compose exec app npm run integrity)
import { initDb, db, closeDb } from '../src/db.js';
import { reconcileWallets } from '../src/services/wallet.js';
import { supply } from '../src/services/coins.js';

await initDb();
const w = await reconcileWallets(db());
const c = await db().query(`SELECT w.user_id, w.balance, COALESCE(SUM(l.amount),0) AS ledger FROM coin_wallets w LEFT JOIN coin_ledger l ON l.user_id=w.user_id GROUP BY w.user_id, w.balance HAVING w.balance <> COALESCE(SUM(l.amount),0)`);
const s = await db().query(`SELECT s.id, s.paid_cents, COALESCE(SUM(p.amount_cents),0) AS approved FROM subscriptions s LEFT JOIN payments p ON p.subscription_id=s.id AND p.status='approved' GROUP BY s.id, s.paid_cents HAVING s.paid_cents <> COALESCE(SUM(p.amount_cents),0)`);
const sup = await supply();
console.log(JSON.stringify({ carteirasDivergentes: w, moedasDivergentes: c, planosDivergentes: s, ivtCoinConsistente: sup.consistent }, null, 2));
const ok = !w.length && !c.length && !s.length && sup.consistent;
console.log(ok ? 'OK: saldos conferem com o histórico.' : 'ATENÇÃO: divergências encontradas. Documente antes de qualquer correção (use ajustes auditáveis, nunca exclusões).');
await closeDb();
process.exit(ok ? 0 : 2);
