/*
 * Service Worker da IVASLOVCK Tattoo Club.
 * - Páginas (navegação): rede primeiro, com o index.html em cache como fallback offline.
 * - /assets/* (arquivos com hash do Vite): cache primeiro — o nome muda a cada versão.
 * - Ícones, manifest e fontes: stale-while-revalidate.
 * - /api/* e outros domínios (exceto Google Fonts): nunca são interceptados.
 * Ao publicar uma nova versão, o navegador detecta o sw.js alterado (servido sem cache),
 * a nova versão assume, remove os caches antigos e o app recarrega na próxima troca de tela.
 */
// Substituído a cada build (vite.config.ts), garantindo que cada publicação gere um novo Service Worker.
const VERSION = "mvz3f1j6";
const STATIC_CACHE = `ivaslovck-static-${VERSION}`;
const RUNTIME_CACHE = `ivaslovck-runtime-${VERSION}`;
// Arquivos da marca ficam em /brand/<versão>/: uma nova versão da logo usa endereços novos e nunca reaproveita o cache antigo.
const BRAND = "/brand/v3";
const PRECACHE = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/favicon.svg",
  `${BRAND}/icon-192.png`,
  `${BRAND}/icon-512.png`,
  `${BRAND}/apple-touch-icon.png`,
  `${BRAND}/logo-720.webp`,
  `${BRAND}/ivaslovck-club-tipografica.webp`,
  `${BRAND}/ivaslovck-club-horizontal.webp`,
  `${BRAND}/marble-texture.webp`,
  `${BRAND}/marble-corner-tl.webp`,
  `${BRAND}/marble-corner-br.webp`,
  `${BRAND}/notification-icon.png`,
  `${BRAND}/notification-badge.png`,
];
const FONT_HOSTS = ["fonts.googleapis.com", "fonts.gstatic.com"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE.map((url) => new Request(url, { cache: "reload" }))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k.startsWith("ivaslovck-") && k !== STATIC_CACHE && k !== RUNTIME_CACHE).map((k) => caches.delete(k)),
      ))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  if (url.origin !== self.location.origin) {
    if (FONT_HOSTS.includes(url.hostname)) event.respondWith(staleWhileRevalidate(req));
    return;
  }
  if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/.netlify/") || url.pathname === "/sw.js") return;

  if (req.mode === "navigate") {
    event.respondWith(networkFirstPage(req));
    return;
  }
  if (url.pathname.startsWith("/assets/")) {
    event.respondWith(cacheFirst(req));
    return;
  }
  if (/\.(png|jpe?g|webp|svg|ico|webmanifest|woff2?)$/.test(url.pathname)) {
    event.respondWith(staleWhileRevalidate(req));
  }
});

async function networkFirstPage(req) {
  const cache = await caches.open(STATIC_CACHE);
  try {
    const res = await fetch(req, { cache: "no-store" });
    if (res.ok && res.type === "basic") cache.put("/index.html", res.clone());
    return res;
  } catch {
    return (await cache.match("/index.html")) || (await cache.match("/")) || Response.error();
  }
}

async function cacheFirst(req) {
  const cache = await caches.open(RUNTIME_CACHE);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  // Nunca guardar o fallback HTML do SPA no lugar de um JS/CSS inexistente.
  if (res.ok && !(res.headers.get("content-type") || "").includes("text/html")) cache.put(req, res.clone());
  return res;
}

async function staleWhileRevalidate(req) {
  const cache = await caches.open(RUNTIME_CACHE);
  const hit = await cache.match(req);
  const network = fetch(req)
    .then((res) => {
      if (res.ok || res.type === "opaque") cache.put(req, res.clone());
      return res;
    })
    .catch(() => hit);
  return hit || network;
}

/* ---------------------------------------------------------------- Notificações push */
// O conteúdo chega cifrado pelo serviço de push do navegador (Web Push + VAPID) e é exibido mesmo com o app fechado.
self.addEventListener("push", (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { title: "IVASLOVCK", body: event.data ? event.data.text() : "" }; }
  const title = data.title || "IVASLOVCK";
  const options = {
    body: data.body || "",
    // Logo oficial (ícone) e letreiro branco transparente (badge da barra de status do Android).
    icon: sameOrigin(data.icon) || `${BRAND}/notification-icon.png`,
    badge: sameOrigin(data.badge) || `${BRAND}/notification-badge.png`,
    image: sameOrigin(data.image) || undefined,
    tag: data.tag || undefined,
    renotify: Boolean(data.tag),
    requireInteraction: Boolean(data.urgent),
    lang: "pt-BR",
    timestamp: data.ts || Date.now(),
    data: { url: data.url || "/inicio", id: data.id || null, token: data.token || null },
  };
  event.waitUntil(Promise.all([
    self.registration.showNotification(title, options),
    // Contador no ícone do app (quando suportado) e atualização imediata do sino nas janelas abertas.
    typeof data.unread === "number" && self.navigator.setAppBadge ? self.navigator.setAppBadge(data.unread).catch(() => {}) : null,
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((ws) => ws.forEach((w) => w.postMessage({ type: "ivs-notification" }))),
    // Confirmação de entrega ao aparelho (métrica de entrega real).
    data.id ? fetch("/api/push/events", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: data.id, token: data.token, kind: "delivered" }), keepalive: true }).catch(() => {}) : null,
  ]));
});

/** Aceita apenas imagens do próprio app (caminho relativo), nunca endereços externos. */
function sameOrigin(path) {
  return typeof path === "string" && path.startsWith("/") && !path.startsWith("//") ? path : null;
}

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const d = event.notification.data || {};
  const target = new URL(d.url || "/inicio", self.location.origin);
  if (target.origin !== self.location.origin) target.href = new URL("/inicio", self.location.origin).href;
  event.waitUntil((async () => {
    if (d.id) {
      fetch("/api/push/events", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: d.id, token: d.token, kind: "clicked" }), keepalive: true }).catch(() => {});
    }
    const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const w of windows) {
      if (new URL(w.url).origin === self.location.origin && "focus" in w) {
        await w.focus();
        if ("navigate" in w) return w.navigate(target.href).catch(() => self.clients.openWindow(target.href));
        return;
      }
    }
    return self.clients.openWindow(target.href);
  })());
});

// O navegador trocou a assinatura (expirada ou renovada): registra a nova automaticamente.
self.addEventListener("pushsubscriptionchange", (event) => {
  event.waitUntil((async () => {
    try {
      const res = await fetch("/api/push/vapid");
      const { publicKey } = await res.json();
      const b64 = publicKey.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (publicKey.length % 4)) % 4);
      const key = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      const sub = event.newSubscription || (await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key }));
      await fetch("/api/push/resubscribe", {
        method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ old: event.oldSubscription ? event.oldSubscription.endpoint : null, subscription: sub.toJSON() }),
      });
    } catch { /* o app registra novamente na próxima abertura */ }
  })());
});
