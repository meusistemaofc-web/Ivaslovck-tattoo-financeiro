// Cobranças de resgate: o estúdio gera, o cliente autoriza (app ou código), o saldo é debitado atomicamente.
import crypto from 'node:crypto';
import { db } from '../db.js';
import { bad, conflict, notFound } from '../http.js';
import { getSetting, audit, notify } from './settings.js';
import * as wallet from './wallet.js';

const now = () => new Date().toISOString();
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const genCode = () => Array.from(crypto.randomBytes(8), (b) => ALPHABET[b % ALPHABET.length]).join('');

export function redemptionView(r, extra = {}) {
  return {
    id: r.id, userId: r.user_id, amountCents: r.amount_cents, description: r.description, attendance: r.attendance,
    code: r.code, status: r.status, expiresAt: r.expires_at, createdAt: r.created_at, createdByName: r.created_by_name,
    confirmedAt: r.confirmed_at, confirmedVia: r.confirmed_via, cardId: r.card_id, ...extra,
  };
}

export async function expireRedemptions(q = db()) {
  await q.query(`UPDATE redemptions SET status='expired', closed_at=$1 WHERE status='pending' AND expires_at < $1`, [now()]);
}

export async function reservedCents(q, userId, exceptId = null) {
  const r = await q.query(
    `SELECT COALESCE(SUM(amount_cents),0) AS c FROM redemptions WHERE user_id=$1 AND status='pending' AND expires_at > $2 AND id <> $3`,
    [userId, now(), exceptId || 0],
  );
  return Number(r[0].c);
}

export async function createRedemption(admin, userId, { amountCents, description }) {
  amountCents = Number(amountCents);
  if (!Number.isInteger(amountCents) || amountCents <= 0) throw bad('Informe o valor a descontar.');
  if (!description || !String(description).trim()) throw bad('Informe a identificação do atendimento.');
  const minutes = Number(await getSetting('redemptionExpirationMinutes')) || 30;
  return db().tx(async (t) => {
    await expireRedemptions(t);
    const user = (await t.query(`SELECT * FROM users WHERE id=$1 AND role='client'`, [userId]))[0];
    if (!user) throw notFound('Cliente não encontrado.');
    const w = await wallet.lockWallet(t, userId);
    const reserved = await reservedCents(t, userId);
    if (w.balance_cents - reserved < amountCents) throw conflict('Saldo disponível insuficiente para esta cobrança.');
    const ts = now();
    const rows = await t.query(
      `INSERT INTO redemptions (user_id, amount_cents, description, attendance, code, status, expires_at, created_by, created_by_name, created_at)
       VALUES ($1,$2,$3,$4,$5,'pending',$6,$7,$8,$9) RETURNING *`,
      [userId, amountCents, String(description).trim().slice(0, 200), 'Atendimento no estúdio', genCode(),
        new Date(Date.now() + minutes * 60000).toISOString(), admin.id, admin.name, ts],
    );
    await audit(t, 'redemption_created', `Cobrança de resgate: ${rows[0].description}`, { userId, actorId: admin.id, amountCents });
    await notify(t, userId, 'Cobrança de resgate aguardando você', rows[0].description, '/creditos', 'redemption');
    return rows[0];
  });
}

/** Confirma (debita). via: 'client_app' | 'admin_code'. Idempotente por redemption id. */
export async function confirmRedemption({ id, actor, via, code, userId = null, cardId = null }) {
  return db().tx(async (t) => {
    const r = (await t.query('SELECT * FROM redemptions WHERE id=$1 FOR UPDATE', [id]))[0];
    if (!r || (userId && r.user_id !== userId)) throw notFound('Cobrança não encontrada.');
    if (r.status === 'confirmed') return r;
    if (r.status !== 'pending') throw conflict('Esta cobrança não está mais disponível.');
    if (new Date(r.expires_at) < new Date()) {
      await t.query(`UPDATE redemptions SET status='expired', closed_at=$1 WHERE id=$2`, [now(), id]);
      throw conflict('Esta cobrança expirou. Gere uma nova.');
    }
    if (via === 'admin_code' && String(code || '').toUpperCase() !== r.code) throw bad('Código de autorização incorreto.');
    if (cardId) {
      const c = (await t.query(`SELECT * FROM cards WHERE id=$1 AND user_id=$2`, [cardId, r.user_id]))[0];
      if (!c || c.status !== 'active' || (c.expires_on && c.expires_on < now().slice(0, 10))) throw conflict('Cartão indisponível para pagamento.');
    }
    const reservedOther = await reservedCents(t, r.user_id, r.id);
    const d = await wallet.debit(t, {
      userId: r.user_id, amountCents: r.amount_cents, kind: 'redemption', refType: 'redemption', refId: r.id,
      key: `redemption:${r.id}`, description: r.description, actorId: actor.id, reservedOtherCents: reservedOther,
    });
    const ts = now();
    await t.query(`UPDATE redemptions SET status='confirmed', confirmed_at=$1, confirmed_via=$2, card_id=$3, ledger_id=$4, closed_at=$1 WHERE id=$5`,
      [ts, via, cardId, d.entries[0].id, id]);
    await audit(t, 'redemption_confirmed', `Utilização de crédito confirmada: ${r.description}`, { userId: r.user_id, actorId: actor.id, amountCents: r.amount_cents, meta: { via, cardId } });
    return (await t.query('SELECT * FROM redemptions WHERE id=$1', [id]))[0];
  });
}

export async function closeRedemption({ id, actor, status, userId = null }) {
  return db().tx(async (t) => {
    const r = (await t.query('SELECT * FROM redemptions WHERE id=$1 FOR UPDATE', [id]))[0];
    if (!r || (userId && r.user_id !== userId)) throw notFound('Cobrança não encontrada.');
    if (r.status !== 'pending') throw conflict('Esta cobrança não está mais pendente.');
    await t.query('UPDATE redemptions SET status=$1, closed_at=$2 WHERE id=$3', [status, now(), id]);
    await audit(t, status === 'declined' ? 'redemption_declined' : 'redemption_cancelled', `Cobrança de resgate ${status === 'declined' ? 'recusada pelo cliente' : 'cancelada'}: ${r.description}`, { userId: r.user_id, actorId: actor.id, amountCents: r.amount_cents });
  });
}
