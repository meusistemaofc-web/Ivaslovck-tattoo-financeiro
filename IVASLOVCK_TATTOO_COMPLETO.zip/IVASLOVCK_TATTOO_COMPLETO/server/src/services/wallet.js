// Carteira em REAIS. Toda alteração de saldo passa por aqui, dentro de uma transação do banco.
// Regras: livro-razão imutável, chave de idempotência única, bloqueio da linha da carteira (FOR UPDATE),
// saldo nunca negativo (validação + CHECK no banco), débitos consomem Cartão Presente -> conversões -> planos.
import { HttpError } from '../http.js';

const BUCKET_COL = { plan: 'plan_cents', gift: 'gift_cents', conversion: 'conversion_cents' };
const DEBIT_ORDER = ['gift', 'conversion', 'plan'];

export async function lockWallet(t, userId) {
  await t.query('INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING', [userId]);
  const rows = await t.query('SELECT * FROM wallets WHERE user_id = $1 FOR UPDATE', [userId]);
  return rows[0];
}

export async function getWallet(q, userId) {
  const rows = await q.query('SELECT * FROM wallets WHERE user_id = $1', [userId]);
  return rows[0] || { user_id: userId, balance_cents: 0, plan_cents: 0, gift_cents: 0, conversion_cents: 0 };
}

async function existing(t, key) {
  const rows = await t.query('SELECT * FROM wallet_ledger WHERE idempotency_key = $1', [key]);
  return rows.length ? rows : null;
}

async function insertEntry(t, w, { userId, amount, bucket, kind, refType, refId, key, description, actorId }) {
  w[BUCKET_COL[bucket]] += amount;
  w.balance_cents += amount;
  if (w[BUCKET_COL[bucket]] < 0 || w.balance_cents < 0) throw new HttpError(409, 'Saldo insuficiente.');
  const rows = await t.query(
    `INSERT INTO wallet_ledger (user_id, amount_cents, bucket, kind, ref_type, ref_id, idempotency_key, balance_after, description, created_by, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [userId, amount, bucket, kind, refType, refId == null ? null : String(refId), key, w.balance_cents, description || null, actorId || null, new Date().toISOString()],
  );
  return rows[0];
}

async function saveWallet(t, w) {
  await t.query(
    'UPDATE wallets SET balance_cents=$1, plan_cents=$2, gift_cents=$3, conversion_cents=$4, updated_at=$5 WHERE user_id=$6',
    [w.balance_cents, w.plan_cents, w.gift_cents, w.conversion_cents, new Date().toISOString(), w.user_id],
  );
}

/** Crédito (valor positivo) em um balde. Idempotente pela chave. */
export async function credit(t, { userId, amountCents, bucket = 'plan', kind, refType, refId, key, description, actorId }) {
  if (!Number.isInteger(amountCents) || amountCents <= 0) throw new HttpError(400, 'Valor inválido.');
  if (!key) throw new Error('idempotency key obrigatória');
  const dup = await existing(t, key);
  if (dup) return { entries: dup, duplicate: true };
  const w = await lockWallet(t, userId);
  const e = await insertEntry(t, w, { userId, amount: amountCents, bucket, kind, refType, refId, key, description, actorId });
  await saveWallet(t, w);
  return { entries: [e], duplicate: false, wallet: w };
}

/** Débito: consome os baldes na ordem definida. Falha inteira se o saldo não cobrir. */
export async function debit(t, { userId, amountCents, kind, refType, refId, key, description, actorId, reservedOtherCents = 0 }) {
  if (!Number.isInteger(amountCents) || amountCents <= 0) throw new HttpError(400, 'Valor inválido.');
  if (!key) throw new Error('idempotency key obrigatória');
  const dup = await existing(t, `${key}:1`) || await existing(t, key);
  if (dup) return { entries: dup, duplicate: true };
  const w = await lockWallet(t, userId);
  if (w.balance_cents - reservedOtherCents < amountCents) throw new HttpError(409, 'Saldo insuficiente para esta operação.');
  let left = amountCents;
  const entries = [];
  let n = 0;
  for (const b of DEBIT_ORDER) {
    const avail = w[BUCKET_COL[b]];
    if (left <= 0 || avail <= 0) continue;
    const take = Math.min(avail, left);
    n += 1;
    entries.push(await insertEntry(t, w, { userId, amount: -take, bucket: b, kind, refType, refId, key: `${key}:${n}`, description, actorId }));
    left -= take;
  }
  if (left !== 0) throw new HttpError(409, 'Saldo insuficiente para esta operação.');
  await saveWallet(t, w);
  return { entries, duplicate: false, wallet: w };
}

/** Verifica se o saldo armazenado bate com a soma do livro-razão (auditoria). */
export async function reconcileWallets(q) {
  return q.query(`
    SELECT w.user_id, w.balance_cents, COALESCE(l.total,0) AS ledger_total,
           w.plan_cents, COALESCE(l.plan,0) AS ledger_plan,
           w.gift_cents, COALESCE(l.gift,0) AS ledger_gift,
           w.conversion_cents, COALESCE(l.conv,0) AS ledger_conversion
    FROM wallets w
    LEFT JOIN (
      SELECT user_id, SUM(amount_cents) AS total,
        SUM(CASE WHEN bucket='plan' THEN amount_cents ELSE 0 END) AS plan,
        SUM(CASE WHEN bucket='gift' THEN amount_cents ELSE 0 END) AS gift,
        SUM(CASE WHEN bucket='conversion' THEN amount_cents ELSE 0 END) AS conv
      FROM wallet_ledger GROUP BY user_id) l ON l.user_id = w.user_id
    WHERE w.balance_cents <> COALESCE(l.total,0) OR w.plan_cents <> COALESCE(l.plan,0)
       OR w.gift_cents <> COALESCE(l.gift,0) OR w.conversion_cents <> COALESCE(l.conv,0)`);
}
