import { db } from '../db.js';
import { HttpError } from '../http.js';
import { getSetting } from '../services/settings.js';
import * as subs from '../services/subscriptions.js';
import * as mp from '../services/mercadopago.js';

// Módulos do frontend original cujo backend NÃO foi recuperado nem reconstruído nesta etapa.
// Respondem 501 com mensagem clara (nunca dados inventados).
export const NOT_RECONSTRUCTED = {
  '/api/market': 'Marketplace', '/api/market-promo': 'Promoções do marketplace', '/api/raffles': 'Sorteios',
  '/api/referrals': 'Indicações', '/api/rewards': 'Campanhas de recompensa', '/api/push': 'Notificações push',
  '/api/support': 'Atendimento/suporte', '/api/identity': 'Cadastro de identidade', '/api/trust': 'Limite de confiança',
  '/api/credit': 'Parcelamento com limite de confiança', '/api/gifts': 'Cartão Presente', '/api/pay': 'IVT PAY (transferências)',
  '/api/payoff': 'Quitação Especial', '/api/early-release': 'Liberação Antecipada', '/api/upgrades': 'Upgrade de plano',
  '/api/landing': 'Landing pages/campanhas', '/api/late-fees': 'Multas e juros', '/api/policies': 'Políticas (versões e aceites)',
  '/api/channels': 'Canais de contato', '/api/share-message': 'Mensagem de divulgação', '/api/coins': 'IVT COIN (recursos avançados)',
  '/api/avatars/admin': 'Galeria de avatares (admin)', '/api/admin-notifications/settings': 'Preferências de notificação',
};

export default function register(r) {
  // Webhook do Mercado Pago. Nunca confia no corpo: sempre consulta o pagamento na API antes de aplicar.
  r.post('/api/webhooks/mercadopago', async (req) => {
    const q = req.query;
    const type = req.body?.type || q.get('type') || q.get('topic');
    const id = req.body?.data?.id || q.get('data.id') || q.get('id');
    if (!id || (type && type !== 'payment')) return { ok: true, ignored: true };
    const sig = await mp.verifyWebhookSignature(req.headers, id);
    const key = `mp:${id}:${req.body?.action || type || 'payment'}:${req.headers['x-request-id'] || req.headers['x-signature'] || Date.now()}`;
    await db().query(
      'INSERT INTO webhook_events (provider, event_key, resource_id, payload, signature_valid, received_at) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (event_key) DO NOTHING',
      ['mercadopago', key, String(id), JSON.stringify(req.body || {}).slice(0, 10000), sig, new Date().toISOString()],
    );
    if (sig === false) throw new HttpError(401, 'Assinatura inválida.');
    let result;
    try {
      result = await subs.syncPaymentFromProvider(String(id), { source: 'webhook' });
    } catch (e) {
      await db().query('UPDATE webhook_events SET result=$1 WHERE event_key=$2', [`erro: ${e.message}`.slice(0, 500), key]);
      throw new HttpError(500, 'Falha ao processar; o Mercado Pago tentará novamente.');
    }
    await db().query('UPDATE webhook_events SET processed_at=$1, result=$2 WHERE event_key=$3', [new Date().toISOString(), JSON.stringify(result).slice(0, 500), key]);
    return { ok: true };
  });

  // Informações públicas usadas pelo app
  r.get('/api/health', async () => {
    await db().query('SELECT 1 AS ok');
    return { ok: true, db: db().kind, time: new Date().toISOString() };
  });
  r.get('/api/public/support', async () => ({ whatsapp: (await getSetting('supportWhatsapp')) || '' }));
}

export function notReconstructed(pathname) {
  const prefix = Object.keys(NOT_RECONSTRUCTED).sort((a, b) => b.length - a.length).find((p) => pathname === p || pathname.startsWith(p + '/') || pathname.startsWith(p + '?'));
  const name = prefix ? NOT_RECONSTRUCTED[prefix] : null;
  return new HttpError(501, name
    ? `O módulo "${name}" ainda não foi reconstruído no servidor próprio.`
    : 'Recurso não disponível nesta versão do servidor.', { module: name });
}
