# Auditoria final — IVASLOVCK Tattoo Club

Data: 12/11/2026. Este documento registra o que foi encontrado, o que foi corrigido ou construído, os arquivos alterados, os testes executados e, com a mesma clareza, **o que não foi feito ou não foi possível verificar**.

## 1. Resumo

| Item | Estado |
|---|---|
| Backend próprio (Node.js 22 + PostgreSQL) com mais de 120 rotas | Funciona; 25 testes automáticos aprovados em SQLite |
| Frontend | **Somente a versão compilada original** (`public/`), idêntica à do ZIP recebido |
| Módulos novos nesta etapa | Meus contratos, Indicações, Cartão Presente (cliente e admin), Mensagem de divulgação, Canais oficiais e agendamento, cobrança Pix genérica |
| Módulos ainda não reconstruídos | Sorteios, Marketplace, IVT PAY, Limite de confiança, Parcelamento, Upgrade, Multas e juros, Liberação antecipada, Quitação especial, Suporte, Push, Identidade, Landing pages (respondem HTTP 501 com aviso, sem simulação) |
| Pacote para GitHub e Hostinger | Pronto (README, DEPLOY_HOSTINGER, PUBLICAR_GITHUB, scripts, CI) |
| Testes em PostgreSQL | **Não executados aqui** (sem PostgreSQL no ambiente). O CI do GitHub os executa |
| Deploy na Hostinger / publicação no GitHub | **Não realizados**: não tenho acesso à sua conta nem à VPS |

## 2. O que foi recebido

- `IVASLOVCK_TATTOO_COMPLETO.zip`: backend próprio com 19 testes, scripts de deploy e o frontend compilado.
- **Não havia** código-fonte do frontend (React/Vite), código original das Netlify Functions, banco de dados nem dados reais de clientes.

## 3. Problemas encontrados e correções

| # | Problema | Correção |
|---|---|---|
| 1 | Módulos Indicações, Cartão Presente, Meus contratos, Mensagem de divulgação e Canais oficiais respondiam 501 | Reconstruídos a partir dos formatos que as telas esperam, com testes |
| 2 | Não existia cobrança Pix para algo além de planos (a tela `/cobranca/:id` depende disso) | Criada a base de cobranças (`charges`), com conferência de valor e referência |
| 3 | O instalador automático alterava o Nginx e o firewall sem verificar se o servidor tinha outros projetos | Agora ele recusa rodar em servidor com outros serviços e orienta o caminho manual (seção 4B do guia) |
| 4 | Porta 3000 fixa nos scripts e no proxy | `APP_PORT` e `APP_BIND` respeitados em compose, instalador e atualizador |
| 5 | `.gitignore` incompleto (não cobria `.env.*`, dumps, logs, uploads) | Reforçado; varredura de segredos na árvore final sem ocorrências |
| 6 | Sem integração contínua | Criado `.github/workflows/ci.yml` (SQLite, PostgreSQL 16 e build do Docker) |
| 7 | Documentação desatualizada | README, guias e relatórios reescritos ou atualizados |
| 8 | Sem `package-lock.json` | **Não resolvido aqui** (sem internet). O guia explica como gerar; o Dockerfile já o usa quando existe |
| 9 | Frontend sem código-fonte | **Não resolvido**: exige o projeto Vite original |
| 10 | Sem recuperação de senha: a tela manda o cliente falar com o estúdio e o painel não tem como redefinir a senha | Criado `npm run reset-password` (senha temporária aleatória, encerra sessões, registra auditoria). Não há recuperação automática por e-mail |

Durante os testes dos módulos novos foram encontrados e corrigidos defeitos do meu próprio código, por exemplo um campo com nome errado que quebrava a tela de perfil (botão de agendar) e a comparação de datas, verificada contra a normalização do driver do PostgreSQL.

## 4. Arquivos alterados e criados (comparação com o ZIP recebido)

**Frontend (`public/`): nenhuma diferença.**

Criados:
- `server/src/migrations/002_referrals.sql`, `003_charges_gifts.sql`
- `server/src/services/referrals.js`, `charges.js`, `gifts.js`
- `server/src/routes/policies.js`, `referrals.js`, `outreach.js`, `gifts.js`
- `server/scripts/reset-password.js`
- `.github/workflows/ci.yml`, `DEPLOY_HOSTINGER.md`, `PUBLICAR_GITHUB.md`, `FINAL_AUDITORIA.md`

Modificados:
- `server/src/index.js` (registro das rotas e rotinas periódicas)
- `server/src/routes/auth.js` (captura do código de indicação no cadastro)
- `server/src/services/subscriptions.js` (marcos de indicação e roteamento de pagamentos de cobranças)
- `server/src/services/coins.js` (exportação da função de lançamento de moedas)
- `server/package.json` (script `reset-password`)
- `server/tests/flows.test.js` (de 19 para 25 testes)
- `.gitignore`, `.env.example`, `docker-compose.yml`, `Dockerfile`, `README.md`
- `deploy/scripts/instalar.sh`, `deploy/scripts/atualizar.sh`
- `docs/CHECKLIST_GITHUB_VPS.md`, `docs/RELATORIO_RECONSTRUCAO.md`, `docs/RELATORIO_TESTES.md`

## 5. Verificação por área

| Área | Evidência |
|---|---|
| Login, cadastro, logout, sessão | Testes 1, 2, 3 e 18; cookie `HttpOnly` e `SameSite=Lax`, `Secure` em produção; senha com scrypt; limite de tentativas |
| Recuperação de senha | Não é automática (a tela orienta falar com o estúdio). Redefinição pelo estúdio: `npm run reset-password`, teste 25 |
| Permissões e isolamento entre contas | Teste 15 e os testes novos (cliente não lê contrato, presente, cobrança nem painel de outro; ações administrativas só para o dono) |
| Painel administrativo | Planos, pagamentos, clientes, cartões, IVT COIN, Indicações, Cartão Presente, Divulgação e Canais: funcionam. Módulos pendentes: 501 |
| Painel do cliente | Contratação, Pix, carteira, perfil, Indicações, Presentes, Meus contratos: funcionam |
| Rotas e atualização de página | O servidor devolve o `index.html` para rotas do app; coberto pelos testes de servidor e pelo navegador na etapa de prévia |
| Banco e integridade | Migrações automáticas; `CHECK` contra saldo negativo; teste de integridade (16); script `npm run integrity` |
| Persistência | Teste 18 (dados sobrevivem a reinício) |
| Pagamentos | Valor fixado no servidor; webhook conferido; pagamento duplicado ignorado; valor divergente vai para análise e **não** credita |
| Segredos | Nenhum segredo no repositório (varredura); `APP_SECRET` cifra dados sensíveis |

Testes de navegador (Chromium headless) foram feitos sobre uma versão de prévia que executa o mesmo código do servidor dentro do navegador, com SQLite: login do cliente e do admin, planos, Pix, Indicações, Cartão Presente (compra, pagamento, resgate), Divulgação, Canais e painéis admin. **Os scripts dessa prévia não fazem parte deste repositório**, e os testes `tests/e2e-browser.mjs` e `tests/crawl-browser.mjs` existentes **não foram reexecutados** nesta etapa.

## 6. Segurança: pontos a decidir

- Configurados: cookies `HttpOnly`, `SameSite=Lax`, `X-Frame-Options`, `Referrer-Policy`, `X-Content-Type-Options`, assinatura `x-signature` do webhook, limite de tentativas em cadastro e login.
- **Recomendados e não configurados:** `Strict-Transport-Security` (adicione no Nginx depois de confirmar o HTTPS) e `Content-Security-Policy` (precisa ser testada com o frontend compilado).
- Os limites de tentativa ficam em memória: valem por processo e zeram ao reiniciar.
- Os links do Cartão Presente são portadores: quem tem o link resgata. É o desenho do produto; trate-os como senha.

## 7. Premissas minhas (regras inferidas, não confirmadas)

O ZIP não trazia as regras originais, então, nos módulos novos, deduzi a estrutura pelas telas e usei valores padrão, todos editáveis no painel:
- **Indicações:** 100 IVT por indicação, validação no primeiro pagamento confirmado, 7 dias de carência, 30 dias para cumprir, limite de 10 por mês, antifraude por nome igual, WhatsApp sequencial/fora do padrão e mesma rede.
- **Cartão Presente:** valores de R$ 50 a R$ 500, validade de 365 dias, 3 modelos visuais, mensagens sugeridas. O “saldo restante” por cartão é calculado consumindo o cartão mais antigo primeiro.
- **Agendamento:** o crédito considerado é só o de plano; multas e juros não existem e não são descontados.
- **Contrato:** o texto jurídico do estúdio precisa ser cadastrado (`npm run set-contract`).

Se o sistema original funcionava diferente, ajuste na configuração ou me peça a correção.

## 8. O que depende de você

1. Criar o repositório e enviar o código (`PUBLICAR_GITHUB.md`) e conferir o CI verde, em especial o job de PostgreSQL.
2. Acesso à VPS e decisão do caminho 4A ou 4B do `DEPLOY_HOSTINGER.md`, depois de olhar o que já roda no servidor.
3. Confirmar onde o DNS do domínio é gerenciado e testar antes em um subdomínio.
4. Credenciais do Mercado Pago (primeiro `TEST-`, depois produção) e o webhook.
5. Gerar e guardar o `APP_SECRET` fora do servidor.
6. Gerar o `package-lock.json` e fazer commit.
7. Texto jurídico do contrato e valores reais dos planos.
8. Se existirem dados do sistema antigo, exportá-los: migrar com conferência de saldos antes de abrir ao público.
9. Código-fonte do frontend, se quiser alterar telas.
10. Regras de negócio dos módulos ainda não reconstruídos, na ordem que você preferir.

## 9. Riscos conhecidos

- Sem teste real em PostgreSQL ou com o Mercado Pago de produção feito por mim. O código foi escrito no dialeto PostgreSQL e as comparações de data conferidas contra o driver, mas só o CI e o seu sandbox provam.
- Frontend não editável (só compilado).
- Módulos pendentes mostram aviso de 501 aos usuários que os acessarem; considere ocultar os atalhos no frontend se isso incomodar (exige o código-fonte).
