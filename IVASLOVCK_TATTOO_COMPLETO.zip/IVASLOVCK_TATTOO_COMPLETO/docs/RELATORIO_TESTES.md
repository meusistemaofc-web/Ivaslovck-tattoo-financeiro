# Relatório de Testes — IVASLOVCK Tattoo Club

Execução: 06/11/2026 · Node.js v22.23.4 · Resultado: **19/19 testes automáticos aprovados**, **6/6 etapas no navegador**, **55/55 telas abrem sem travar**.

## Ambiente e limitações (leia antes)
- **Banco**: SQLite temporário (o mesmo SQL do PostgreSQL, traduzido automaticamente). O ambiente de construção **não tinha PostgreSQL nem Docker**. O comportamento concorrente no PostgreSQL (travas `FOR UPDATE`) **precisa ser confirmado na VPS** com `npm run test:pg` (instruções no Guia, passo 9).
- **Mercado Pago**: o ambiente não tinha internet. Foi usado um **dublê de teste** local que imita o contrato HTTP da API (`POST/GET /v1/payments`, `GET /users/me`, idempotência por `X-Idempotency-Key`). Nenhuma cobrança real foi feita. **O teste com o sandbox real do Mercado Pago deve ser feito na VPS** com credencial `TEST-` (Guia, passo 10).
- Nenhum dado de produção foi usado ou alterado.

## Testes automáticos (`npm test` → `tests/flows.test.js`)
Executados pela API HTTP real do servidor.

| # | Fluxo exigido | Resultado | Evidência verificada |
|---|---|---|---|
| 1 | Cadastro de cliente | ✅ | Código IVT0001 gerado; e-mail normalizado; e-mail e WhatsApp duplicados → 409 |
| 2 | Login e logout | ✅ | Login por WhatsApp; senha errada → 401; após logout `/api/auth/me` → 401 |
| 3 | Criação e consulta de carteira | ✅ | Carteira criada sob demanda, saldo 0 |
| 4 | Consulta de saldo | ✅ | `summary` e `wallet` coerentes |
| 5 | Recarga (pagamento de parcela) | ✅ | Valor acima do máximo → 400; Pix pendente não gera saldo |
| 6 | Pagamento via Pix | ✅ | QR Code + copia-e-cola; mesma chave → mesmo Pix; 1 única chamada ao provedor |
| 7 | Recebimento de webhook | ✅ | Assinatura forjada → 401; webhook com pagamento ainda pendente não muda nada |
| 8 | Crédito após confirmação | ✅ | Saldo 0 durante o plano; R$ 300,00 liberados só na quitação (via sincronização do admin); webhook atrasado não duplica |
| 9 | Proteção contra pagamento duplicado | ✅ | **6 webhooks simultâneos** → pagamento aplicado 1 vez (`paidCents = 10000`) |
| 10 | Débito de saldo | ✅ | Saldo insuficiente → 409; reserva impede 2ª cobrança; código errado → 400; **autorização simultânea app + código debita 1 vez** |
| 11 | Movimentação de IVT COIN | ✅ | Crédito idempotente; débito acima do saldo → 409; saldo em reais intocado; conversão recusada até configurar; conversão idempotente com dupla escrituração; oferta de moedas consistente |
| 12 | Contratação de plano | ✅ | Hash do contrato adulterado → 409; valor fora das opções → 400; 2ª contratação aberta → 409 |
| 13 | Consulta de benefícios | ✅ | Modelos BLACK/GOLD/SILVER; elegibilidade "plano quitado" bloqueia cliente sem quitação; emissão, bloqueio, desbloqueio |
| 14 | Gestão administrativa | ✅ | Criar/pausar/reativar plano; plano pausado some da vitrine; validação; teste de credencial MP |
| 15 | Histórico financeiro | ✅ | Receita = só Pix aprovados (30000), créditos liberados (30000) e usados (20000) separados; operações auditadas |
| 16 | Persistência após reinicialização | ✅ | Servidor e banco fechados e reabertos; saldos, moedas e sessões preservados; integridade OK |
| 17 | Controle de permissões | ✅ | Cliente no admin → 403; sem sessão → 401; cliente B não vê pagamento/plano do cliente A (404); cliente não entra no painel; origem externa → 403 |
| 18 | Integridade das transações | ✅ | Saldos = livros-razão; `UPDATE`/`DELETE` em ledger recusados pelo banco; saldo negativo recusado por `CHECK`; tentativas do frontend de "creditar" não mudam o saldo |
| + | Pagamento com valor divergente | ✅ | Vai para conciliação, não credita; admin concilia com justificativa |
| + | Prazo da 1ª parcela | ✅ | Contratação vencida sem Pix → `cancelled_unpaid` |
| + | Módulos não reconstruídos | ✅ | Respondem 501 com nome do módulo |

Saída resumida da execução:
```
# tests 19
# pass 19
# fail 0
```

## Teste no navegador real (`tests/e2e-browser.mjs`, Chromium)
Frontend **original** compilado + backend novo:

| Etapa | Resultado |
|---|---|
| Cadastro pelo app e redirecionamento para /inicio | ✅ |
| Lista de planos | ✅ |
| Contratação com aceite dos termos | ✅ |
| Tela do Pix com QR Code e código | ✅ |
| Tela muda sozinha para "Pagamento realizado!" após a confirmação do banco | ✅ |
| Login no painel administrativo | ✅ |

## Varredura de telas (`tests/crawl-browser.mjs`)
55 telas (33 do cliente, 22 do painel) abertas com dados reais. **Todas abrem sem erro de JavaScript.** 12 mostram o aviso de módulo não reconstruído (sorteios, IVT Market, IVT PAY, presentes, suporte etc.).

Defeitos encontrados e corrigidos durante a varredura: tela de detalhes do plano, "Meu crédito", detalhes do cartão, IVT COIN e conversão travavam por falta de campos na resposta — todos corrigidos e revalidados.

## Como repetir
```bash
cd server
npm test                                   # SQLite + dublê do Mercado Pago
TEST_DATABASE_URL=postgres://.../ivaslovck_test npm run test:pg   # PostgreSQL de TESTE (o banco é apagado!)
```
