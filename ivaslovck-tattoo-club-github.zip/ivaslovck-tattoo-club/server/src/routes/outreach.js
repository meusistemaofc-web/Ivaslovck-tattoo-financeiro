import { db } from '../db.js';
import { config } from '../config.js';
import { requireUser, requireAdmin, requireOwner } from '../auth.js';
import { bad } from '../http.js';
import { getSetting, setSetting, audit } from '../services/settings.js';

const str = (v, max, label, { required = false } = {}) => {
  const s = String(v ?? '').trim();
  if (required && !s) throw bad(`${label}: preenchimento obrigatório.`);
  if (s.length > max) throw bad(`${label}: no máximo ${max} caracteres.`);
  return s;
};
const brl = (c) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const httpUrl = (v) => { try { const u = new URL(v); return /^https?:$/.test(u.protocol) ? u : null; } catch { return null; } };

// ---------- Mensagem de divulgação ----------
const shareDefaults = () => ({
  title: '🔥 Não é loucura. É planejamento!',
  body: 'Organize sua próxima tatuagem ou piercing no seu ritmo: escolha um plano, pague aos poucos e use o crédito no estúdio.',
  cta: '💙 Vem para a IVASLOVCK!', linkLabel: '👉', link: `${config.appUrl}/cadastro?ref=`, personalizeRef: true,
});
async function shareState() {
  const saved = await getSetting('shareMessage');
  return { message: { ...shareDefaults(), ...(saved?.message || {}) }, updatedAt: saved?.updatedAt || null, updatedBy: saved?.updatedBy || null };
}
function personalLink(m, user) {
  if (!m.link) return '';
  const u = httpUrl(m.link);
  if (!u || !m.personalizeRef || !u.searchParams.has('ref') || u.origin !== new URL(config.appUrl).origin) return m.link;
  if (user?.referral_code) u.searchParams.set('ref', user.referral_code); else u.searchParams.delete('ref');
  return u.toString();
}
const shareText = (m, link) => [m.title, m.body, m.cta, [m.linkLabel, link].filter(Boolean).join(' ')].map((x) => String(x || '').trim()).filter(Boolean).join('\n\n');

// ---------- Canais oficiais ----------
export const ICONS = ['instagram', 'whatsapp', 'facebook', 'tiktok', 'youtube', 'site', 'email', 'phone', 'map', 'link'];
const channelDefaults = () => [
  { id: 'instagram', kind: 'instagram', name: 'Instagram', icon: 'instagram', caption: 'Acompanhe nossos trabalhos', value: '', active: false, showInProfile: true },
  { id: 'whatsapp', kind: 'whatsapp', name: 'WhatsApp', icon: 'whatsapp', caption: 'Fale com o estúdio', value: '', active: false, showInProfile: true },
  { id: 'facebook', kind: 'facebook', name: 'Facebook', icon: 'facebook', caption: '', value: '', active: false, showInProfile: true },
  { id: 'tiktok', kind: 'tiktok', name: 'TikTok', icon: 'tiktok', caption: '', value: '', active: false, showInProfile: true },
  { id: 'site', kind: 'site', name: 'Site', icon: 'site', caption: '', value: '', active: false, showInProfile: true },
];
const bookingDefaults = () => ({
  enabled: true, whatsapp: '', buttonLabel: 'Agendar minha sessão', minCreditCents: 1, sectionTitle: 'Redes sociais e canais oficiais',
  message: 'Olá! Sou {nome} (cliente {codigo}). Tenho {credito} de crédito liberado na IVASLOVCK Tattoo Club e gostaria de agendar minha sessão. Quais horários estão disponíveis?',
  noticeEnabled: true, noticeTitle: 'Seu crédito está liberado!', noticeText: 'Você já pode pedir seu horário pelo WhatsApp oficial do estúdio.',
});

// Converte o valor digitado em um endereço seguro. Retorna null se inválido (nunca aceita javascript:, data: etc.).
export function channelHref(kindOrIcon, value) {
  const v = String(value || '').trim();
  if (!v) return null;
  const digits = v.replace(/\D/g, '');
  const wa = () => (digits.length >= 10 && digits.length <= 13 ? `https://wa.me/${digits.length <= 11 ? '55' : ''}${digits}` : null);
  switch (kindOrIcon) {
    case 'instagram': { if (/^@?[A-Za-z0-9._]{1,30}$/.test(v)) return `https://instagram.com/${v.replace(/^@/, '')}`; const u = httpUrl(v); return u && /(^|\.)instagram\.com$/.test(u.hostname) ? u.toString() : null; }
    case 'tiktok': { if (/^@?[A-Za-z0-9._]{1,24}$/.test(v)) return `https://tiktok.com/@${v.replace(/^@/, '')}`; const u = httpUrl(v); return u && /(^|\.)tiktok\.com$/.test(u.hostname) ? u.toString() : null; }
    case 'whatsapp': { if (/^https?:/i.test(v)) { const u = httpUrl(v); return u && /^(wa\.me|api\.whatsapp\.com|chat\.whatsapp\.com)$/.test(u.hostname) ? u.toString() : null; } return wa(); }
    case 'email': return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? `mailto:${v}` : null;
    case 'phone': return digits.length >= 10 && digits.length <= 13 ? `tel:+${digits.length <= 11 ? '55' : ''}${digits}` : null;
    default: { const u = httpUrl(v); return u ? u.toString() : null; }
  }
}
async function channelState() {
  const saved = await getSetting('channelsConfig');
  return { channels: saved?.channels || channelDefaults(), booking: { ...bookingDefaults(), ...(saved?.booking || {}) } };
}
const withHref = (c) => ({ ...c, href: c.active ? channelHref(c.kind === 'custom' ? c.icon : c.kind, c.value) : channelHref(c.kind === 'custom' ? c.icon : c.kind, c.value) });
const randomId = () => `c_${Math.random().toString(36).slice(2, 10)}`;

function sanitizeChannels(list, booking) {
  if (!Array.isArray(list) || list.length > 30) throw bad('Lista de canais inválida (máximo de 30).');
  const channels = list.map((c) => {
    const kind = c.kind === 'custom' ? 'custom' : String(c.kind || '');
    if (kind !== 'custom' && !channelDefaults().some((d) => d.kind === kind)) throw bad('Tipo de canal inválido.');
    const icon = ICONS.includes(c.icon) ? c.icon : 'link';
    const out = { id: String(c.id || randomId()).slice(0, 40), kind, name: str(c.name, 40, 'Nome do canal', { required: true }), icon,
      caption: str(c.caption, 80, 'Texto de identificação'), value: str(c.value, 300, 'Endereço'), active: !!c.active, showInProfile: c.showInProfile !== false };
    if (out.active && !channelHref(kind === 'custom' ? icon : kind, out.value)) throw bad(`Informe um endereço válido para o canal “${out.name}” ou deixe-o inativo.`);
    return out;
  });
  const digits = String(booking?.whatsapp || '').replace(/\D/g, '');
  if (digits && (digits.length < 10 || digits.length > 13)) throw bad('WhatsApp de agendamento inválido.');
  const minCredit = Number(booking?.minCreditCents);
  if (!Number.isInteger(minCredit) || minCredit < 1) throw bad('Informe o crédito mínimo para exibir o agendamento.');
  return {
    channels,
    booking: {
      enabled: !!booking?.enabled, whatsapp: digits, buttonLabel: str(booking?.buttonLabel, 40, 'Texto do botão', { required: true }), minCreditCents: minCredit,
      sectionTitle: str(booking?.sectionTitle, 60, 'Título da seção', { required: true }), message: str(booking?.message, 1500, 'Mensagem automática', { required: true }),
      noticeEnabled: !!booking?.noticeEnabled, noticeTitle: str(booking?.noticeTitle, 60, 'Título do aviso'), noticeText: str(booking?.noticeText, 400, 'Texto do aviso'),
    },
  };
}

export default function register(r) {
  r.get('/api/share-message', async (req) => {
    const user = requireUser(req);
    const { message: m } = await shareState();
    const link = personalLink(m, user);
    return { text: shareText(m, link), link };
  });
  r.get('/api/share-message/admin', async (req) => { requireAdmin(req); return shareState(); });
  r.put('/api/share-message/admin', async (req) => {
    const a = requireOwner(req); const b = req.body || {};
    const link = str(b.link, 600, 'Link de cadastro');
    if (link && !httpUrl(link)) throw bad('O link de cadastro precisa começar com http:// ou https://.');
    const message = { title: str(b.title, 300, 'Título'), body: str(b.body, 2000, 'Texto principal'), cta: str(b.cta, 300, 'Chamada final'), linkLabel: str(b.linkLabel, 40, 'Antes do link'), link, personalizeRef: !!b.personalizeRef };
    if (!shareText(message, link)) throw bad('A mensagem não pode ficar vazia.');
    await setSetting('shareMessage', { message, updatedAt: new Date().toISOString(), updatedBy: a.name }, a.id);
    await audit(db(), 'share_message_changed', 'Mensagem de divulgação alterada', { actorId: a.id });
    return shareState();
  });
  r.post('/api/share-message/admin/restore', async (req) => {
    const a = requireOwner(req);
    await setSetting('shareMessage', null, a.id);
    await audit(db(), 'share_message_restored', 'Mensagem de divulgação restaurada ao padrão', { actorId: a.id });
    return shareState();
  });

  r.get('/api/channels/me', async (req) => {
    const user = requireUser(req);
    const { channels, booking: b } = await channelState();
    const list = channels.map(withHref).filter((c) => c.active && c.showInProfile && c.href).map((c) => ({ id: c.id, name: c.name, icon: c.icon, caption: c.caption, href: c.href }));
    let booking = null;
    if (user.role === 'client' && b.enabled) {
      const w = (await db().query('SELECT plan_cents FROM wallets WHERE user_id=$1', [user.id]))[0];
      const creditCents = Number(w?.plan_cents || 0);
      const phone = String(b.whatsapp || (await getSetting('supportWhatsapp')) || '').replace(/\D/g, '');
      if (creditCents >= b.minCreditCents && creditCents > 0 && phone.length >= 10) {
        const msg = b.message.replace(/\{nome\}/gi, user.name).replace(/\{codigo\}/gi, user.code || '').replace(/\{credito\}/gi, brl(creditCents));
        booking = {
          creditCents, label: b.buttonLabel, whatsappUrl: `https://wa.me/${phone.length <= 11 ? '55' : ''}${phone}?text=${encodeURIComponent(msg)}`,
          notice: b.noticeEnabled && b.noticeTitle ? { title: b.noticeTitle, text: b.noticeText } : null,
        };
      }
    }
    return { sectionTitle: b.sectionTitle, channels: list, booking };
  });
  r.get('/api/channels/admin', async (req) => {
    requireAdmin(req);
    const { channels, booking } = await channelState();
    return { channels: channels.map(withHref), icons: ICONS, booking, supportWhatsapp: (await getSetting('supportWhatsapp')) || '', defaults: { message: bookingDefaults().message } };
  });
  r.put('/api/channels/admin', async (req) => {
    const a = requireOwner(req);
    const cfg = sanitizeChannels(req.body?.channels, req.body?.booking);
    await setSetting('channelsConfig', cfg, a.id);
    await audit(db(), 'channels_changed', 'Canais oficiais e agendamento alterados', { actorId: a.id });
    const { channels, booking } = await channelState();
    return { channels: channels.map(withHref), icons: ICONS, booking, supportWhatsapp: (await getSetting('supportWhatsapp')) || '', defaults: { message: bookingDefaults().message } };
  });
}
