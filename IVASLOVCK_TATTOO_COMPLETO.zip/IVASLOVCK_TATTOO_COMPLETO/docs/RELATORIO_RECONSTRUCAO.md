# Relatório de Reconstrução — IVASLOVCK Tattoo Club

Data: 06/11/2026 · Entrada: `ivaslovcktattoo-main.zip` (preservado intacto, sem alterações)

## 1. Auditoria inicial — o que o ZIP continha

| Item | Situação |
|---|---|
| Frontend (React + Vite) | **Somente compilado**: `index.html`, 1 JS minificado (1,7 MB), 1 CSS, imagens, `sw.js` (PWA), `manifest.webmanifest`, avatares, ícones |
| Código-fonte do frontend (`src/`, `package.json`, `vite.config`) | **Ausente** — não recuperável a partir do bundle minificado |
| Backend / Netlify Functions | **Ausente (100%)** |
| Banco de dados / migrações | **Ausente** |
| Configuração Netlify | `netlify.toml` (redirect SPA + cabeçalhos de cache) — guardado em `legacy/` |
| Supabase | **Nenhuma evidência** no código |
| Autenticação | Sessão por cookie (`credentials: same-origin`), erros no formato `{ error }` |
| Endpoints chamados pelo frontend | **364 rotas `/api/...`** distintas em ~30 módulos |

### Defeito crítico encontrado no download
Os arquivos de `assets/` vieram com nomes **em minúsculas** (`index-dkmyskau.js`), mas o `index.html` e o JS referenciam `index-DkMysKaU.js`, `ivt-coin-front-192-BWb3Oxxx.webp` etc. Em servidores Linux (sensíveis a maiúsculas) o site **não carregava**. **Corrigido**: os 6 arquivos foram renomeados para os nomes exatos referenciados.

## 2. Regras de negócio recuperadas do frontend
Extraídas por análise do bundle (textos, campos e validações das telas):

- **Crédito programado**: o cliente contrata um plano (categorias `tatuagem`, `piercing`, `outros`), escolhe o valor da contribuição entre as opções do plano e paga via Pix na periodicidade do plano (diária, semanal, quinzenal, mensal). **O crédito só é liberado após a quitação total.**
- Contratação aguarda o 1º Pix por um prazo configurável (padrão do painel: 24 h); sem pagamento → cancelada.
- Só uma contratação em aberto por cliente; não é possível contratar outro plano com crédito de plano ainda disponível.
- Opções por plano: pagamento mínimo, antecipação, várias parcelas no mesmo dia, destaque, ativo/pausado.
- **Utilização do crédito**: o estúdio gera uma "cobrança de resgate" (valor + atendimento); o cliente autoriza no app ou informa um código de 8 caracteres ao profissional.
- **Cartões digitais**: somente **BLACK, GOLD e SILVER** existem no código. **"Starter" não foi encontrado** em nenhum lugar do projeto e não foi criado. Elegibilidade: `todos`, `plano quitado` ou `crédito mínimo`. Os cartões usam o mesmo saldo da carteira.
- **IVT COIN**: carteira, extrato, distribuição manual pelo estúdio, débito com destino (retorno ao estoque / retirada de circulação), conversão em saldo.
- Cadastro **sem verificação de e-mail** (preservado); e-mail e WhatsApp únicos.

## 3. O que foi reconstruído (backend novo, `server/`)
Node.js 22 (ESM, sem framework), PostgreSQL em produção. **90 rotas** implementadas com o formato de resposta que as telas originais esperam.

| Módulo | Rotas | Estado |
|---|---|---|
| Autenticação (cadastro, login, logout, sessão, 1º administrador) | `/api/auth/*` | ✅ reconstruído e testado |
| Planos (público + admin: criar, editar, pausar, imagem) | `/api/plans*`, `/api/admin/plans*`, `/api/admin/images` | ✅ |
| Contratação + termo com hash | `/api/me/subscriptions*`, `/api/policies/preview` | ✅ |
| Pix Mercado Pago + webhook + sincronização + conciliação | `/api/me/payments*`, `/api/webhooks/mercadopago`, `/api/admin/payments*` | ✅ |
| Carteira, resumo, histórico, extrato | `/api/me/summary`, `/api/me/wallet`, `/api/me/history` | ✅ |
| Resgates (uso do crédito) | `/api/me/redemptions*`, `/api/admin/redemptions*`, `/api/admin/clients/:id/redemptions` | ✅ |
| Cartões BLACK/GOLD/SILVER | `/api/me/cards*`, `/api/admin/cards*`, `/api/admin/card-models*` | ✅ |
| IVT COIN (carteira, extrato, distribuição, débito, conversão, visão geral, auditoria) | `/api/coins/me/*`, `/api/coins/admin/*` (parte) | ✅ núcleo |
| Painel: indicadores, clientes, operações, configurações, teste de credencial | `/api/admin/*` | ✅ |
| Integridade (saldos × livros-razão) | `/api/admin/integrity`, `npm run integrity` | ✅ novo |
| Notificações (app e admin), perfil, avatares e foto | `/api/notifications*`, `/api/me/profile`, `/api/avatars*` | ✅ |
| Saúde do serviço | `/api/health` | ✅ novo |

Arquivos estáticos: servidos pelo próprio backend com os **mesmos cabeçalhos do `netlify.toml`** (sw.js sem cache, assets imutáveis, fallback SPA para `index.html`).

## 4. O que NÃO foi reconstruído (registrado, sem dados falsos)
O backend destes módulos só existia na Netlify e suas regras não podem ser deduzidas com segurança do frontend. As rotas respondem **HTTP 501** com a mensagem *"O módulo X ainda não foi reconstruído no servidor próprio."* — a tela mostra o aviso e nada é simulado.

Marketplace (IVT Market), Sorteios, Indicações, Campanhas de recompensa / regras automáticas de IVT COIN, Notificações push, Atendimento/suporte, Cadastro de identidade, Limite de confiança, Parcelamento com limite de confiança (`/api/credit`), Cartão Presente, IVT PAY (transferências), Quitação Especial, Liberação Antecipada, Upgrade de plano (lista vazia já tratada pela tela), Landing pages, Multas e juros (nenhuma multa é cobrada), Versões de políticas, Canais oficiais, Mensagem de divulgação, Índice interno de valorização da IVT COIN, cupons de IVT COIN.

Dados perdidos que viraram configuração do estúdio:
- **Texto jurídico do contrato**: o termo exibido hoje descreve apenas os dados objetivos do plano. O estúdio deve cadastrar as cláusulas com `npm run set-contract` (ver Guia).
- **Cotação da IVT COIN**: desligada até o dono configurar em *Admin › IVT COIN › Conversão*.
- **Validade da cobrança de resgate**: padrão operacional de 30 min (configurável via API de configurações).

## 5. Arquivos alterados no frontend
Nenhum código do frontend foi modificado. Apenas: renomeação dos 6 arquivos de `assets/` (correção de maiúsculas) e remoção do `netlify.toml` de `public/` (cópia em `legacy/`).

## 6. Problemas que não puderam ser resolvidos
1. Código-fonte do frontend ausente: alterações visuais futuras exigem o projeto Vite original (procure no GitHub/Netlify de quem gerou).
2. 22 módulos acima sem backend.
3. Não foi possível gerar `package-lock.json` (ambiente sem internet); a dependência única é `pg@^8.13`.
4. Dados reais da Netlify (clientes, saldos, pagamentos) **não estavam no ZIP**. Se existirem em algum banco antigo, precisam ser exportados e migrados com conferência (ver relatório financeiro, seção 8).
