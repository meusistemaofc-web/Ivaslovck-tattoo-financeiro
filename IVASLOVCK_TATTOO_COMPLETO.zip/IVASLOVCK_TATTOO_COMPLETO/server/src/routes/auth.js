import crypto from 'node:crypto';
import { db } from '../db.js';
import { config } from '../config.js';
import { bad, conflict, HttpError, forbidden } from '../http.js';
import {
  hashPassword, verifyPassword, createSession, destroySession, publicUser, checkRateLimit, resetRateLimit, isAdmin,
} from '../auth.js';
import { audit } from '../services/settings.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
export const onlyDigits = (s) => String(s || '').replace(/\D/g, '');

function validateSignup(b) {
  const name = String(b.name || '').trim().replace(/\s+/g, ' ');
  const whatsapp = onlyDigits(b.whatsapp);
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');
  if (name.length < 3 || !name.includes(' ')) throw bad('Informe seu nome completo.');
  if (whatsapp.length < 10 || whatsapp.length > 11) throw bad('Informe um WhatsApp válido com DDD.');
  if (!EMAIL_RE.test(email)) throw bad('Informe um e-mail válido.');
  if (password.length < 6) throw bad('A senha deve ter pelo menos 6 caracteres.');
  return { name: name.slice(0, 120), whatsapp, email, password };
}

async function nextClientCode(t) {
  const r = await t.query(`SELECT code FROM users WHERE code LIKE 'IVT%' ORDER BY LENGTH(code) DESC, code DESC LIMIT 1`);
  const n = r.length ? Number(r[0].code.slice(3)) + 1 : 1;
  return `IVT${String(n).padStart(4, '0')}`;
}

async function insertUser(t, data, role) {
  const dupE = await t.query('SELECT id FROM users WHERE email=$1', [data.email]);
  if (dupE.length) throw conflict('Este e-mail já está cadastrado. Faça login.');
  const dupW = await t.query('SELECT id FROM users WHERE whatsapp=$1', [data.whatsapp]);
  if (dupW.length) throw conflict('Este WhatsApp já está cadastrado. Faça login.');
  const code = role === 'client' ? await nextClientCode(t) : null;
  const ts = new Date().toISOString();
  const rows = await t.query(
    `INSERT INTO users (code, name, email, whatsapp, password_hash, role, referral_code, created_at, updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8) RETURNING *`,
    [code, data.name, data.email, data.whatsapp, await hashPassword(data.password), role, code, ts],
  );
  return rows[0];
}

export default function register(r) {
  r.get('/api/auth/me', async (req) => {
    if (!req.user) throw new HttpError(401, 'Não autenticado.');
    return { user: publicUser(req.user) };
  });

  // Cadastro sem verificação de e-mail (comportamento do projeto original).
  r.post('/api/auth/register', async (req, res) => {
    checkRateLimit(`register:${req.ip}`, 20, 3600000);
    const data = validateSignup(req.body);
    let user;
    try {
      user = await db().tx(async (t) => {
        const u = await insertUser(t, data, 'client');
        await audit(t, 'client_registered', `Novo cliente: ${u.name}`, { userId: u.id, actorId: u.id });
        return u;
      });
    } catch (e) {
      if (/unique|UNIQUE/.test(e.message)) throw conflict('E-mail ou WhatsApp já cadastrado.');
      throw e;
    }
    await createSession(res, user, req);
    return { user: publicUser(user) };
  });

  r.post('/api/auth/login', async (req, res) => {
    const login = String(req.body.login || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!login || !password) throw bad('Informe seu login e senha.');
    const rlKey = `login:${req.ip}:${login}`;
    checkRateLimit(rlKey, 10);
    const digits = onlyDigits(login);
    const rows = await db().query('SELECT * FROM users WHERE email=$1 OR (whatsapp=$2 AND $2 <> \'\')', [login, digits.length >= 10 ? digits : '']);
    const u = rows[0];
    if (!u || !(await verifyPassword(password, u.password_hash))) throw new HttpError(401, 'Login ou senha incorretos.');
    if (u.status !== 'active') throw forbidden('Conta bloqueada. Fale com o estúdio.');
    if (req.body.admin && !isAdmin(u)) throw forbidden('Esta conta não tem acesso ao painel administrativo.');
    resetRateLimit(rlKey);
    await createSession(res, u, req);
    return { user: publicUser(u) };
  });

  r.post('/api/auth/logout', async (req, res) => {
    await destroySession(req, res);
    return { ok: true };
  });

  // Criação do PRIMEIRO administrador (owner). Exige ADMIN_SETUP_TOKEN no .env e só funciona sem admins.
  r.get('/api/auth/admin-setup', async () => {
    const admins = await db().query(`SELECT id FROM users WHERE role IN ('admin','owner') LIMIT 1`);
    return { needed: admins.length === 0, enabled: !!config.adminSetupToken };
  });

  r.post('/api/auth/admin-setup', async (req, res) => {
    checkRateLimit(`setup:${req.ip}`, 10);
    if (!config.adminSetupToken) throw forbidden('Configuração inicial desativada (defina ADMIN_SETUP_TOKEN no servidor).');
    const tok = String(req.body.setupToken || '');
    const a = Buffer.from(tok), b = Buffer.from(config.adminSetupToken);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw forbidden('Código de configuração inválido.');
    const data = validateSignup(req.body);
    if (data.password.length < 8) throw bad('Use uma senha forte com pelo menos 8 caracteres.');
    const user = await db().tx(async (t) => {
      const admins = await t.query(`SELECT id FROM users WHERE role IN ('admin','owner') LIMIT 1`);
      if (admins.length) throw conflict('O administrador já foi criado.');
      const u = await insertUser(t, data, 'owner');
      await audit(t, 'admin_created', `Administrador principal criado: ${u.name}`, { actorId: u.id });
      return u;
    });
    await createSession(res, user, req);
    return { user: publicUser(user) };
  });
}
