# Implantação na Hostinger (VPS) — IVASLOVCK Tattoo Club

Guia para colocar o sistema no ar na sua VPS, usando o **domínio que já existe**, sem mexer em outros projetos e com backup antes de qualquer troca.

> Regra de ouro: **não altere DNS, Nginx, firewall ou containers existentes sem antes olhar o que há no servidor** (seção 2). Tudo aqui foi escrito para somar ao servidor, não para substituir o que já funciona.

## 1. Arquitetura

```
Internet ──► Nginx (no servidor, HTTPS) ──► 127.0.0.1:PORTA ──► container "app" (Node.js 22)
                                                                   │
                                                                   └──► container "db" (PostgreSQL 16, volume persistente)
```

- O container `app` serve a API e o frontend. Ele só escuta em `127.0.0.1`, então não fica exposto direto.
- O banco e as fotos enviadas ficam em volumes do Docker e **sobrevivem** a atualizações.
- O Docker reinicia os containers sozinho (`restart: unless-stopped`), inclusive depois de reiniciar a VPS.
- O Certbot emite e renova o certificado HTTPS.

Valores que **não** são assumidos e devem ser conferidos no seu servidor: porta livre, domínio, e-mail do certificado e credenciais do Mercado Pago.

## 2. Antes de começar: olhe o que já existe no servidor

Entre na VPS (`ssh root@IP_DA_VPS` ou *hPanel › VPS › Terminal do navegador*) e rode:

```bash
lsb_release -ds                 # sistema (Ubuntu 22.04 ou 24.04)
docker ps -a 2>/dev/null        # containers existentes
ls /etc/nginx/sites-enabled     # sites já configurados no Nginx
ss -ltnp | grep -E ':(80|443|3000|5432)\b'   # portas em uso
pm2 list 2>/dev/null            # processos PM2, se houver
df -h /                         # espaço em disco (precisa de ~3 GB livres)
```

Anote o resultado. Decisões:

| O que você encontrou | O que fazer |
|---|---|
| Servidor novo, nada instalado | Caminho **4A** (instalador automático) |
| Já há sites, containers ou portas 80/443 em uso | Caminho **4B** (manual, só acrescenta) |
| Porta 3000 ocupada | Escolha outra (ex.: 3100) em `APP_PORT` no `.env` |
| Já existe uma instalação deste mesmo sistema | Faça **backup** e siga a seção 9 (atualização) |
| Nginx Proxy Manager instalado | Siga a seção 7 |

Se já existe uma instalação deste sistema, **não apague nada**: faça o backup da seção 9 primeiro.

## 3. Domínio existente e DNS (sem derrubar o que está no ar)

O domínio já foi usado por este projeto (na Netlify). Para trocar com segurança:

1. **Descubra para onde ele aponta hoje** e quem controla o DNS:
   ```bash
   dig +short A seudominio.com.br
   dig +short CNAME www.seudominio.com.br
   dig +short NS seudominio.com.br
   ```
   - Se os nameservers forem da Hostinger, edite no *hPanel › Domínios › DNS / Zona DNS*.
   - Se forem da Netlify (ou de outro provedor), edite lá, ou troque os nameservers para os da Hostinger. Escolha um só lugar e mantenha.
2. **Teste primeiro em um subdomínio**, para o site atual continuar no ar: crie um registro `A` de `novo` apontando para o IP da VPS e use `novo.seudominio.com.br` nas seções 4 a 6.
3. **Quando tudo estiver validado**, aponte o domínio principal:
   - `A` de `@` (e de `www`, ou `CNAME www` para o domínio) → IP da VPS.
   - Antes, reduza o TTL desses registros para 300 segundos e aguarde o TTL antigo vencer.
   - **Não apague** registros que não são do site, como `MX` e `TXT` de e-mail.
4. Atualize `APP_URL` no `.env` para o domínio final e rode `docker compose up -d`. Atualize também a URL do webhook no Mercado Pago (seção 6).
5. Mantenha o site antigo na Netlify por alguns dias como plano de volta. Para voltar, basta reapontar o DNS.

Observações:
- Quem estava logado no site antigo precisará entrar de novo (a sessão é do novo servidor).
- O certificado HTTPS só é emitido depois que o domínio aponta para a VPS.
- Os dados do site antigo (clientes, saldos, pagamentos) **não estavam no material recebido**. Se existirem em algum banco da Netlify, é preciso exportá-los e migrá-los com conferência de saldos antes de abrir ao público.

## 4. Instalação

Coloque o projeto na VPS (substitua pelo seu repositório):

```bash
cd /opt
git clone https://github.com/SEU_USUARIO/ivaslovck-tattoo-club.git
cd ivaslovck-tattoo-club
```

Repositório privado: use um *Personal Access Token* ou uma *Deploy key* (veja `PUBLICAR_GITHUB.md`).

### 4A. Servidor novo: instalador automático

```bash
sudo bash deploy/scripts/instalar.sh
```

Ele instala Docker, Nginx e Certbot, gera um `.env` com segredos aleatórios, sobe os containers, configura o Nginx, pede o certificado HTTPS e agenda backup diário. **Se detectar outros serviços no servidor, ele para sem alterar nada** e manda você para a seção 4B.

### 4B. Servidor com outros projetos: caminho manual (só acrescenta)

**1) Docker e Certbot** (pule o que já estiver instalado):

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl openssl nginx certbot python3-certbot-nginx
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sudo sh
```

**2) Arquivo `.env`:**

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

Preencha, no mínimo:

| Variável | Valor |
|---|---|
| `APP_URL` | `https://seudominio.com.br` |
| `APP_SECRET` | resultado de `openssl rand -hex 32` (**guarde uma cópia fora do servidor**) |
| `POSTGRES_PASSWORD` | resultado de `openssl rand -hex 24` |
| `ADMIN_SETUP_TOKEN` | resultado de `openssl rand -hex 12` |
| `APP_PORT` | uma porta livre (3000 se estiver livre) |

**3) Subir:**

```bash
docker compose up -d --build
docker compose ps
curl -fsS http://127.0.0.1:3000/api/health      # use a sua APP_PORT
```

Esperado: `{"ok":true,"db":"postgres",...}`. As migrações do banco rodam sozinhas na primeira inicialização.

**4) Nginx: um arquivo novo, só para o seu domínio** (não toca nos outros sites):

```bash
DOMINIO=seudominio.com.br      # ou novo.seudominio.com.br no teste
PORTA=3000                     # a mesma APP_PORT
sed -e "s/SEU_DOMINIO/$DOMINIO/g" -e "s/127.0.0.1:3000/127.0.0.1:$PORTA/" \
  deploy/nginx/ivaslovck.conf | sudo tee /etc/nginx/sites-available/ivaslovck.conf >/dev/null
sudo ln -s /etc/nginx/sites-available/ivaslovck.conf /etc/nginx/sites-enabled/ivaslovck.conf
sudo nginx -t && sudo systemctl reload nginx
```

Se `nginx -t` acusar erro, **não recarregue**: corrija ou remova o link recém-criado (`sudo rm /etc/nginx/sites-enabled/ivaslovck.conf`).

**5) HTTPS** (o domínio precisa já apontar para a VPS):

```bash
sudo certbot --nginx -d $DOMINIO -d www.$DOMINIO --redirect -m SEU_EMAIL --agree-tos
```

O Certbot só altera o bloco do Nginx que responde por esses nomes. Se `www` não existir no DNS, use apenas `-d $DOMINIO`.

**6) Backup diário:**

```bash
mkdir -p backups
( crontab -l 2>/dev/null | grep -v 'deploy/scripts/backup.sh'; \
  echo "30 3 * * * cd $(pwd) && bash deploy/scripts/backup.sh >> $(pwd)/backups/backup.log 2>&1" ) | crontab -
```

## 5. Primeiro administrador

1. Abra `https://seudominio.com.br/admin/entrar`.
2. Aba **Configuração inicial**: nome, WhatsApp, e-mail, a chave (`ADMIN_SETUP_TOKEN` do `.env`) e a senha.
3. **Depois de criar**, apague o valor de `ADMIN_SETUP_TOKEN` no `.env` e rode `docker compose up -d`.

## 6. Configuração do sistema

1. **Mercado Pago:** no painel, *Configurações*, cole o Access Token e use **Testar conexão**.
   - Primeiro com o token de teste (`TEST-...`) para validar o fluxo. Só depois coloque o de produção (`APP_USR-...`).
2. **Webhook:** em *Mercado Pago › Suas integrações › Webhooks*, cadastre `https://seudominio.com.br/api/webhooks/mercadopago`, evento **Pagamentos**, e coloque a assinatura secreta em `MP_WEBHOOK_SECRET` (ou no painel).
3. **Contrato:** cadastre as cláusulas do estúdio:
   ```bash
   docker compose cp clausulas.txt app:/tmp/clausulas.txt
   docker compose exec app npm run set-contract -- /tmp/clausulas.txt
   ```
4. Cadastre planos, revise os modelos de cartão, o WhatsApp de atendimento, os **Canais oficiais** e o **Cartão Presente** (valores, modelos, validade).
5. Revise o programa de **Indicações** (recompensa, prazo de confirmação, limites).
6. **Senha esquecida:** o app não tem recuperação por e-mail; a tela manda o cliente falar com o estúdio. Para redefinir, pelo WhatsApp ou e-mail da conta:
   ```bash
   docker compose exec app npm run reset-password -- 11999998888
   ```
   O comando gera uma senha temporária, encerra as sessões abertas da conta e registra na auditoria. Envie a senha ao cliente por um canal seguro.

## 7. Nginx Proxy Manager (se já estiver no servidor)

Se o servidor usa o Nginx Proxy Manager (NPM), **não** instale outro Nginx na 80/443. Em vez disso:

1. No `.env`, defina `APP_BIND=172.17.0.1` (IP da ponte do Docker; confira com `ip -4 addr show docker0`) e `APP_PORT` livre. Rode `docker compose up -d`. Isso deixa o NPM, que roda em outro container, alcançar o app sem expô-lo na internet.
2. No NPM: *Proxy Hosts › Add*. Domínio: `seudominio.com.br`. Esquema `http`. Forward Hostname/IP `172.17.0.1`, Forward Port = `APP_PORT`. Ative *Block Common Exploits*. WebSockets: não são necessários.
3. Aba SSL: *Request a new certificate*, *Force SSL*, *HTTP/2*.
4. Mantenha `TRUST_PROXY=true` no `.env`.

Não use `0.0.0.0` em `APP_BIND` (abriria a porta do app para a internet).

## 8. Alternativa sem Docker (Node + PostgreSQL + systemd)

Use só se preferir não usar Docker. Requer Node.js 22.5 ou superior e PostgreSQL.

```bash
# Node 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs postgresql
# Banco
sudo -u postgres psql -c "CREATE USER ivaslovck WITH PASSWORD 'TROQUE_ESTA_SENHA';"
sudo -u postgres psql -c "CREATE DATABASE ivaslovck OWNER ivaslovck;"
# Aplicação
sudo mkdir -p /opt/ivaslovck /var/lib/ivaslovck/uploads
sudo cp -r server public /opt/ivaslovck/
cd /opt/ivaslovck/server && sudo npm install --omit=dev
```

Crie `/etc/ivaslovck.env` (permissão 600) com `NODE_ENV=production`, `PORT=3100`, `HOST=127.0.0.1`, `APP_URL`, `APP_SECRET`, `DATABASE_URL=postgres://ivaslovck:SENHA@127.0.0.1:5432/ivaslovck`, `PUBLIC_DIR=/opt/ivaslovck/public`, `UPLOADS_DIR=/var/lib/ivaslovck/uploads`, `COOKIE_SECURE=true`, `TRUST_PROXY=true`. Depois `/etc/systemd/system/ivaslovck.service`:

```ini
[Unit]
Description=IVASLOVCK Tattoo Club
After=network.target postgresql.service

[Service]
WorkingDirectory=/opt/ivaslovck/server
EnvironmentFile=/etc/ivaslovck.env
ExecStart=/usr/bin/node src/index.js
Restart=always
RestartSec=3
User=www-data

[Install]
WantedBy=multi-user.target
```

```bash
sudo chown -R www-data /var/lib/ivaslovck
sudo systemctl daemon-reload && sudo systemctl enable --now ivaslovck
```

O Nginx e o HTTPS seguem a seção 4B (passos 4 e 5), com a porta `3100`. Se preferir PM2 em vez de systemd, use `pm2 start src/index.js --name ivaslovck` dentro de `/opt/ivaslovck/server`, com as mesmas variáveis. Neste caminho, o backup do banco é com `pg_dump` (os scripts de `deploy/scripts` são para o caminho Docker).

## 9. Atualização segura e volta

Atualizar (faz backup automaticamente antes):

```bash
cd /opt/ivaslovck-tattoo-club
git pull
bash deploy/scripts/atualizar.sh
```

O script cria backup do banco e das fotos, reconstrói a imagem, reinicia e confere `/api/health`.

Voltar atrás se algo der errado:

```bash
ls backups/                                   # escolha o backup de antes da atualização
git checkout TAG_OU_COMMIT_ANTERIOR
bash deploy/scripts/restaurar.sh backups/banco-AAAAMMDD-HHMMSS.dump backups/uploads-AAAAMMDD-HHMMSS.tar.gz
docker compose up -d --build
```

O `restaurar.sh` pede confirmação e faz um backup do estado atual antes de substituir os dados. Copie a pasta `backups/` de vez em quando para **fora da VPS**.

## 10. Verificação depois de implantar

| Conferência | Como |
|---|---|
| Containers de pé | `docker compose ps` mostra `app` e `db` como `running`/`healthy` |
| API e banco | `curl -fsS https://seudominio.com.br/api/health` retorna `"db":"postgres"` |
| HTTPS | cadeado no navegador; `http://` redireciona para `https://` |
| Rotas ao recarregar | abra `https://seudominio.com.br/admin/entrar` direto e aperte F5 |
| Login e cadastro | crie uma conta de cliente e entre |
| Pix | contrate um plano com o token `TEST-` e pague no sandbox; o crédito só aparece depois da quitação |
| Integridade financeira | `docker compose exec app npm run integrity` mostra “OK: saldos conferem com o histórico.” |
| Reinício automático | `sudo reboot`, aguarde e repita o `curl` do health |
| Backup | `bash deploy/scripts/backup.sh` cria os arquivos em `backups/` |
| Testes em PostgreSQL (opcional) | CI do GitHub, ou `TEST_DATABASE_URL=... npm run test:pg` em banco de **teste** |

## 11. Problemas comuns

| Sintoma | Causa provável | Solução |
|---|---|---|
| `docker compose up` reclama de `POSTGRES_PASSWORD` | `.env` incompleto | preencha `POSTGRES_PASSWORD` |
| 502 Bad Gateway no navegador | app parado ou porta diferente no Nginx | `docker compose logs app`; confira `APP_PORT` e o Nginx |
| Certbot falha | DNS ainda não aponta para a VPS | confira `dig +short A seudominio.com.br` e tente de novo |
| Login “funciona” e volta para a tela inicial | `COOKIE_SECURE=true` sem HTTPS | acesse por HTTPS ou ajuste o `.env` |
| Pix não confirma sozinho | webhook mal cadastrado | confira URL, evento e assinatura; o sistema também confere o pagamento ao consultar |
| Porta já em uso | outro serviço na mesma porta | troque `APP_PORT` e o Nginx |
| Tela com “módulo ainda não foi reconstruído” | módulo pendente (HTTP 501) | esperado; veja `FINAL_AUDITORIA.md` |

## 12. Segurança

- `.env` com permissão 600 e **fora do GitHub**. Guarde `APP_SECRET` em um cofre de senhas: sem ele, dados cifrados ficam ilegíveis.
- Apague `ADMIN_SETUP_TOKEN` depois do primeiro administrador.
- Mantenha o firewall liberando só SSH, 80 e 443 (o instalador automático faz isso em servidor novo; em servidor com outros projetos, ajuste com cuidado).
- Nunca publique a porta do app na internet (`APP_BIND` fica em `127.0.0.1` ou no IP da ponte do Docker).
