#!/usr/bin/env bash
# Restaura um backup do banco. ATENÇÃO: substitui TODOS os dados atuais.
#   bash deploy/scripts/restaurar.sh backups/banco-AAAAMMDD-HHMMSS.dump [backups/uploads-....tar.gz]
set -euo pipefail
cd "$(dirname "$0")/../.."
[ -f "${1:-}" ] || { echo "Informe o arquivo .dump"; exit 1; }
set -a; . ./.env; set +a
read -rp "Isto vai SUBSTITUIR todos os dados atuais. Digite RESTAURAR para continuar: " OK
[ "$OK" = "RESTAURAR" ] || { echo "Cancelado."; exit 1; }
bash deploy/scripts/backup.sh   # segurança: guarda o estado atual antes
docker compose stop app
docker compose exec -T db pg_restore -U "${POSTGRES_USER:-ivaslovck}" -d "${POSTGRES_DB:-ivaslovck}" --clean --if-exists --no-owner < "$1"
if [ -f "${2:-}" ]; then docker compose run --rm -T --entrypoint sh app -c "tar -xzf - -C /app/data" < "$2"; fi
docker compose start app
echo "Restauração concluída. Rode: docker compose exec app npm run integrity"
