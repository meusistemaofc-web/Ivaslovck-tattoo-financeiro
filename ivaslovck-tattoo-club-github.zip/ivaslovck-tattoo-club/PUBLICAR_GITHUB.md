# Publicar no GitHub

Este guia leva o projeto do seu computador até um repositório **privado** no GitHub e deixa a VPS pronta para baixá-lo. Eu não tenho acesso à sua conta, então estes passos são seus.

> Repositório **privado** é o recomendado: o código contém regras financeiras e a estrutura do sistema.

## 1. Criar o repositório vazio

1. Entre em https://github.com/new
2. Nome sugerido: `ivaslovck-tattoo-club`. Marque **Private**.
3. **Não** marque “Add a README”, “.gitignore” nem “license” (o projeto já traz o seu).
4. Clique em **Create repository** e copie o endereço, algo como `https://github.com/SEU_USUARIO/ivaslovck-tattoo-club.git`.

## 2. Enviar o código (recomendado: terminal ou GitHub Desktop)

Descompacte o ZIP e, dentro da pasta `ivaslovck-tattoo-club`:

```bash
git init -b main
git add .
```

**Confira antes de enviar** que nenhum segredo entrou (os dois comandos abaixo não devem imprimir nada):

```bash
git ls-files | grep -E '(^|/)\.env$'
git ls-files | grep -E 'node_modules|\.sqlite|\.dump'
```

Se ambos estiverem vazios, siga:

```bash
git commit -m "IVASLOVCK Tattoo Club: backend próprio, módulos e guia de implantação"
git remote add origin https://github.com/SEU_USUARIO/ivaslovck-tattoo-club.git
git push -u origin main
```

Na primeira vez o Git pede autenticação. Use um **Personal Access Token** no lugar da senha (GitHub › Settings › Developer settings › Personal access tokens › Fine-grained, permissão *Contents: Read and write* só neste repositório), ou `gh auth login` se tiver o GitHub CLI. **Não salve o token em nenhum arquivo do projeto.**

Com o **GitHub Desktop**: *File › Add local repository*, escolha a pasta, *Publish repository* e mantenha “Keep this code private”.

### Pela página do GitHub (não recomendado)

O envio pelo navegador aceita no máximo 100 arquivos por vez e costuma ignorar pastas ocultas como `.github`. O projeto tem cerca de 200 arquivos, então use o terminal ou o GitHub Desktop.

## 3. Conferir o resultado

- Na aba **Actions**, o fluxo **CI** roda sozinho: testes em SQLite, **testes em PostgreSQL 16** e o build da imagem Docker. Os três precisam ficar verdes. O teste em PostgreSQL é a verificação que não pude executar durante a preparação, então confira esse resultado.
- Na aba **Code**, confirme que **não** existe `.env` nem `node_modules`.

## 4. Gerar o `package-lock.json` (recomendado, uma vez)

Não consegui gerar esse arquivo porque o ambiente onde preparei o projeto não tem acesso à internet. Ele fixa as versões exatas das dependências. No seu computador, com Node 22.5+:

```bash
cd server
npm install
cd ..
git add server/package-lock.json
git commit -m "Adiciona package-lock.json"
git push
```

O `Dockerfile` já usa o lockfile automaticamente quando ele existe.

## 5. Deixar a VPS baixar o repositório

Para repositório privado, use uma **chave de implantação somente leitura**. Na VPS:

```bash
ssh-keygen -t ed25519 -C "vps-ivaslovck" -f ~/.ssh/ivaslovck_deploy -N ""
cat ~/.ssh/ivaslovck_deploy.pub
```

No GitHub: repositório › **Settings › Deploy keys › Add deploy key**, cole a chave pública e deixe **Allow write access desmarcado**. De volta à VPS:

```bash
cat >> ~/.ssh/config <<'EOC'
Host github-ivaslovck
  HostName github.com
  User git
  IdentityFile ~/.ssh/ivaslovck_deploy
  IdentitiesOnly yes
EOC
cd /opt
git clone git@github-ivaslovck:SEU_USUARIO/ivaslovck-tattoo-club.git
```

Depois siga o `DEPLOY_HOSTINGER.md`.

## 6. No dia a dia

```bash
git add -A && git commit -m "descrição da mudança" && git push     # no seu computador
cd /opt/ivaslovck-tattoo-club && git pull && bash deploy/scripts/atualizar.sh   # na VPS
```

Nunca coloque `.env`, `APP_SECRET`, tokens do Mercado Pago ou backups no repositório. O `.gitignore` já bloqueia esses arquivos, mas confira com `git status` antes de cada envio.
