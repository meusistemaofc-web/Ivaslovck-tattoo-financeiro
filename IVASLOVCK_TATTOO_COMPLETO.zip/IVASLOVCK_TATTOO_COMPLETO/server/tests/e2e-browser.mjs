// Teste no navegador real (Chromium/Playwright): frontend ORIGINAL compilado + backend reconstruído.
// Uso: PLAYWRIGHT_BROWSERS_PATH=... node tests/e2e-browser.mjs <pasta-de-screenshots>
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { startFakeMp, Client, tmpDbPath, uuid } from './helpers.js';

const outDir = process.argv[2] || '/tmp/e2e';
fs.mkdirSync(outDir, { recursive: true });
const fake = await startFakeMp();
const dbPath = tmpDbPath();
Object.assign(process.env, {
  DATABASE_URL: '', SQLITE_PATH: dbPath, MP_API_BASE: fake.url, MP_ACCESS_TOKEN: 'TEST-fake-token-1234567890abcdef',
  ADMIN_SETUP_TOKEN: 'setup', APP_SECRET: 'y'.repeat(40), UPLOADS_DIR: dbPath + '-up', PORT: '4321', HOST: '127.0.0.1', APP_URL: 'http://127.0.0.1:4321',
});
const { start } = await import('../src/index.js');
await start();
const base = 'http://127.0.0.1:4321';
const log = [];
const step = (s, ok, extra = '') => { log.push({ step: s, ok, extra }); console.log(ok ? 'OK  ' : 'FALHA', s, extra); };

// Preparação via API: administrador e plano
const admin = new Client(base);
await admin.post('/api/auth/admin-setup', { name: 'Dono Estudio', whatsapp: '11911112222', email: 'dono@estudio.com', password: 'adminpass', setupToken: 'setup' });
await admin.post('/api/admin/plans', { name: 'Fechamento de braço', category: 'tatuagem', description: 'Plano demonstrativo criado no teste.', totalCents: 20000, minPaymentCents: 1000, dailyOptions: [5000, 10000], allowCustom: false, period: 'weekly', allowAdvance: true, allowMultiple: true, featured: true, active: true });

const { chromium } = await import('/opt/npm-tools/node_modules/playwright/index.mjs');
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 400, height: 860 } });
const consoleErrors = [];
page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
page.on('pageerror', (e) => consoleErrors.push('PAGEERROR ' + e.message));
const shot = (n) => page.screenshot({ path: path.join(outDir, `${n}.png`) });

try {
  await page.goto(base + '/cadastro', { waitUntil: 'domcontentloaded' });
  await shot('01-cadastro');
  await page.fill('input[name="name"]', 'Cliente Navegador Teste');
  await page.fill('input[name="whatsapp"]', '11977776666');
  await page.fill('input[name="email"]', 'nav@teste.com');
  await page.fill('input[name="password"]', 'segredo1');
  const confirm = await page.$('input[name="confirm"]');
  if (confirm) await confirm.fill('segredo1');
  await page.click('button[type="submit"]');
  await page.waitForURL(/inicio/, { timeout: 15000 });
  await page.waitForTimeout(1500);
  await shot('02-inicio');
  step('Cadastro pelo app e redirecionamento para /inicio', true);

  await page.goto(base + '/planos', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  await shot('03-planos');
  const hasPlan = await page.getByText('Fechamento de braço').count();
  step('Lista de planos exibida', hasPlan > 0);
  await page.getByText('Fechamento de braço').first().click();
  await page.waitForTimeout(1200);
  await shot('04-plano-detalhe');
  // avança para revisão
  const btns = await page.$$eval('button, a', (els) => els.map((e) => e.textContent.trim()).filter(Boolean));
  fs.writeFileSync(path.join(outDir, 'botoes-plano.json'), JSON.stringify(btns, null, 1));
  const cont = page.getByRole('button', { name: /continuar|contratar|avançar/i }).first();
  await cont.click();
  await page.waitForTimeout(1500);
  await shot('05-revisar');
  await page.locator('.consent-box input[type="checkbox"]').check();
  await page.getByRole('button', { name: /Confirmar contratação/ }).click();
  await page.waitForURL(/pagar\?assinatura=/, { timeout: 15000 });
  await page.waitForTimeout(1200);
  await shot('06-pagar');
  step('Contratação pelo app (aceite de termos)', true);
  await page.getByRole('button', { name: /Gerar Pix|Pagar agora/ }).last().click();
  await page.waitForURL(/pagamento=/, { timeout: 15000 });
  await page.waitForTimeout(1500);
  await shot('07-pix');
  const qrOk = await page.locator('img[alt="QR Code Pix"]').count();
  step('Tela do Pix com QR Code', qrOk > 0);

  // banco confirma -> webhook -> tela deve mudar sozinha (polling do app)
  const payId = Number(new URL(page.url()).searchParams.get('pagamento'));
  const pr = [...fake.payments.values()].find((p) => p.external_reference === `ivs-payment-${payId}`);
  fake.approve(pr.id);
  await new Client(base).post(`/api/webhooks/mercadopago?data.id=${pr.id}&type=payment`, { type: 'payment', data: { id: String(pr.id) } });
  await page.waitForTimeout(7000);
  await shot('08-pix-confirmado');
  const body = await page.textContent('body');
  step('Tela atualizada após confirmação do banco', !/Escaneie o QR Code/.test(body), body.slice(0, 120).replace(/\s+/g, ' '));

  await page.goto(base + '/meus-planos', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1000);
  await shot('09-meus-planos');
  await page.goto(base + '/ivt-coin', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1000);
  await shot('10-ivt-coin');

  // Admin
  const ap = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  ap.on('pageerror', (e) => consoleErrors.push('ADMIN PAGEERROR ' + e.message));
  await ap.goto(base + '/admin', { waitUntil: 'domcontentloaded' });
  await ap.waitForTimeout(1000);
  await ap.screenshot({ path: path.join(outDir, '11-admin-login.png') });
  const inputs = await ap.$$('input');
  await ap.fill('input[name="login"], input[autocomplete="username"]', 'dono@estudio.com').catch(async () => { await inputs[0].fill('dono@estudio.com'); });
  await ap.fill('input[type="password"]', 'adminpass');
  await ap.click('button[type="submit"]');
  await ap.waitForTimeout(2500);
  await ap.screenshot({ path: path.join(outDir, '12-admin-visao-geral.png') });
  step('Login no painel administrativo', /admin/.test(ap.url()) && !(await ap.locator('input[type="password"]').count()), ap.url());
  for (const [n, u] of [['13-admin-clientes', '/admin/clientes'], ['14-admin-pagamentos', '/admin/pagamentos'], ['15-admin-planos', '/admin/planos'], ['16-admin-config', '/admin/configuracoes'], ['17-admin-cartoes', '/admin/cartoes']]) {
    await ap.goto(base + u, { waitUntil: 'domcontentloaded' });
    await ap.waitForTimeout(1200);
    await ap.screenshot({ path: path.join(outDir, `${n}.png`) });
  }
} catch (e) {
  step('Erro no fluxo do navegador', false, e.message);
  await shot('erro').catch(() => {});
}
fs.writeFileSync(path.join(outDir, 'resultado.json'), JSON.stringify({ log, consoleErrors }, null, 1));
console.log('Erros de console:', consoleErrors.length);
consoleErrors.slice(0, 30).forEach((e) => console.log('  ', e.slice(0, 200)));
await browser.close();
await fake.close();
process.exit(0);
