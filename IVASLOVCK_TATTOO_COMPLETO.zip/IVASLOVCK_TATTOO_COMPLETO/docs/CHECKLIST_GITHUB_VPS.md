# Checklist de Publicação — GitHub e VPS

## Antes de subir para o GitHub
- [ ] Repositório criado como **privado**
- [ ] Arquivo `.env` **não** está no ZIP nem no repositório (só o `.env.example`)
- [ ] Nenhuma credencial real em arquivos (token Mercado Pago, senhas)
- [ ] ZIP `IVASLOVCK_TATTOO_COMPLETO.zip` enviado inteiro (você descompacta na VPS)
- [ ] ZIP original `ivaslovcktattoo-main.zip` guardado em local seguro (backup do projeto antigo)

## Domínio
- [ ] Registros A `@` e `www` apontando para o IP da VPS
- [ ] `ping seudominio.com.br` responde com o IP da VPS

## VPS
- [ ] Ubuntu 22.04/24.04, acesso root
- [ ] Arquivos em `/opt/IVASLOVCK_TATTOO_COMPLETO`
- [ ] `sudo bash deploy/scripts/instalar.sh` concluído
- [ ] `docker compose ps` mostra `db` e `app` como healthy
- [ ] `https://seudominio.com.br/api/health` responde `{"ok":true,"db":"postgres",...}`
- [ ] Cadeado HTTPS ativo no navegador

## Configuração
- [ ] Primeiro administrador criado em `/admin/entrar`
- [ ] `ADMIN_SETUP_TOKEN` apagado do `.env` e `docker compose up -d` executado
- [ ] Access Token do Mercado Pago configurado e "Testar conexão" OK
- [ ] Webhook cadastrado no Mercado Pago (`/api/webhooks/mercadopago`, evento Pagamentos)
- [ ] Assinatura secreta do webhook configurada
- [ ] Cláusulas do contrato cadastradas (`npm run set-contract`)
- [ ] WhatsApp de atendimento, validade do Pix e prazo da 1ª parcela revisados
- [ ] Planos de tatuagem e piercing cadastrados com os valores reais do estúdio
- [ ] Modelos de cartão revisados (BLACK, GOLD, SILVER)
- [ ] Cotação de IVT COIN definida (ou mantida desligada)

## Validação
- [ ] `npm run test:pg` em banco de teste: 19 aprovados, 0 falhas
- [ ] Teste com sandbox (token TEST-): Pix gerado, pago e confirmado automaticamente
- [ ] Teste de resgate: cobrança criada no painel e autorizada no app
- [ ] `docker compose exec app npm run integrity` → "OK: saldos conferem"
- [ ] Token de produção (APP_USR-) recolocado após os testes

## Operação contínua
- [ ] Backup diário agendado (`crontab -l` mostra `backup.sh`)
- [ ] Cópia periódica de `backups/` para fora da VPS
- [ ] Teste de restauração feito pelo menos uma vez
