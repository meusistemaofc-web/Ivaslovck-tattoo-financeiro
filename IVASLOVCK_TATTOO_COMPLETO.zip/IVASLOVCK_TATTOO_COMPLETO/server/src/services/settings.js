import crypto from 'node:crypto';
import { db } from '../db.js';
import { config } from '../config.js';

// Valores padrão vindos dos estados iniciais do painel original (useState(30) e useState(24)).
export const DEFAULTS = {
  pixExpirationMinutes: 30,
  firstPaymentHours: 24,
  redemptionExpirationMinutes: 30,
  supportWhatsapp: '',
  // Termos de contratação: o texto jurídico original ficava no servidor da Netlify e não veio no ZIP.
  // Fica configurável; o padrão só descreve dados objetivos do plano (ver policies.js).
  termsVersion: '1',
  contractClauses: '',
  // IVT COIN: configuração em 'coinConversion' (ver services/coins.js), desligada por padrão.
  coinConversion: null,
};
export const FIRST_PAYMENT_PRESETS = [1, 2, 6, 12, 24, 48, 72];
const SECRET_KEYS = new Set(['mpAccessToken', 'mpWebhookSecret']);

function key() {
  return crypto.createHash('sha256').update(config.appSecret || 'dev-insecure-secret').digest();
}
function encrypt(text) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const enc = Buffer.concat([c.update(text, 'utf8'), c.final()]);
  return `enc:v1:${iv.toString('base64')}:${c.getAuthTag().toString('base64')}:${enc.toString('base64')}`;
}
function decrypt(val) {
  if (!val || !val.startsWith('enc:v1:')) return val;
  const [, , iv, tag, data] = val.split(':');
  const d = crypto.createDecipheriv('aes-256-gcm', key(), Buffer.from(iv, 'base64'));
  d.setAuthTag(Buffer.from(tag, 'base64'));
  return Buffer.concat([d.update(Buffer.from(data, 'base64')), d.final()]).toString('utf8');
}

export async function getSetting(name, q = db()) {
  const rows = await q.query('SELECT value FROM settings WHERE key = $1', [name]);
  if (!rows.length || rows[0].value == null) return DEFAULTS[name];
  let v = rows[0].value;
  if (SECRET_KEYS.has(name)) {
    try { return decrypt(v); } catch { return ''; }
  }
  try { return JSON.parse(v); } catch { return v; }
}

export async function setSetting(name, value, actorId, q = db()) {
  let v = value == null ? null : SECRET_KEYS.has(name) ? encrypt(String(value)) : JSON.stringify(value);
  const now = new Date().toISOString();
  await q.query(
    `INSERT INTO settings (key, value, updated_by, updated_at) VALUES ($1,$2,$3,$4)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_by = EXCLUDED.updated_by, updated_at = EXCLUDED.updated_at`,
    [name, v, actorId || null, now],
  );
}

export async function mpAccessToken() {
  return config.mpAccessToken || (await getSetting('mpAccessToken')) || '';
}
export async function mpWebhookSecret() {
  return config.mpWebhookSecret || (await getSetting('mpWebhookSecret')) || '';
}

export async function audit(q, type, message, { userId = null, actorId = null, amountCents = null, meta = null } = {}) {
  await q.query(
    'INSERT INTO audit_log (type, message, user_id, actor_id, amount_cents, meta, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)',
    [type, message, userId, actorId, amountCents, meta ? JSON.stringify(meta) : null, new Date().toISOString()],
  );
}

export async function notify(q, userId, title, body, link, kind = null, audience = 'client') {
  await q.query(
    'INSERT INTO notifications (user_id, audience, title, body, link, kind, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)',
    [userId, audience, title, body || null, link || null, kind, new Date().toISOString()],
  );
}
