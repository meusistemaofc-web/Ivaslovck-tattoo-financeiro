import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { db } from '../db.js';
import { config } from '../config.js';
import { bad, notFound } from '../http.js';
import { requireAdmin, requireOwner } from '../auth.js';
import { getSetting, setSetting, audit, FIRST_PAYMENT_PRESETS, DEFAULTS, mpAccessToken } from '../services/settings.js';
import * as subs from '../services/subscriptions.js';
import * as wallet from '../services/wallet.js';
import * as red from '../services/redemptions.js';
import * as coins from '../services/coins.js';
import * as mp from '../services/mercadopago.js';
import { cardView } from './cards.js';

const now = () => new Date().toISOString();
const int = (v, d = 0) => (Number.isFinite(Number(v)) ? Math.round(Number(v)) : d);

function planInput(b) {
  const name = String(b.name || '').trim();
  if (!name) throw bad('Informe o nome do plano.');
  if (!['tatuagem', 'piercing', 'outros'].includes(b.category)) throw bad('Categoria inválida.');
  if (!['daily', 'weekly', 'biweekly', 'monthly'].includes(b.period)) throw bad('Periodicidade inválida.');
  const total = int(b.totalCents), min = int(b.minPaymentCents);
  if (total <= 0) throw bad('Informe o valor total do plano.');
  if (min <= 0 || min > total) throw bad('Pagamento mínimo inválido.');
  const opts = [...new Set((Array.isArray(b.dailyOptions) ? b.dailyOptions : []).map((x) => int(x)).filter((x) => x >= min && x <= total))].sort((a, c) => a - c);
  if (!opts.length && !b.allowCustom) throw bad('Informe ao menos um valor de contribuição.');
  return {
    name: name.slice(0, 120), category: b.category, description: String(b.description || '').slice(0, 4000),
    image_key: b.imageKey || null, image_url: b.imageUrl || null, total_cents: total, min_payment_cents: min,
    daily_options: JSON.stringify(opts), allow_custom: !!b.allowCustom, period: b.period, allow_advance: !!b.allowAdvance,
    allow_multiple: !!b.allowMultiple, allow_early_payoff: !!b.allowEarlyPayoff, featured: !!b.featured,
    active: b.active !== false, sort_order: int(b.sortOrder), payoff_enabled: false, accepts_benefit: !!b.acceptsBenefit,
  };
}

async function clientRow(u) {
  const w = await wallet.getWallet(db(), u.id);
  const s = (await db().query(`SELECT * FROM subscriptions WHERE user_id=$1 AND status IN ('active','awaiting_first_payment') ORDER BY id DESC LIMIT 1`, [u.id]))[0];
  return {
    id: u.id, code: u.code, name: u.name, whatsapp: u.whatsapp, email: u.email, status: u.status, createdAt: u.created_at,
    creditBalance: w.balance_cents, activePlan: s ? { id: s.id, planName: s.plan_name, percent: Math.floor((s.paid_cents * 100) / s.total_cents), status: s.status } : null,
  };
}

function opView(o) {
  return { id: o.id, type: o.type, message: o.message, userId: o.user_id, clientName: o.client_name || null, amountCents: o.amount_cents, createdAt: o.created_at };
}

export default function register(r) {
  // ---------- Visão geral ----------
  r.get('/api/admin/stats', async (req) => {
    requireAdmin(req);
    await subs.expireDue();
    const one = async (sql, p = []) => Number(Object.values((await db().query(sql, p))[0])[0] || 0);
    const recent = await db().query(`SELECT a.*, u.name AS client_name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 12`);
    return {
      clients: await one(`SELECT COUNT(*) FROM users WHERE role='client'`),
      activeSubscriptions: await one(`SELECT COUNT(*) FROM subscriptions WHERE status='active'`),
      completedSubscriptions: await one(`SELECT COUNT(*) FROM subscriptions WHERE status='completed'`),
      // Dinheiro efetivamente recebido = somente Pix aprovados e aplicados (não inclui conciliação, créditos promocionais ou IVT COIN).
      receivedCents: await one(`SELECT COALESCE(SUM(amount_cents),0) FROM payments WHERE status='approved'`),
      approvedPayments: await one(`SELECT COUNT(*) FROM payments WHERE status='approved'`),
      pendingPaymentsCents: await one(`SELECT COALESCE(SUM(amount_cents),0) FROM payments WHERE status='pending'`),
      reconciliationCents: await one(`SELECT COALESCE(SUM(amount_cents),0) FROM payments WHERE status='reconciliation'`),
      creditsReleasedCents: await one(`SELECT COALESCE(SUM(amount_cents),0) FROM credit_releases`),
      creditsUsedCents: await one(`SELECT COALESCE(SUM(amount_cents),0) FROM redemptions WHERE status='confirmed'`),
      outstandingCreditCents: await one(`SELECT COALESCE(SUM(balance_cents),0) FROM wallets`),
      contractedCents: await one(`SELECT COALESCE(SUM(total_cents),0) FROM subscriptions WHERE status IN ('active','completed')`),
      payoffBenefitCents: 0, payoffGranted: 0,
      recent: recent.map(opView),
    };
  });

  r.get('/api/admin/operations', async (req) => {
    requireAdmin(req);
    const rows = await db().query(`SELECT a.*, u.name AS client_name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 500`);
    return { operations: rows.map(opView) };
  });

  // ---------- Clientes ----------
  r.get('/api/admin/clients', async (req) => {
    requireAdmin(req);
    const q = (req.query.get('q') || '').trim().toLowerCase();
    const params = [];
    let sql = `SELECT * FROM users WHERE role='client'`;
    if (q) {
      params.push(`%${q}%`, `%${q.replace(/\D/g, '') || '§'}%`);
      sql += ` AND (LOWER(name) LIKE $1 OR LOWER(code) LIKE $1 OR LOWER(email) LIKE $1 OR whatsapp LIKE $2)`;
    }
    sql += ' ORDER BY id DESC LIMIT 200';
    const rows = await db().query(sql, params);
    const clients = [];
    for (const u of rows) clients.push(await clientRow(u));
    return { clients };
  });

  r.get('/api/admin/clients/:id', async (req) => {
    requireAdmin(req);
    await red.expireRedemptions();
    const u = (await db().query(`SELECT * FROM users WHERE id=$1 AND role='client'`, [int(req.params.id)]))[0];
    if (!u) throw notFound('Cliente não encontrado.');
    const subsRows = await db().query('SELECT * FROM subscriptions WHERE user_id=$1 ORDER BY id DESC', [u.id]);
    const pays = await db().query(`SELECT p.*, s.plan_name FROM payments p JOIN subscriptions s ON s.id=p.subscription_id WHERE p.user_id=$1 ORDER BY p.id DESC`, [u.id]);
    const reds = await db().query('SELECT * FROM redemptions WHERE user_id=$1 ORDER BY id DESC', [u.id]);
    const credits = await db().query('SELECT * FROM credit_releases WHERE user_id=$1 ORDER BY id DESC', [u.id]);
    const cards = await db().query(`SELECT c.*, m.code AS model_code, m.name AS model_name FROM cards c JOIN card_models m ON m.id=c.model_id WHERE c.user_id=$1 ORDER BY c.id DESC`, [u.id]);
    const w = await wallet.getWallet(db(), u.id);
    return {
      client: await clientRow(u),
      wallet: { totalCents: w.balance_cents, planCents: w.plan_cents, giftCents: w.gift_cents, conversionCents: w.conversion_cents },
      reservedCents: await red.reservedCents(db(), u.id),
      subscriptions: subsRows.map((s) => subs.subscriptionView(s)),
      payments: pays.map((p) => ({ ...subs.paymentView(p), planName: p.plan_name })),
      redemptions: reds.map((x) => red.redemptionView(x)),
      credits: credits.map((c) => ({ id: c.id, amountCents: c.amount_cents, subscriptionId: c.subscription_id, createdAt: c.created_at })),
      cards: cards.map((c) => cardView(c)),
      referredBy: null,
    };
  });

  r.post('/api/admin/clients/:id/redemptions', async (req) => {
    const a = requireAdmin(req);
    const x = await red.createRedemption(a, int(req.params.id), req.body || {});
    return { redemption: red.redemptionView(x) };
  });

  // ---------- Resgates ----------
  r.get('/api/admin/redemptions', async (req) => {
    requireAdmin(req);
    await red.expireRedemptions();
    const st = req.query.get('status');
    const rows = await db().query(
      `SELECT r.*, u.name AS client_name, u.code AS client_code FROM redemptions r JOIN users u ON u.id=r.user_id
       ${st ? 'WHERE r.status=$1' : ''} ORDER BY r.id DESC LIMIT 300`, st ? [st] : []);
    return { redemptions: rows.map((x) => red.redemptionView(x, { clientId: x.user_id, clientName: x.client_name, clientCode: x.client_code })) };
  });
  r.get('/api/admin/redemptions/:id', async (req) => {
    requireAdmin(req);
    await red.expireRedemptions();
    const x = (await db().query('SELECT * FROM redemptions WHERE id=$1', [int(req.params.id)]))[0];
    if (!x) throw notFound();
    return { redemption: red.redemptionView(x) };
  });
  r.post('/api/admin/redemptions/:id/confirm', async (req) => {
    const a = requireAdmin(req);
    const x = await red.confirmRedemption({ id: int(req.params.id), actor: a, via: 'admin_code', code: req.body?.code });
    return { redemption: red.redemptionView(x) };
  });
  r.post('/api/admin/redemptions/:id/cancel', async (req) => {
    const a = requireAdmin(req);
    await red.closeRedemption({ id: int(req.params.id), actor: a, status: 'cancelled' });
    return { ok: true };
  });

  // ---------- Planos ----------
  r.get('/api/admin/plans', async (req) => {
    requireAdmin(req);
    const rows = await db().query(`SELECT p.*, (SELECT COUNT(*) FROM subscriptions s WHERE s.plan_id=p.id AND s.status IN ('active','completed')) AS contracts FROM plans p ORDER BY p.sort_order, p.id`);
    return { plans: rows.map((p) => subs.planView(p, { contracts: Number(p.contracts) })) };
  });
  r.get('/api/admin/plans/:id', async (req) => {
    requireAdmin(req);
    const p = (await db().query('SELECT * FROM plans WHERE id=$1', [int(req.params.id)]))[0];
    if (!p) throw notFound();
    return { plan: subs.planView(p) };
  });
  r.post('/api/admin/plans', async (req) => {
    const a = requireAdmin(req);
    const d = planInput(req.body || {});
    const cols = Object.keys(d);
    const rows = await db().query(
      `INSERT INTO plans (${cols.join(',')}, created_at, updated_at) VALUES (${cols.map((_, i) => `$${i + 1}`).join(',')}, $${cols.length + 1}, $${cols.length + 1}) RETURNING *`,
      [...Object.values(d), now()]);
    await audit(db(), 'plan_created', `Plano ${d.name} criado`, { actorId: a.id, amountCents: d.total_cents });
    return { plan: subs.planView(rows[0]) };
  });
  r.put('/api/admin/plans/:id', async (req) => {
    const a = requireAdmin(req);
    const p = (await db().query('SELECT * FROM plans WHERE id=$1', [int(req.params.id)]))[0];
    if (!p) throw notFound();
    const d = planInput(req.body || {});
    // Contratações existentes guardam snapshot das condições: editar o plano NÃO altera contratos em andamento.
    const cols = Object.keys(d);
    await db().query(`UPDATE plans SET ${cols.map((c, i) => `${c}=$${i + 1}`).join(', ')}, updated_at=$${cols.length + 1} WHERE id=$${cols.length + 2}`,
      [...Object.values(d), now(), p.id]);
    await audit(db(), 'plan_updated', `Plano ${d.name} atualizado`, { actorId: a.id, meta: { before: subs.planView(p) } });
    return { ok: true };
  });
  r.post('/api/admin/plans/:id/toggle', async (req) => {
    const a = requireAdmin(req);
    const p = (await db().query('SELECT * FROM plans WHERE id=$1', [int(req.params.id)]))[0];
    if (!p) throw notFound();
    const active = !(p.active === true || p.active === 1);
    await db().query('UPDATE plans SET active=$1, updated_at=$2 WHERE id=$3', [active, now(), p.id]);
    await audit(db(), 'plan_toggled', `Plano ${p.name} ${active ? 'ativado' : 'pausado'}`, { actorId: a.id });
    return { ok: true, active };
  });

  r.post('/api/admin/images', async (req) => {
    requireAdmin(req);
    const buf = req.rawBody;
    if (!buf || buf.length < 100 || buf.length > 5 * 1024 * 1024) throw bad('Imagem inválida (máximo 5 MB).');
    const isJpeg = buf[0] === 0xff && buf[1] === 0xd8;
    const isPng = buf[0] === 0x89 && buf[1] === 0x50;
    const isWebp = buf.slice(8, 12).toString() === 'WEBP';
    if (!isJpeg && !isPng && !isWebp) throw bad('Formato não suportado (JPEG, PNG ou WebP).');
    const key = `plans/${crypto.randomBytes(10).toString('hex')}.${isJpeg ? 'jpg' : isPng ? 'png' : 'webp'}`;
    fs.mkdirSync(path.join(config.uploadsDir, 'plans'), { recursive: true });
    fs.writeFileSync(path.join(config.uploadsDir, key), buf);
    return { imageKey: key, imageUrl: `/uploads/${key}` };
  });

  // ---------- Pagamentos ----------
  r.get('/api/admin/payments', async (req) => {
    requireAdmin(req);
    await subs.expireDue();
    const st = req.query.get('status');
    const rows = await db().query(
      `SELECT p.*, s.plan_name, u.name AS client_name, u.code AS client_code FROM payments p
       JOIN subscriptions s ON s.id=p.subscription_id JOIN users u ON u.id=p.user_id
       ${st ? 'WHERE p.status=$1' : ''} ORDER BY p.id DESC LIMIT 500`, st ? [st] : []);
    return { payments: rows.map((p) => ({ ...subs.paymentView(p), clientId: p.user_id, clientName: p.client_name, clientCode: p.client_code, planName: p.plan_name })) };
  });
  r.post('/api/admin/payments/:id/sync', async (req) => {
    const a = requireAdmin(req);
    const p = (await db().query('SELECT * FROM payments WHERE id=$1', [int(req.params.id)]))[0];
    if (!p) throw notFound();
    if (!p.provider_payment_id) throw bad('Este pagamento não chegou a ser criado no Mercado Pago.');
    await subs.syncPaymentFromProvider(p.provider_payment_id, { actorId: a.id, source: 'sincronização manual' });
    const np = (await db().query('SELECT * FROM payments WHERE id=$1', [p.id]))[0];
    return { payment: subs.paymentView(np) };
  });
  r.post('/api/admin/payments/:id/reconcile', async (req) => {
    const a = requireAdmin(req);
    await subs.reconcilePayment(a, int(req.params.id), req.body?.note);
    return { ok: true };
  });

  // ---------- Configurações ----------
  r.get('/api/admin/settings', async (req) => {
    requireAdmin(req);
    const token = await mpAccessToken();
    return {
      mpConfigured: !!token, mpTestMode: token.startsWith('TEST-'), mpTokenHint: token ? `${token.slice(0, 8)}…${token.slice(-4)}` : null,
      mpTokenFromEnv: !!config.mpAccessToken,
      webhookSecretConfigured: !!(config.mpWebhookSecret || (await getSetting('mpWebhookSecret'))),
      webhookUrl: `${config.appUrl}/api/webhooks/mercadopago`,
      supportWhatsapp: (await getSetting('supportWhatsapp')) || '',
      pixExpirationMinutes: Number(await getSetting('pixExpirationMinutes')),
      firstPaymentHours: Number(await getSetting('firstPaymentHours')),
      firstPaymentPresets: FIRST_PAYMENT_PRESETS, firstPaymentDefaultHours: DEFAULTS.firstPaymentHours,
      redemptionExpirationMinutes: Number(await getSetting('redemptionExpirationMinutes')),
      termsVersion: String(await getSetting('termsVersion')),
    };
  });
  r.put('/api/admin/settings', async (req) => {
    const a = requireOwner(req);
    const b = req.body || {};
    const changed = [];
    if (b.mpAccessToken !== undefined) {
      const t = String(b.mpAccessToken).trim();
      if (!/^(APP_USR|TEST)-[\w-]{20,}$/.test(t)) throw bad('Access Token inválido (deve começar com APP_USR- ou TEST-).');
      await setSetting('mpAccessToken', t, a.id); changed.push('Access Token do Mercado Pago');
    }
    if (b.mpWebhookSecret !== undefined) {
      const s = String(b.mpWebhookSecret).trim();
      if (s.length < 16) throw bad('Assinatura secreta inválida.');
      await setSetting('mpWebhookSecret', s, a.id); changed.push('assinatura do webhook');
    }
    if (b.clearWebhookSecret) { await setSetting('mpWebhookSecret', null, a.id); changed.push('assinatura do webhook removida'); }
    if (b.supportWhatsapp !== undefined) { await setSetting('supportWhatsapp', String(b.supportWhatsapp).replace(/\D/g, '').slice(0, 13), a.id); changed.push('WhatsApp de atendimento'); }
    if (b.pixExpirationMinutes !== undefined) {
      const m = int(b.pixExpirationMinutes);
      if (m < 5 || m > 1440) throw bad('Validade do Pix deve ficar entre 5 e 1440 minutos.');
      await setSetting('pixExpirationMinutes', m, a.id); changed.push('validade do Pix');
    }
    if (b.firstPaymentHours !== undefined) {
      const h = int(b.firstPaymentHours);
      if (h < 1 || h > 720) throw bad('Prazo deve ficar entre 1 e 720 horas.');
      await setSetting('firstPaymentHours', h, a.id); changed.push('prazo da primeira parcela');
    }
    if (b.redemptionExpirationMinutes !== undefined) {
      const m = int(b.redemptionExpirationMinutes);
      if (m < 5 || m > 1440) throw bad('Validade da cobrança de resgate deve ficar entre 5 e 1440 minutos.');
      await setSetting('redemptionExpirationMinutes', m, a.id); changed.push('validade das cobranças de resgate');
    }
    if (changed.length) await audit(db(), 'settings_updated', `Configurações alteradas: ${changed.join(', ')}`, { actorId: a.id });
    return { ok: true };
  });
  r.post('/api/admin/settings/test', async (req) => {
    requireAdmin(req);
    return { account: await mp.testCredentials() };
  });

  // ---------- IVT COIN (admin) ----------
  const clientInfo = async (ids) => {
    if (!ids.length) return {};
    const rows = await db().query(`SELECT id, name, code FROM users WHERE id IN (${ids.map((_, i) => `$${i + 1}`).join(',')})`, ids);
    return Object.fromEntries(rows.map((u) => [u.id, u]));
  };
  const withClients = async (rows) => {
    const info = await clientInfo([...new Set(rows.map((e) => e.user_id))]);
    return rows.map((e) => coins.txView(e, { clientName: info[e.user_id]?.name, clientCode: info[e.user_id]?.code }));
  };
  r.post('/api/coins/admin/grant', async (req) => {
    const a = requireAdmin(req);
    if (req.body?.ruleId) throw bad('Regras automáticas de distribuição ainda não foram reconstruídas. Informe a quantidade manualmente.');
    const x = await coins.grant(a, { userId: int(req.body?.userId), amount: req.body?.amount, note: req.body?.note, idempotencyKey: req.body?.idempotencyKey });
    return { ok: true, duplicate: x.duplicate, transaction: coins.txView(x.entry) };
  });
  r.post('/api/coins/admin/debit', async (req) => {
    const a = requireAdmin(req);
    const x = await coins.adminDebit(a, { userId: int(req.body?.userId), amount: req.body?.amount, note: req.body?.note, destination: req.body?.destination, idempotencyKey: req.body?.idempotencyKey });
    return { ok: true, duplicate: x.duplicate, transaction: coins.txView(x.entry) };
  });
  r.get('/api/coins/admin/transactions', async (req) => {
    requireAdmin(req);
    const params = [];
    let sql = 'SELECT * FROM coin_ledger WHERE 1=1';
    const kinds = (req.query.get('kind') || req.query.get('type') || '').split(',').filter(Boolean);
    if (kinds.length) { sql += ` AND kind IN (${kinds.map((k) => { params.push(k); return `$${params.length}`; }).join(',')})`; }
    const from = req.query.get('from'), to = req.query.get('to');
    if (from) { params.push(from); sql += ` AND created_at >= $${params.length}`; }
    if (to) { params.push(`${to}T23:59:59.999Z`); sql += ` AND created_at <= $${params.length}`; }
    sql += ' ORDER BY id DESC LIMIT 500';
    return { transactions: await withClients(await db().query(sql, params)) };
  });
  r.get('/api/coins/admin/clients/:id', async (req) => {
    requireAdmin(req);
    const uid = int(req.params.id);
    const w = await coins.getCoinWallet(db(), uid);
    const rows = await db().query('SELECT * FROM coin_ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 50', [uid]);
    return { wallet: { balance: w.balance, totalEarned: w.total_earned, totalSpent: w.total_spent }, transactions: rows.map((e) => coins.txView(e)), recent: rows.map((e) => coins.txView(e)) };
  });
  r.get('/api/coins/admin/overview', async (req) => {
    requireAdmin(req);
    const sup = await coins.supply();
    const ranking = await db().query(`SELECT w.*, u.name, u.code FROM coin_wallets w JOIN users u ON u.id=w.user_id WHERE w.total_earned > 0 ORDER BY w.balance DESC LIMIT 20`);
    const recent = await db().query('SELECT * FROM coin_ledger ORDER BY id DESC LIMIT 20');
    return {
      supply: sup, ranking: ranking.map((w, i) => ({ position: i + 1, userId: w.user_id, clientName: w.name, clientCode: w.code, balance: w.balance, totalEarned: w.total_earned, totalSpent: w.total_spent })),
      recent: await withClients(recent), coupons: { active: 0, used: 0, usedCents: 0 }, index: { value: 10000, changePct: 0 },
    };
  });
  r.get('/api/coins/admin/conversion-config', async (req) => {
    const a = requireAdmin(req);
    const c = await coins.coinConfig();
    const hist = await db().query(`SELECT a.*, u.name AS actor_name FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id WHERE a.type='coin_conversion_config' ORDER BY a.id DESC LIMIT 50`);
    const { configured, conversionEnabled, minConversion, ...config } = c;
    return { config, isOwner: a.role === 'owner', audit: hist.map((h) => ({ id: h.id, action: 'Configuração', note: h.message, message: h.message, actorName: h.actor_name, createdAt: h.created_at })), history: [] };
  });
  r.put('/api/coins/admin/conversion-config', async (req) => {
    const a = requireOwner(req);
    const c = coins.sanitizeConversionConfig(req.body || {});
    if (c.enabled && (!c.rateCoins || !c.rateCents)) throw bad('Para habilitar a conversão, defina a cotação (moedas e valor em centavos).');
    await setSetting('coinConversion', c, a.id);
    await audit(db(), 'coin_conversion_config', `Conversão ${c.enabled ? 'habilitada' : 'desabilitada'}: ${c.rateCoins} IVT = ${c.rateCents} centavos`, { actorId: a.id, meta: c });
    return { ok: true };
  });
  r.get('/api/coins/admin/conversions', async (req) => {
    requireAdmin(req);
    const rows = await db().query(`SELECT * FROM coin_ledger WHERE kind='redeem' ORDER BY id DESC LIMIT 300`);
    const info = await clientInfo([...new Set(rows.map((e) => e.user_id))]);
    return { conversions: rows.map((e) => ({ id: e.id, code: `CNV${e.id}`, coins: -e.amount, userId: e.user_id, clientName: info[e.user_id]?.name, clientCode: info[e.user_id]?.code, createdAt: e.created_at, status: 'completed' })) };
  });
  r.get('/api/coins/admin/audit', async (req) => {
    requireAdmin(req);
    const rows = await db().query(`SELECT a.*, u.name AS actor_name FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id WHERE a.type LIKE 'coin%' ORDER BY a.id DESC LIMIT 300`);
    return { audit: rows.map((h) => ({ id: h.id, action: h.type, message: h.message, actorName: h.actor_name, createdAt: h.created_at })) };
  });

  // ---------- Integridade (auditoria de saldos) ----------
  r.get('/api/admin/integrity', async (req) => {
    requireAdmin(req);
    const walletDiffs = await wallet.reconcileWallets(db());
    const coinDiffs = await db().query(`SELECT w.user_id, w.balance, COALESCE(SUM(l.amount),0) AS ledger FROM coin_wallets w LEFT JOIN coin_ledger l ON l.user_id=w.user_id GROUP BY w.user_id, w.balance HAVING w.balance <> COALESCE(SUM(l.amount),0)`);
    const subDiffs = await db().query(`SELECT s.id, s.paid_cents, COALESCE(SUM(p.amount_cents),0) AS approved FROM subscriptions s LEFT JOIN payments p ON p.subscription_id=s.id AND p.status='approved' GROUP BY s.id, s.paid_cents HAVING s.paid_cents <> COALESCE(SUM(p.amount_cents),0)`);
    return { ok: !walletDiffs.length && !coinDiffs.length && !subDiffs.length, walletDiffs, coinDiffs, subscriptionDiffs: subDiffs, checkedAt: now() };
  });
}
