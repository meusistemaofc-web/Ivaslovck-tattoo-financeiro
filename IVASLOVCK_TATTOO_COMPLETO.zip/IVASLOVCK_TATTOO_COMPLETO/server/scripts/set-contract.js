// Define as cláusulas do contrato exibidas na contratação e incrementa a versão dos termos.
// O texto jurídico original não estava no ZIP; o estúdio deve fornecer o seu.
// Uso: npm run set-contract -- caminho/para/clausulas.txt
//  (na VPS: docker compose cp clausulas.txt app:/tmp/c.txt && docker compose exec app npm run set-contract -- /tmp/c.txt)
import fs from 'node:fs';
import { initDb, db, closeDb } from '../src/db.js';
import { getSetting, setSetting, audit } from '../src/services/settings.js';

const file = process.argv[2];
if (!file || !fs.existsSync(file)) { console.error('Informe o arquivo .txt com as cláusulas.'); process.exit(1); }
const text = fs.readFileSync(file, 'utf8').trim();
await initDb();
const v = String((Number(await getSetting('termsVersion')) || 1) + 1);
await setSetting('contractClauses', text, null);
await setSetting('termsVersion', v, null);
await audit(db(), 'terms_updated', `Cláusulas do contrato atualizadas (versão ${v})`, {});
console.log(`Contrato atualizado para a versão ${v}. Novas contratações exigirão aceite desta versão.`);
await closeDb();
