# Relatório Financeiro e de Integridade — IVASLOVCK Tattoo Club

## 1. Princípios
1. **O frontend nunca altera saldo.** Não existe rota que receba "valor de saldo" do navegador. Todo crédito nasce de uma confirmação consultada pelo servidor no Mercado Pago; todo débito nasce de uma cobrança de resgate autorizada.
2. **Livro-razão imutável.** Toda movimentação vira uma linha nova; o banco bloqueia `UPDATE` e `DELETE` por trigger em `wallet_ledger`, `coin_ledger`, `credit_releases` e `audit_log`.
3. **Reais e IVT COIN separados.** Tabelas, saldos e históricos independentes. Não há conversão automática.
4. **Transações atômicas e travamento.** Cada operação roda em uma transação do banco com `SELECT ... FOR UPDATE` na linha da carteira/pagamento/contratação.
5. **Idempotência.** Toda movimentação tem chave única (`idempotency_key UNIQUE`). Repetir a mesma operação devolve o resultado anterior em vez de duplicar.
6. **Correções sem apagar.** Divergências vão para "conciliação" ou ajuste auditável; nada é excluído.

## 2. Modelo de dados (resumo)
| Tabela | Função |
|---|---|
| `plans` | Catálogo de planos (valores em centavos) |
| `subscriptions` | Contratação com **snapshot** das condições (editar o plano não altera contratos em andamento). `CHECK paid_cents BETWEEN 0 AND total_cents`; índice único impede 2 contratações abertas por cliente |
| `payments` | Cobranças Pix: `UNIQUE(provider_payment_id)`, `UNIQUE(user_id, idempotency_key)`, flag `applied` |
| `webhook_events` | Toda notificação recebida, com resultado da validação de assinatura |
| `wallets` | Saldo em reais por balde (`plan`, `gift`, `conversion`). `CHECK >= 0` em cada balde e `CHECK balance = soma dos baldes` |
| `wallet_ledger` | Livro-razão imutável dos reais (`balance_after >= 0`) |
| `credit_releases` | Uma liberação por contratação (`subscription_id UNIQUE`) |
| `redemptions` | Cobranças de resgate (pendente/confirmada/recusada/cancelada/expirada) |
| `coin_wallets` / `coin_ledger` | IVT COIN — saldo e livro-razão próprios, imutáveis |
| `cards` / `card_models` | Cartões digitais internos (usam o saldo da carteira) |
| `audit_log` | Auditoria administrativa imutável |

## 3. Fluxo do dinheiro (Pix)
1. Cliente pede pagamento → servidor valida mínimo/máximo, status do plano e Pix pendentes, **reserva** um registro `pending` e só então chama o Mercado Pago com `X-Idempotency-Key = ivs-payment-<id>` e `external_reference = ivs-payment-<id>`.
2. Retentativa/duplo clique com a mesma chave → mesmo Pix (sem segunda cobrança).
3. Confirmação chega por **webhook**, consulta periódica da tela ou "Sincronizar" no painel. Em todos os casos o servidor faz `GET /v1/payments/{id}` e só aplica se:
   - status `approved`;
   - `external_reference` aponta para um pagamento interno existente e o ID do provedor confere;
   - valor pago == valor cobrado.
4. Aplicação (uma transação): pagamento → `approved` + `applied`; contratação → soma `paid_cents`, ativa na 1ª parcela; ao atingir o total → `completed` e **crédito liberado** no livro-razão com chave `release:subscription:<id>`.
5. Casos de exceção → **`reconciliation`** (não credita, avisa o painel): valor divergente; pago após cancelamento; pagamento que ultrapassaria o total do plano.
6. Estorno no Mercado Pago depois de creditado → registrado em auditoria e notificado ao estúdio; **o saldo não é alterado automaticamente** (decisão humana com ajuste auditável).
7. Webhook: assinatura `x-signature` validada (HMAC-SHA256) quando o segredo está configurado; assinatura inválida → 401.
8. Pix vencidos são reconsultados no provedor antes de serem marcados como expirados (pagamento no último minuto não se perde).

## 4. Uso do crédito (débito)
- Cobrança de resgate criada pelo estúdio **reserva** saldo (soma das pendentes não pode exceder o saldo).
- Confirmação pelo app do cliente ou pelo código de 8 caracteres; débito com chave `redemption:<id>`, consumindo Cartão Presente → conversão IVT → crédito de plano.
- Confirmação simultânea (app + código) debita uma única vez (testado).

## 5. IVT COIN
- Distribuição e débito manuais pelo painel, com motivo e chave de idempotência.
- Débito escolhe destino: retorno ao estoque ou retirada de circulação.
- **Conversão em saldo**: desligada por padrão. Só funciona após o dono definir cotação (ex.: 100 IVT = R$ 1,00) e habilitar. A conversão grava, na mesma transação, o débito em moedas e o crédito no balde `conversion` dos reais, com referência cruzada e registro da cotação usada. Limites diário/semanal/mensal, mínimo, múltiplo e máximo por operação são aplicados.
- Não reconstruído: regras automáticas de ganho, índice de valorização, cupons (o índice aparece fixo em 1,0000 e não altera nada).

## 6. Painel financeiro — separação de valores
| Indicador | Origem |
|---|---|
| Valores recebidos | Somente Pix `approved` (dinheiro confirmado) |
| Pendentes | Pix `pending` (ainda não é receita) |
| Em conciliação | Pix pagos que exigem decisão (não creditados) |
| Créditos liberados | Soma de `credit_releases` (obrigação do estúdio) |
| Créditos utilizados | Resgates confirmados |
| Saldo em carteiras | Soma dos saldos atuais |
| Valor contratado | Total dos planos ativos/quitados |
| IVT COIN | Em tela própria, **nunca** somada a receita |

## 7. Segurança
Senhas com scrypt; sessão em cookie HttpOnly/Secure/SameSite=Lax (token guardado apenas como hash); limite de tentativas de login; bloqueio de requisições de outra origem; controle de acesso por papel (`client`, `admin`, `owner`); configurações sensíveis (token do Mercado Pago) somente pelo `owner`; token salvo pelo painel é **criptografado (AES-256-GCM)** com `APP_SECRET`; variáveis de ambiente têm prioridade.

## 8. Divergências e migração de dados antigos
- `GET /api/admin/integrity` e `npm run integrity` comparam saldos × livros-razão, moedas × livro-razão e parcelas pagas × Pix aprovados. **Não corrigem nada** — apenas listam.
- Se houver dados da Netlify a importar: importar como lançamentos no livro-razão (um por saldo inicial, com descrição "Saldo migrado da plataforma anterior" e referência ao registro de origem), rodar a verificação e documentar qualquer diferença antes de liberar o sistema.
