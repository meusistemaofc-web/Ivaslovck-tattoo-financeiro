#!/usr/bin/env bash
# Atualiza o sistema após substituir os arquivos por uma versão nova (o banco e as fotos são preservados).
set -euo pipefail
cd "$(dirname "$0")/../.."
bash deploy/scripts/backup.sh
docker compose up -d --build
sleep 5
PORTA=$(grep '^APP_PORT=' .env | cut -d= -f2); PORTA=${PORTA:-3000}
curl -fsS "http://127.0.0.1:$PORTA/api/health" && echo " — atualizado"
