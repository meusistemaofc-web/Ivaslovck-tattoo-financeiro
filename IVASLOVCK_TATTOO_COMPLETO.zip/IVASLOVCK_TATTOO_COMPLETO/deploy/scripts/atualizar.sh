#!/usr/bin/env bash
# Atualiza o sistema após substituir os arquivos por uma versão nova (o banco e as fotos são preservados).
set -euo pipefail
cd "$(dirname "$0")/../.."
bash deploy/scripts/backup.sh
docker compose up -d --build
sleep 5
curl -fsS http://127.0.0.1:3000/api/health && echo " — atualizado"
