import crypto from 'node:crypto';
import { db } from '../db.js';
import { bad, conflict, notFound } from '../http.js';
import { requireAdmin } from '../auth.js';
import { audit, notify } from '../services/settings.js';
import * as wallet from '../services/wallet.js';

export function cardView(c, extra = {}) {
  const today = new Date().toISOString().slice(0, 10);
  return {
    id: c.id, userId: c.user_id, model: { id: c.model_id, code: c.model_code, name: c.model_name },
    holderName: c.holder_name, identifier: c.identifier, maskedIdentifier: `IVK •••• •••• ${c.last4}`, last4: c.last4,
    expiresOn: c.expires_on, expired: !!(c.expires_on && c.expires_on < today), status: c.status, blockedBy: c.blocked_by,
    issuedAt: c.issued_at, issuedByName: c.issued_by_name, issueKind: 'admin', clientId: c.user_id,
    clientName: c.client_name, clientCode: c.client_code, ...extra,
  };
}

function modelView(m, counts = {}) {
  return {
    id: m.id, code: m.code, name: m.name, description: m.description || '', eligibility: m.eligibility,
    minCreditCents: m.min_credit_cents, active: m.active === true || m.active === 1, updatedAt: m.updated_at,
    issuedActive: counts.active || 0, issuedBlocked: counts.blocked || 0,
  };
}

async function eligibility(model, userId) {
  if (model.eligibility === 'all') return { eligible: true, reason: null };
  if (model.eligibility === 'completed_plan') {
    const r = await db().query(`SELECT id FROM subscriptions WHERE user_id=$1 AND status='completed' LIMIT 1`, [userId]);
    return r.length ? { eligible: true, reason: null } : { eligible: false, reason: 'O cliente ainda não quitou nenhum plano.' };
  }
  const r = await db().query('SELECT COALESCE(SUM(amount_cents),0) AS c FROM credit_releases WHERE user_id=$1', [userId]);
  const total = Number(r[0].c);
  return total >= model.min_credit_cents
    ? { eligible: true, reason: null }
    : { eligible: false, reason: `Créditos liberados abaixo do mínimo exigido por este modelo.` };
}

export default function register(r) {
  r.get('/api/admin/card-models', async (req) => {
    requireAdmin(req);
    const models = await db().query('SELECT * FROM card_models ORDER BY sort_order, id');
    const counts = await db().query(`SELECT model_id, status, COUNT(*) AS c FROM cards GROUP BY model_id, status`);
    return {
      models: models.map((m) => {
        const c = {};
        counts.filter((x) => x.model_id === m.id).forEach((x) => { c[x.status] = Number(x.c); });
        return modelView(m, c);
      }),
    };
  });
  r.put('/api/admin/card-models/:id', async (req) => {
    const a = requireAdmin(req);
    const b = req.body || {};
    const m = (await db().query('SELECT * FROM card_models WHERE id=$1', [Number(req.params.id) || 0]))[0];
    if (!m) throw notFound();
    const elig = ['all', 'completed_plan', 'min_credit'].includes(b.eligibility) ? b.eligibility : m.eligibility;
    const minC = Math.max(0, Number(b.minCreditCents) || 0);
    const name = String(b.name ?? m.name).trim() || m.name;
    await db().query('UPDATE card_models SET name=$1, description=$2, eligibility=$3, min_credit_cents=$4, updated_at=$5 WHERE id=$6',
      [name.slice(0, 60), String(b.description ?? m.description ?? '').slice(0, 500), elig, minC, new Date().toISOString(), m.id]);
    await audit(db(), 'card_model_updated', `Modelo de cartão ${name} atualizado`, { actorId: a.id });
    return { ok: true };
  });
  r.post('/api/admin/card-models/:id/toggle', async (req) => {
    const a = requireAdmin(req);
    const m = (await db().query('SELECT * FROM card_models WHERE id=$1', [Number(req.params.id) || 0]))[0];
    if (!m) throw notFound();
    const active = !(m.active === true || m.active === 1);
    await db().query('UPDATE card_models SET active=$1, updated_at=$2 WHERE id=$3', [active, new Date().toISOString(), m.id]);
    await audit(db(), 'card_model_toggled', `Modelo ${m.name} ${active ? 'ativado' : 'desativado'}`, { actorId: a.id });
    return { ok: true, active };
  });
  r.get('/api/admin/card-models/:id/eligibility', async (req) => {
    requireAdmin(req);
    const m = (await db().query('SELECT * FROM card_models WHERE id=$1', [Number(req.params.id) || 0]))[0];
    if (!m) throw notFound();
    return eligibility(m, Number(req.query.get('userId')) || 0);
  });

  r.get('/api/admin/cards', async (req) => {
    requireAdmin(req);
    const params = [];
    let sql = `SELECT c.*, m.code AS model_code, m.name AS model_name, u.name AS client_name, u.code AS client_code
               FROM cards c JOIN card_models m ON m.id=c.model_id JOIN users u ON u.id=c.user_id WHERE 1=1`;
    const st = req.query.get('status'), mid = req.query.get('modelId'), q = (req.query.get('q') || '').trim();
    if (st) { params.push(st); sql += ` AND c.status=$${params.length}`; }
    if (mid) { params.push(Number(mid)); sql += ` AND c.model_id=$${params.length}`; }
    if (q) { params.push(`%${q.toLowerCase()}%`); sql += ` AND (LOWER(u.name) LIKE $${params.length} OR LOWER(u.code) LIKE $${params.length} OR LOWER(c.identifier) LIKE $${params.length})`; }
    sql += ' ORDER BY c.id DESC LIMIT 300';
    const rows = await db().query(sql, params);
    const out = [];
    for (const c of rows) out.push(cardView(c, { balanceCents: (await wallet.getWallet(db(), c.user_id)).balance_cents }));
    return { cards: out };
  });

  r.post('/api/admin/cards', async (req) => {
    const a = requireAdmin(req);
    const { userId, modelId, validityMonths } = req.body || {};
    const m = (await db().query('SELECT * FROM card_models WHERE id=$1', [Number(modelId) || 0]))[0];
    if (!m || !(m.active === true || m.active === 1)) throw bad('Modelo de cartão indisponível.');
    const u = (await db().query(`SELECT * FROM users WHERE id=$1 AND role='client'`, [Number(userId) || 0]))[0];
    if (!u) throw notFound('Cliente não encontrado.');
    const el = await eligibility(m, u.id);
    if (!el.eligible) throw conflict(el.reason);
    const dupe = await db().query(`SELECT id FROM cards WHERE user_id=$1 AND model_id=$2 AND status <> 'cancelled'`, [u.id, m.id]);
    if (dupe.length) throw conflict('O cliente já possui um cartão ativo deste modelo.');
    const months = Math.max(0, Math.min(120, Number(validityMonths) || 0));
    let expires = null;
    if (months > 0) { const d = new Date(); d.setUTCMonth(d.getUTCMonth() + months); expires = d.toISOString().slice(0, 10); }
    const digits = Array.from(crypto.randomBytes(12), (b) => String(b % 10)).join('');
    const identifier = `IVK ${digits.slice(0, 4)} ${digits.slice(4, 8)} ${digits.slice(8, 12)}`;
    const rows = await db().query(
      `INSERT INTO cards (user_id, model_id, identifier, last4, holder_name, status, expires_on, issued_at, issued_by, issued_by_name)
       VALUES ($1,$2,$3,$4,$5,'active',$6,$7,$8,$9) RETURNING *`,
      [u.id, m.id, identifier, digits.slice(8, 12), u.name.toUpperCase().slice(0, 26), expires, new Date().toISOString(), a.id, a.name]);
    await audit(db(), 'card_issued', `Cartão ${m.name} emitido para ${u.name}`, { userId: u.id, actorId: a.id });
    await notify(db(), u.id, 'Novo cartão digital', `Seu cartão ${m.name} foi emitido.`, '/creditos', 'card');
    return { card: { id: rows[0].id } };
  });

  r.post('/api/admin/cards/:id/:action', async (req) => {
    const a = requireAdmin(req);
    const { action } = req.params;
    if (!['block', 'unblock'].includes(action)) throw notFound();
    const c = (await db().query('SELECT * FROM cards WHERE id=$1', [Number(req.params.id) || 0]))[0];
    if (!c || c.status === 'cancelled') throw notFound('Cartão não encontrado.');
    await db().query('UPDATE cards SET status=$1, blocked_by=$2 WHERE id=$3', [action === 'block' ? 'blocked' : 'active', action === 'block' ? 'admin' : null, c.id]);
    await audit(db(), action === 'block' ? 'card_blocked' : 'card_unblocked', `Cartão final ${c.last4} ${action === 'block' ? 'bloqueado' : 'desbloqueado'} pelo estúdio`, { userId: c.user_id, actorId: a.id });
    return { ok: true };
  });
  r.post('/api/credit/admin/cards/:id/cancel', async (req) => {
    const a = requireAdmin(req);
    const c = (await db().query('SELECT * FROM cards WHERE id=$1', [Number(req.params.id) || 0]))[0];
    if (!c || c.status === 'cancelled') throw notFound('Cartão não encontrado.');
    const reason = String(req.body?.reason || '').slice(0, 300);
    await db().query(`UPDATE cards SET status='cancelled', cancelled_at=$1, cancel_reason=$2 WHERE id=$3`, [new Date().toISOString(), reason, c.id]);
    await audit(db(), 'card_cancelled', `Cartão final ${c.last4} cancelado${reason ? `: ${reason}` : ''}`, { userId: c.user_id, actorId: a.id });
    return { ok: true };
  });
}
