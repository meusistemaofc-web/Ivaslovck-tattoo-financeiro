import { db } from '../db.js';
import { config } from '../config.js';
import { requireClient, requireAdmin, requireOwner } from '../auth.js';
import { bad } from '../http.js';
import * as ref from '../services/referrals.js';

const n = (v) => Number(v || 0);
const baseUrl = (req) => (config.appUrl || (req.headers.origin ?? '') || `http://${req.headers.host || 'localhost'}`).replace(/\/$/, '');
const initialName = (full) => { const p = String(full).trim().split(/\s+/); return p.length > 1 ? `${p[0]} ${p[p.length - 1][0]}.` : p[0]; };
const flagsOf = (r) => { try { return JSON.parse(r.flags || '[]'); } catch { return []; } };

export default function register(r) {
  // Acesso ao link: valida o código e conta o visitante (público).
  r.post('/api/referrals/visit', async (req) => {
    const code = req.body?.code;
    if (typeof code !== 'string') throw bad('Código inválido.');
    return ref.trackVisit(code, req.ip, req.headers['user-agent']);
  });

  r.get('/api/referrals/me', async (req) => {
    const u = requireClient(req);
    const cfg = await ref.getConfig();
    const camp = await ref.activeCampaign();
    const rows = await db().query(
      `SELECT r.*, d.name AS referred_name FROM referrals r JOIN users d ON d.id=r.referred_id WHERE r.referrer_id=$1 ORDER BY r.id DESC`, [u.id]);
    const sum = (f) => rows.filter(f).reduce((a, x) => a + n(x.reward_coins), 0);
    const visits = n((await db().query('SELECT COUNT(*) AS c FROM referral_visits WHERE code=$1', [u.referral_code]))[0].c);
    const pending = (x) => ['qualified', 'review', 'capped'].includes(x.status);
    return {
      code: u.referral_code,
      link: `${baseUrl(req)}/?ref=${u.referral_code}`,
      program: {
        enabled: cfg.enabled, rewardCoins: cfg.rewardCoins, criterionText: ref.CRITERIA[cfg.criterion],
        confirmationDays: cfg.confirmationDays, maxRewardsPerPeriod: cfg.maxRewardsPerPeriod, rewardPeriod: cfg.rewardPeriod,
        campaign: camp ? { name: camp.name, rewardCoins: n(camp.reward_coins), endsAt: camp.ends_at } : null,
      },
      stats: {
        signups: rows.length, visits, pending: rows.filter(pending).length, approved: rows.filter((x) => x.status === 'approved').length,
        coinsEarned: rows.filter((x) => x.status === 'approved').reduce((a, x) => a + n(x.paid_coins), 0), pendingCoins: sum(pending),
      },
      referrals: rows.map((x) => ({
        id: n(x.id), name: initialName(x.referred_name), createdAt: x.created_at, status: x.status, statusText: ref.STATUS_TEXT[x.status],
        releaseAt: x.status === 'qualified' ? x.release_at : null,
      })),
      rewards: rows.filter((x) => x.status === 'approved').map((x) => ({ id: n(x.id), name: initialName(x.referred_name), at: x.approved_at, coins: n(x.paid_coins) })),
    };
  });

  // ---------- administração ----------
  r.get('/api/referrals/admin/overview', async (req) => {
    const a = requireAdmin(req);
    const cfg = await ref.getConfig();
    const rows = await db().query(
      `SELECT r.*, rr.name AS referrer_name, rr.code AS referrer_code, d.name AS referred_name, d.code AS referred_code, d.whatsapp AS referred_whatsapp
       FROM referrals r JOIN users rr ON rr.id=r.referrer_id JOIN users d ON d.id=r.referred_id ORDER BY r.id DESC LIMIT 500`);
    const count = (s) => rows.filter((x) => x.status === s).length;
    const visits = n((await db().query('SELECT COUNT(*) AS c FROM referral_visits'))[0].c);
    const top = {};
    for (const x of rows) {
      const t = (top[x.referrer_id] ||= { userId: n(x.referrer_id), name: x.referrer_name, clientCode: x.referrer_code, signups: 0, approved: 0, coins: 0 });
      t.signups++; if (x.status === 'approved') { t.approved++; t.coins += n(x.paid_coins); }
    }
    const campaigns = await db().query('SELECT * FROM referral_campaigns ORDER BY id DESC');
    return {
      isOwner: a.role === 'owner', config: cfg, criteria: ref.CRITERIA,
      totals: {
        visits, signups: rows.length, awaiting: count('registered'), qualified: count('qualified'), review: count('review'), capped: count('capped'),
        approved: count('approved'), rejected: count('rejected'), expired: count('expired'),
        coins: rows.reduce((s, x) => s + n(x.paid_coins), 0), flagged: rows.filter((x) => flagsOf(x).length).length,
      },
      top: Object.values(top).sort((p, q) => q.approved - p.approved || q.signups - p.signups).slice(0, 10),
      referrals: rows.map((x) => ({
        id: n(x.id), code: x.code, referrerId: n(x.referrer_id), referrerName: x.referrer_name, referrerCode: x.referrer_code,
        referredId: n(x.referred_id), referredName: x.referred_name, referredCode: x.referred_code, referredWhatsapp: x.referred_whatsapp,
        createdAt: x.created_at, qualifiedAt: x.qualified_at, releaseAt: x.release_at, status: x.status, statusText: ref.STATUS_TEXT[x.status],
        note: x.note, rewardCoins: n(x.reward_coins), paidCoins: n(x.paid_coins), campaign: x.campaign_name, rewardTxId: x.ledger_id == null ? null : n(x.ledger_id), flags: flagsOf(x),
      })),
      campaigns: campaigns.map(ref.campaignView),
    };
  });

  r.put('/api/referrals/admin/config', async (req) => ({ config: await ref.saveConfig(requireOwner(req), req.body) }));
  r.post('/api/referrals/admin/campaigns', async (req) => ({ campaign: ref.campaignView(await ref.createCampaign(requireOwner(req), req.body || {})) }));
  r.post('/api/referrals/admin/campaigns/:id', async (req) => { await ref.toggleCampaign(requireOwner(req), Number(req.params.id)); return { ok: true }; });
  r.post('/api/referrals/admin/approve/:id', async (req) => ref.adminDecide(requireOwner(req), Number(req.params.id), true));
  r.post('/api/referrals/admin/reject/:id', async (req) => {
    const reason = String(req.body?.reason || '').trim();
    if (!reason) throw bad('Informe o motivo da rejeição.');
    return ref.adminDecide(requireOwner(req), Number(req.params.id), false, reason);
  });
}
