// Redefine a senha de um cliente (ou administrador) a pedido dele, por exemplo via WhatsApp do estúdio.
// O app não tem recuperação automática por e-mail: a tela orienta o cliente a falar com o estúdio.
// Gera uma senha temporária aleatória, encerra todas as sessões abertas dessa conta e registra na auditoria.
// Uso: npm run reset-password -- 11999998888        (WhatsApp com DDD)   ou   npm run reset-password -- cliente@email.com
//  (na VPS: docker compose exec app npm run reset-password -- 11999998888)
// A senha nunca é aceita na linha de comando (ficaria gravada no histórico do terminal).
import crypto from 'node:crypto';
import { initDb, db, closeDb } from '../src/db.js';
import { hashPassword } from '../src/auth.js';
import { audit } from '../src/services/settings.js';

const id = String(process.argv[2] || '').trim();
if (!id) { console.error('Informe o WhatsApp (com DDD) ou o e-mail da conta.'); process.exit(1); }
await initDb();
const digits = id.replace(/\D/g, '');
const rows = id.includes('@')
  ? await db().query('SELECT id, name, role, email, whatsapp FROM users WHERE LOWER(email)=$1', [id.toLowerCase()])
  : await db().query('SELECT id, name, role, email, whatsapp FROM users WHERE whatsapp=$1', [digits.replace(/^55(\d{10,11})$/, '$1')]);
if (rows.length !== 1) { console.error('Conta não encontrada. Confira o WhatsApp (com DDD) ou o e-mail.'); await closeDb(); process.exit(1); }
const u = rows[0];
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
const temp = Array.from(crypto.randomBytes(12), (b) => alphabet[b % alphabet.length]).join('');
await db().tx(async (t) => {
  await t.query('UPDATE users SET password_hash=$1, updated_at=$2 WHERE id=$3', [await hashPassword(temp), new Date().toISOString(), u.id]);
  await t.query('DELETE FROM sessions WHERE user_id=$1', [u.id]);
  await audit(t, 'password_reset_cli', `Senha redefinida pelo estúdio para ${u.name} (${u.role})`, { userId: u.id });
});
console.log(`Conta: ${u.name} (${u.role})`);
console.log(`Senha temporária: ${temp}`);
console.log('Todas as sessões abertas dessa conta foram encerradas. Envie a senha ao titular por um canal seguro.');
await closeDb();
