# Guia de Instalação na VPS Hostinger — IVASLOVCK Tattoo Club

Escrito para quem tem pouca experiência com servidores. Copie e cole os comandos exatamente como estão.

## O que você vai precisar
- VPS Hostinger com **Ubuntu 22.04 ou 24.04** (mínimo 1 vCPU, 2 GB RAM).
- Um **domínio** (obrigatório para HTTPS e para o webhook do Mercado Pago).
- Credenciais do Mercado Pago (Access Token e assinatura do webhook).

## Passo 1 — Apontar o domínio para a VPS
No painel onde o domínio foi comprado, crie dois registros **A**:
- `@` → IP da VPS
- `www` → IP da VPS

O IP aparece no hPanel em *VPS › Visão geral*. A propagação pode levar de minutos a algumas horas.

## Passo 2 — Entrar no servidor
No hPanel: *VPS › Terminal do navegador*, ou no seu computador:
```bash
ssh root@IP_DA_VPS
```

## Passo 3 — Colocar os arquivos na VPS
**Opção A — pelo GitHub** (você sobe o `IVASLOVCK_TATTOO_COMPLETO.zip` inteiro no repositório):
```bash
apt-get update && apt-get install -y git unzip
cd /opt
git clone https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git ivaslovck-repo
cd ivaslovck-repo
unzip IVASLOVCK_TATTOO_COMPLETO.zip -d /opt/
cd /opt/IVASLOVCK_TATTOO_COMPLETO
```
Repositório privado: o GitHub pede usuário e um *token* (Settings › Developer settings › Personal access tokens) no lugar da senha.

**Opção B — enviar o ZIP direto** do seu computador:
```bash
scp IVASLOVCK_TATTOO_COMPLETO.zip root@IP_DA_VPS:/opt/
# depois, na VPS:
cd /opt && apt-get install -y unzip && unzip IVASLOVCK_TATTOO_COMPLETO.zip && cd IVASLOVCK_TATTOO_COMPLETO
```

## Passo 4 — Instalar tudo com um comando
```bash
sudo bash deploy/scripts/instalar.sh
```
O script pergunta o domínio e um e-mail e então:
- instala Docker, Nginx e Certbot;
- configura o firewall;
- gera o `.env` com senhas aleatórias;
- sobe o banco PostgreSQL e o sistema;
- configura o Nginx e o HTTPS;
- agenda backup diário.

No final ele mostra a **chave de configuração do primeiro administrador**. Anote.

Se o HTTPS falhar porque o DNS ainda não propagou, rode depois:
```bash
certbot --nginx -d seudominio.com.br -d www.seudominio.com.br --redirect
```

## Passo 5 — Criar o administrador
1. Acesse `https://seudominio.com.br/admin/entrar`.
2. Preencha nome, WhatsApp, e-mail, senha (mín. 8 caracteres) e a **chave de configuração**.
3. Depois de entrar, desative a chave:
```bash
cd /opt/IVASLOVCK_TATTOO_COMPLETO
sed -i 's/^ADMIN_SETUP_TOKEN=.*/ADMIN_SETUP_TOKEN=/' .env
docker compose up -d
```

## Passo 6 — Configurar o Mercado Pago
1. No Mercado Pago: *Suas integrações › sua aplicação › Credenciais de produção* → copie o **Access Token** (`APP_USR-...`).
2. No painel do sistema: *Configurações › Mercado Pago · Pix* → cole o token → **Testar conexão**.
3. No Mercado Pago: *Webhooks › Configurar notificações*:
   - URL: `https://seudominio.com.br/api/webhooks/mercadopago`
   - Evento: **Pagamentos**
   - Salve e copie a **assinatura secreta**.
4. Cole a assinatura em *Configurações › Webhook* no painel.

Alternativa mais segura: coloque `MP_ACCESS_TOKEN` e `MP_WEBHOOK_SECRET` no `.env` e rode `docker compose up -d`. O `.env` tem prioridade sobre o painel.

## Passo 7 — Cláusulas do contrato
O texto jurídico original não estava no ZIP. Escreva suas cláusulas num arquivo `clausulas.txt` (de preferência revisado por um advogado) e rode:
```bash
docker compose cp clausulas.txt app:/tmp/clausulas.txt
docker compose exec app npm run set-contract -- /tmp/clausulas.txt
```

## Passo 8 — Planos, cartões e IVT COIN
- No painel, cadastre os planos de tatuagem e piercing: valor, contribuições, periodicidade e regras.
- Revise os modelos de cartão (BLACK, GOLD, SILVER) e a elegibilidade de cada um.
- Em *IVT COIN › Conversão*, defina a cotação apenas se quiser liberar a conversão. Ela começa desligada.

## Passo 9 — Validar o banco PostgreSQL (recomendado, uma vez)
Os testes automáticos rodam num banco de **teste**, separado. O banco real não é tocado.
```bash
docker compose exec db createdb -U ivaslovck ivaslovck_test
SENHA=$(grep ^POSTGRES_PASSWORD= .env | cut -d= -f2)
docker compose exec -e TEST_DATABASE_URL=postgres://ivaslovck:$SENHA@db:5432/ivaslovck_test app npm run test:pg
docker compose exec db dropdb -U ivaslovck ivaslovck_test
```
O resultado esperado é `# pass 19` e `# fail 0`.

## Passo 10 — Teste real com o sandbox do Mercado Pago (antes de abrir para clientes)
1. Coloque temporariamente um token **`TEST-...`** no painel. O painel mostra "modo teste".
2. Crie um cliente de teste, contrate um plano barato e gere o Pix.
3. Pague com a conta de teste do Mercado Pago. Confirme que:
   - a tela muda sozinha para "Pagamento realizado!";
   - o pagamento aparece como confirmado no painel.
4. Volte para o token de produção.

## Passo 11 — Manutenção
| Tarefa | Comando (na pasta do projeto) |
|---|---|
| Ver se está no ar | `curl https://seudominio.com.br/api/health` |
| Ver os registros | `docker compose logs -f app` |
| Reiniciar | `docker compose restart app` |
| Backup manual | `bash deploy/scripts/backup.sh` (arquivos em `backups/`) |
| Restaurar backup | `bash deploy/scripts/restaurar.sh backups/banco-XXXX.dump backups/uploads-XXXX.tar.gz` |
| Atualizar para uma versão nova | substitua os arquivos (mantenha o `.env`) e rode `bash deploy/scripts/atualizar.sh` |
| Conferir saldos | `docker compose exec app npm run integrity` |

Copie a pasta `backups/` para fora da VPS de vez em quando (Google Drive, computador).

## Problemas comuns
- **Site não abre**: rode `docker compose ps`. Se `app` não estiver "healthy", veja o erro com `docker compose logs app`.
- **"Configuração inválida: APP_SECRET"**: o `.env` está sem `APP_SECRET`. Gere com `openssl rand -hex 32`.
- **Pix não gera**: o token está ausente ou inválido. Use *Configurações › Testar conexão*.
- **Pix pago mas não confirmou**: confira se a URL do webhook está correta e se o site tem HTTPS. No painel, *Pagamentos › Sincronizar* consulta o Mercado Pago na hora.
- **Tela com "módulo ainda não foi reconstruído"**: comportamento esperado para os módulos listados no relatório de reconstrução.
