import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { config, assertProdConfig } from './config.js';
import { initDb, db, closeDb } from './db.js';
import { Router, HttpError, parseCookies, readBody, sendJson, serveStatic } from './http.js';
import { loadUser } from './auth.js';
import authRoutes from './routes/auth.js';
import meRoutes from './routes/me.js';
import adminRoutes from './routes/admin.js';
import cardRoutes from './routes/cards.js';
import miscRoutes, { notReconstructed } from './routes/misc.js';
import { expireDue } from './services/subscriptions.js';
import { expireRedemptions } from './services/redemptions.js';

export function buildRouter() {
  const r = new Router();
  authRoutes(r); meRoutes(r); adminRoutes(r); cardRoutes(r); miscRoutes(r);
  return r;
}

const SECURITY_HEADERS = {
  'X-Frame-Options': 'SAMEORIGIN',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
};

function clientIp(req) {
  if (config.trustProxy && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim();
  return req.socket.remoteAddress;
}

function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // apps nativos / curl / mesmo-site sem Origin; cookie SameSite=Lax já protege
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  try {
    const o = new URL(origin);
    return o.host === host || origin === config.appUrl;
  } catch { return false; }
}

export function createServer(router = buildRouter()) {
  return http.createServer(async (req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    const url = new URL(req.url, 'http://localhost');
    const pathname = url.pathname;
    try {
      if (pathname.startsWith('/api/')) {
        req.query = url.searchParams;
        req.cookies = parseCookies(req.headers.cookie);
        req.ip = clientIp(req);
        const isWebhook = pathname.startsWith('/api/webhooks/');
        if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && !isWebhook && !originAllowed(req)) {
          throw new HttpError(403, 'Origem da requisição não permitida.');
        }
        const m = router.match(req.method, pathname);
        if (!m) throw notReconstructed(pathname);
        if (m.methodNotAllowed) throw new HttpError(405, 'Método não permitido.');
        req.params = m.params;
        req.body = {};
        if (!['GET', 'HEAD'].includes(req.method)) {
          const raw = await readBody(req, 8 * 1024 * 1024);
          req.rawBody = raw;
          const ct = String(req.headers['content-type'] || '');
          if (raw.length && ct.includes('application/json')) {
            try { req.body = JSON.parse(raw.toString('utf8')); } catch { throw new HttpError(400, 'JSON inválido.'); }
          }
        }
        req.user = await loadUser(req);
        let out;
        for (const h of m.route.handlers) out = await h(req, res);
        if (!res.headersSent) sendJson(res, 200, out ?? { ok: true });
        return;
      }
      if (pathname.startsWith('/uploads/')) {
        const root = path.resolve(config.uploadsDir);
        const file = path.resolve(root, '.' + decodeURIComponent(pathname.slice('/uploads'.length)));
        if (file.startsWith(root) && fs.existsSync(file) && fs.statSync(file).isFile()) {
          const ext = path.extname(file).toLowerCase();
          res.writeHead(200, { 'Content-Type': ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg', 'Cache-Control': 'public, max-age=86400', 'X-Content-Type-Options': 'nosniff' });
          fs.createReadStream(file).pipe(res);
          return;
        }
        res.writeHead(404).end();
        return;
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405).end(); return; }
      if (!serveStatic(req, res, pathname)) { res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Não encontrado'); }
    } catch (e) {
      if (e instanceof HttpError) {
        sendJson(res, e.status, { error: e.message, ...(e.extra || {}) });
      } else if (/CHECK constraint|violates check constraint|saldo/i.test(e.message || '')) {
        // Proteção do banco acionada (ex.: saldo negativo) — nunca é aplicada parcialmente (transação desfeita).
        console.error('[integridade]', e.message);
        sendJson(res, 409, { error: 'Operação recusada pela proteção de integridade financeira.' });
      } else {
        console.error('[erro]', req.method, pathname, e);
        sendJson(res, 500, { error: 'Erro interno. Tente novamente.' });
      }
    }
  });
}

export async function start() {
  assertProdConfig();
  await initDb();
  fs.mkdirSync(config.uploadsDir, { recursive: true });
  const server = createServer();
  await new Promise((r) => server.listen(config.port, config.host, r));
  console.log(`[ivaslovck] servidor em ${config.host}:${config.port} (banco: ${db().kind}, ambiente: ${config.env})`);
  const tick = async () => {
    try { await expireDue(true); await expireRedemptions(); } catch (e) { console.error('[jobs]', e.message); }
  };
  const timer = setInterval(tick, config.jobsIntervalMs);
  timer.unref();
  const stop = async () => { server.close(); await closeDb(); process.exit(0); };
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
  return server;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname)) {
  start().catch((e) => { console.error(e); process.exit(1); });
}
