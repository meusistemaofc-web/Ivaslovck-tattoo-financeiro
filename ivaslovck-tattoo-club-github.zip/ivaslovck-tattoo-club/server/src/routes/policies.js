import { db } from '../db.js';
import { notFound } from '../http.js';
import { requireUser } from '../auth.js';

// Contratos aceitos pelo cliente. Cada contratação guarda o texto exato aceito, a versão dos termos e o hash.
// O código público do contrato é derivado do número da contratação (IVC-000123).
const codeOf = (id) => `IVC-${String(id).padStart(6, '0')}`;
const idOf = (code) => { const m = /^IVC-(\d{1,12})$/.exec(String(code)); return m ? Number(m[1]) : null; };
const view = (s) => ({
  code: codeOf(s.id), kind: 'plan', amountCents: Number(s.total_cents), termsVersion: s.terms_version,
  acceptedAt: s.accepted_at, contractHash: s.contract_hash, subscriptionId: Number(s.id), status: s.status,
  conditions: { planName: s.plan_name, planCategory: s.plan_category, totalCents: Number(s.total_cents), dailyCents: Number(s.daily_cents), period: s.period },
});

async function load(req) {
  const u = requireUser(req);
  const id = idOf(req.params.code);
  const s = id ? (await db().query('SELECT * FROM subscriptions WHERE id=$1 AND user_id=$2', [id, u.id]))[0] : null;
  if (!s) throw notFound('Contrato não encontrado.');
  return s;
}

export default function register(r) {
  r.get('/api/policies/contracts', async (req) => {
    const u = requireUser(req);
    const rows = await db().query('SELECT * FROM subscriptions WHERE user_id=$1 ORDER BY accepted_at DESC, id DESC', [u.id]);
    return { contracts: rows.map(view) };
  });
  r.get('/api/policies/contracts/:code', async (req) => {
    const s = await load(req);
    return { contract: { ...view(s), contractText: s.contract_text } };
  });
  r.get('/api/policies/contracts/:code/download', async (req, res) => {
    const s = await load(req);
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Content-Disposition': `attachment; filename="contrato-${codeOf(s.id)}.txt"`, 'Cache-Control': 'no-store' });
    res.end(`${s.contract_text}\n\nCódigo: ${codeOf(s.id)}\nVersão dos termos: ${s.terms_version}\nAceito em: ${s.accepted_at}\nHash: ${s.contract_hash}\n`);
  });
}
