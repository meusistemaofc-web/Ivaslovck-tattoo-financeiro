import { createHash } from 'node:crypto';
import { db } from '../db.js';
import { bad, notFound, conflict } from '../http.js';
import { getSetting, setSetting, audit, notify } from './settings.js';
import { move } from './coins.js';

const now = () => new Date().toISOString();
const addDays = (d) => new Date(Date.now() + d * 86400000).toISOString();
const truthy = (v) => v === true || v === 1 || v === '1' || v === 't';

export const CRITERIA = {
  signup: 'assim que seu amigo criar a conta',
  contract: 'quando seu amigo contratar o primeiro plano',
  payment: 'quando o primeiro pagamento do seu amigo for confirmado',
};
export const STATUS_TEXT = {
  registered: 'Cadastro realizado', qualified: 'Aguardando confirmação', review: 'Em análise', capped: 'Limite atingido',
  approved: 'Aprovada', rejected: 'Rejeitada', expired: 'Expirada',
};
export const CONFIG_DEFAULTS = {
  enabled: true, rewardCoins: 100, criterion: 'payment', confirmationDays: 7, qualifyWithinDays: 30,
  maxRewardsPerPeriod: 10, rewardPeriod: 'month', maxCoinsPerUser: 0, requireApproval: false, holdFlagged: true,
};

export async function getConfig(q = db()) {
  const saved = (await getSetting('referralConfig', q)) || {};
  return { ...CONFIG_DEFAULTS, ...saved };
}
export function sanitizeConfig(b = {}) {
  const int = (v, min, max, label) => {
    const n = Number(v);
    if (!Number.isInteger(n) || n < min || n > max) throw bad(`${label}: informe um número inteiro entre ${min} e ${max}.`);
    return n;
  };
  if (!Object.keys(CRITERIA).includes(b.criterion)) throw bad('Critério de validação inválido.');
  if (!['week', 'month', 'year'].includes(b.rewardPeriod)) throw bad('Período inválido.');
  return {
    enabled: !!b.enabled,
    rewardCoins: int(b.rewardCoins, 1, 1000000, 'IVT COINS por indicação'),
    criterion: b.criterion,
    confirmationDays: int(b.confirmationDays, 0, 365, 'Prazo de confirmação'),
    qualifyWithinDays: int(b.qualifyWithinDays, 0, 730, 'Prazo para cumprir o critério'),
    maxRewardsPerPeriod: int(b.maxRewardsPerPeriod, 0, 100000, 'Limite por período'),
    rewardPeriod: b.rewardPeriod,
    maxCoinsPerUser: int(b.maxCoinsPerUser, 0, 1000000000, 'Teto de moedas por cliente'),
    requireApproval: !!b.requireApproval,
    holdFlagged: !!b.holdFlagged,
  };
}

const cleanCode = (c) => String(c ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 24);
const loopback = (ip) => !ip || ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';

function periodStart(period) {
  const d = new Date();
  if (period === 'year') return new Date(Date.UTC(d.getUTCFullYear(), 0, 1)).toISOString();
  if (period === 'month') return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString();
  const wd = (d.getUTCDay() + 6) % 7;
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - wd)).toISOString();
}

export async function activeCampaign(q = db()) {
  const t = now();
  const rows = await q.query('SELECT * FROM referral_campaigns WHERE active=$1 AND starts_at<=$2 AND ends_at>=$3 ORDER BY id DESC LIMIT 1', [true, t, t]);
  return rows[0] || null;
}

// ---------- visitas ----------
export async function trackVisit(code, ip, ua) {
  const c = cleanCode(code);
  if (c.length < 4) return { valid: false };
  const ref = (await db().query(`SELECT id, name, referral_code FROM users WHERE referral_code=$1 AND role='client' AND status='active'`, [c]))[0];
  if (!ref) return { valid: false };
  const hash = createHash('sha256').update(`${ip || ''}|${ua || ''}`).digest('hex').slice(0, 32);
  try { await db().query('INSERT INTO referral_visits (code, visitor_hash, created_at) VALUES ($1,$2,$3) ON CONFLICT (code, visitor_hash) DO NOTHING', [c, hash, now()]); } catch { /* contagem é best-effort */ }
  return { valid: true, code: c, referrerFirstName: String(ref.name).split(' ')[0] };
}

// ---------- cadastro por indicação ----------
async function signupFlags(t, referrer, user, ip) {
  const flags = [];
  const norm = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  if (norm(referrer.name) === norm(user.name)) flags.push({ key: 'same_name', text: 'Nome igual ao do indicador' });
  const a = Number(referrer.whatsapp), b = Number(user.whatsapp);
  if (a && b && Math.abs(a - b) <= 3) flags.push({ key: 'sequential_whatsapp', text: 'WhatsApp sequencial ao do indicador' });
  if (!/^\d{2}9\d{8}$/.test(String(user.whatsapp))) flags.push({ key: 'odd_whatsapp', text: 'WhatsApp fora do padrão de celular' });
  if (!loopback(ip)) {
    const same = await t.query('SELECT id FROM sessions WHERE user_id=$1 AND ip=$2 LIMIT 1', [referrer.id, ip]);
    if (same.length) flags.push({ key: 'same_ip', text: 'Mesmo IP do indicador' });
    const many = await t.query('SELECT COUNT(*) AS n FROM referrals WHERE referrer_id=$1 AND signup_ip=$2', [referrer.id, ip]);
    if (Number(many[0].n) >= 2) flags.push({ key: 'same_network', text: 'Vários cadastros da mesma rede' });
  }
  return flags;
}

export async function captureSignup(t, user, { code, ip } = {}) {
  const c = cleanCode(code);
  if (c.length < 4) return null;
  const referrer = (await t.query(`SELECT id, name, whatsapp FROM users WHERE referral_code=$1 AND role='client'`, [c]))[0];
  if (!referrer || Number(referrer.id) === Number(user.id)) return null;
  const cfg = await getConfig(t);
  const camp = await activeCampaign(t);
  const flags = await signupFlags(t, referrer, user, ip);
  const ts = now();
  const rows = await t.query(
    `INSERT INTO referrals (referrer_id, referred_id, code, status, reward_coins, campaign_id, campaign_name, flags, signup_ip, expires_at, created_at, updated_at)
     VALUES ($1,$2,$3,'registered',$4,$5,$6,$7,$8,$9,$10,$10) RETURNING *`,
    [referrer.id, user.id, c, camp ? camp.reward_coins : cfg.rewardCoins, camp ? camp.id : null, camp ? camp.name : null,
      JSON.stringify(flags), loopback(ip) ? null : ip, cfg.qualifyWithinDays > 0 ? addDays(cfg.qualifyWithinDays) : null, ts],
  );
  await t.query('UPDATE users SET referred_by=$1 WHERE id=$2', [referrer.id, user.id]);
  await audit(t, 'referral_registered', `Cadastro por indicação de ${referrer.name}: ${user.name}`, { userId: referrer.id, actorId: user.id, meta: { referralId: rows[0].id, flags: flags.map((f) => f.key) } });
  if (cfg.criterion === 'signup') await qualify(t, user.id, 'signup');
  return rows[0];
}

// Chamado quando o indicado cumpre um marco: 'signup' | 'contract' | 'payment'.
export async function qualify(t, userId, event) {
  const r = (await t.query(`SELECT * FROM referrals WHERE referred_id=$1 AND status='registered'`, [userId]))[0];
  if (!r) return null;
  const cfg = await getConfig(t);
  if (cfg.criterion !== event) return null;
  const ts = now();
  if (r.expires_at && r.expires_at < ts) {
    await t.query(`UPDATE referrals SET status='expired', updated_at=$1 WHERE id=$2`, [ts, r.id]);
    return null;
  }
  const flagged = JSON.parse(r.flags || '[]').length > 0;
  const status = cfg.requireApproval || (cfg.holdFlagged && flagged) ? 'review' : 'qualified';
  await t.query('UPDATE referrals SET status=$1, qualified_at=$2, release_at=$3, updated_at=$2 WHERE id=$4', [status, ts, addDays(cfg.confirmationDays), r.id]);
  await audit(t, 'referral_qualified', `Indicação #${r.id} cumpriu o critério (${event})${status === 'review' ? ' — em análise' : ''}`, { userId: r.referrer_id, meta: { referralId: r.id } });
  return status;
}

// ---------- recompensa ----------
async function capReached(t, r, cfg) {
  if (cfg.maxRewardsPerPeriod > 0) {
    const n = await t.query(`SELECT COUNT(*) AS n FROM referrals WHERE referrer_id=$1 AND status='approved' AND approved_at>=$2`, [r.referrer_id, periodStart(cfg.rewardPeriod)]);
    if (Number(n[0].n) >= cfg.maxRewardsPerPeriod) return true;
  }
  if (cfg.maxCoinsPerUser > 0) {
    const s = await t.query(`SELECT COALESCE(SUM(paid_coins),0) AS s FROM referrals WHERE referrer_id=$1 AND status='approved'`, [r.referrer_id]);
    if (Number(s[0].s) + Number(r.reward_coins) > cfg.maxCoinsPerUser) return true;
  }
  return false;
}

async function grantReward(t, r, { actorId = null } = {}) {
  const referred = (await t.query('SELECT name FROM users WHERE id=$1', [r.referred_id]))[0];
  const first = String(referred?.name || 'amigo').split(' ')[0];
  const res = await move(t, { userId: r.referrer_id, amount: Number(r.reward_coins), kind: 'distribute', reason: `Indicação de ${first}`, refType: 'referral', refId: r.id, key: `referral:${r.id}`, actorId });
  const ts = now();
  await t.query(`UPDATE referrals SET status='approved', paid_coins=$1, ledger_id=$2, approved_at=$3, decided_by=$4, updated_at=$3 WHERE id=$5`,
    [r.reward_coins, res.entry.id, ts, actorId, r.id]);
  await audit(t, 'referral_rewarded', `${r.reward_coins} IVT COINS por indicação #${r.id}`, { userId: r.referrer_id, actorId, meta: { coins: Number(r.reward_coins), referralId: r.id } });
  await notify(t, r.referrer_id, 'Indicação confirmada!', `Você ganhou ${r.reward_coins} IVT COINS pela indicação de ${first}.`, '/indique', 'referral_rewarded');
}

export async function processReferrals() {
  const ts = now();
  await db().query(`UPDATE referrals SET status='expired', updated_at=$1 WHERE status='registered' AND expires_at IS NOT NULL AND expires_at<$1`, [ts]);
  const due = await db().query(`SELECT id FROM referrals WHERE status IN ('qualified','capped') AND release_at<=$1 ORDER BY id`, [ts]);
  for (const { id } of due) {
    await db().tx(async (t) => {
      const r = (await t.query(`SELECT * FROM referrals WHERE id=$1 AND status IN ('qualified','capped') FOR UPDATE`, [id]))[0];
      if (!r) return;
      const cfg = await getConfig(t);
      if (!cfg.enabled) return;
      if (await capReached(t, r, cfg)) { if (r.status !== 'capped') await t.query(`UPDATE referrals SET status='capped', updated_at=$1 WHERE id=$2`, [now(), id]); return; }
      await grantReward(t, r);
    });
  }
}

export async function adminDecide(admin, id, approve, reason) {
  return db().tx(async (t) => {
    const r = (await t.query('SELECT * FROM referrals WHERE id=$1 FOR UPDATE', [id]))[0];
    if (!r) throw notFound('Indicação não encontrada.');
    if (approve) {
      if (!['qualified', 'review', 'capped'].includes(r.status)) throw conflict('Esta indicação não pode ser aprovada na situação atual.');
      await grantReward(t, r, { actorId: admin.id });
    } else {
      if (!['registered', 'qualified', 'review', 'capped'].includes(r.status)) throw conflict('Esta indicação não pode ser rejeitada na situação atual.');
      await t.query(`UPDATE referrals SET status='rejected', note=$1, decided_by=$2, updated_at=$3 WHERE id=$4`, [String(reason || '').slice(0, 300), admin.id, now(), id]);
      await audit(t, 'referral_rejected', `Indicação #${id} rejeitada`, { userId: r.referrer_id, actorId: admin.id, meta: { reason: reason || null } });
    }
    return { ok: true };
  });
}

// ---------- campanhas ----------
const dayStart = (d) => new Date(`${d}T00:00:00-03:00`).toISOString();
const dayEnd = (d) => new Date(`${d}T23:59:59.999-03:00`).toISOString();
export async function createCampaign(admin, b) {
  const name = String(b.name || '').trim();
  const coins = Number(b.rewardCoins);
  if (name.length < 3 || name.length > 80) throw bad('Informe o nome da campanha (3 a 80 caracteres).');
  if (!Number.isInteger(coins) || coins < 1) throw bad('Informe as moedas por indicação.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.startsAt || '') || !/^\d{4}-\d{2}-\d{2}$/.test(b.endsAt || '')) throw bad('Informe as datas de início e fim.');
  if (b.endsAt < b.startsAt) throw bad('O fim deve ser igual ou posterior ao início.');
  const rows = await db().query('INSERT INTO referral_campaigns (name, reward_coins, starts_at, ends_at, active, created_by, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
    [name, coins, dayStart(b.startsAt), dayEnd(b.endsAt), true, admin.id, now()]);
  await audit(db(), 'referral_campaign_created', `Campanha de indicação: ${name} (${coins} IVT)`, { actorId: admin.id });
  return rows[0];
}
export async function toggleCampaign(admin, id) {
  const c = (await db().query('SELECT * FROM referral_campaigns WHERE id=$1', [id]))[0];
  if (!c) throw notFound('Campanha não encontrada.');
  await db().query('UPDATE referral_campaigns SET active=$1 WHERE id=$2', [!truthy(c.active), id]);
  await audit(db(), 'referral_campaign_toggled', `Campanha ${c.name} ${truthy(c.active) ? 'desativada' : 'ativada'}`, { actorId: admin.id });
}
export const campaignView = (c) => {
  const t = now(); const active = truthy(c.active);
  return { id: Number(c.id), name: c.name, rewardCoins: Number(c.reward_coins), startsAt: c.starts_at, endsAt: c.ends_at, active, running: active && c.starts_at <= t && c.ends_at >= t };
};

export async function saveConfig(admin, body) {
  const cfg = sanitizeConfig(body);
  await setSetting('referralConfig', cfg, admin.id);
  await audit(db(), 'referral_config_changed', 'Configurações do programa de indicação alteradas', { actorId: admin.id, meta: cfg });
  return cfg;
}
