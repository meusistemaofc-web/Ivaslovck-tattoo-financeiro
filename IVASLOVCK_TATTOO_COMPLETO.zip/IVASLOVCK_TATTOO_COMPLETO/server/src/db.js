// Camada de banco de dados.
// Produção: PostgreSQL (driver "pg"). Testes locais / desenvolvimento: SQLite embutido do Node (node:sqlite).
// Todo SQL do projeto é escrito no dialeto do PostgreSQL ($1, $2 ... / FOR UPDATE / RETURNING)
// e traduzido automaticamente quando o driver é SQLite.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let driver = null;

function normalizeRow(row) {
  if (!row) return row;
  const out = {};
  for (const [k, v] of Object.entries(row)) {
    if (v instanceof Date) out[k] = v.toISOString();
    else if (typeof v === 'bigint') out[k] = Number(v);
    else out[k] = v;
  }
  return out;
}

function toSqlite(sql) {
  return sql
    .replace(/\bFOR UPDATE\b/gi, '')
    .replace(/\bILIKE\b/gi, 'LIKE')
    .replace(/\$(\d+)/g, '?$1')
    .replace(/::[a-z]+/gi, '');
}

function translateDDL(sql) {
  return sql
    .replace(/BIGSERIAL PRIMARY KEY/gi, 'INTEGER PRIMARY KEY AUTOINCREMENT')
    .replace(/\bTIMESTAMPTZ\b/gi, 'TEXT')
    .replace(/\bJSONB\b/gi, 'TEXT')
    .replace(/\bBOOLEAN\b/gi, 'INTEGER')
    .replace(/DEFAULT NOW\(\)/gi, "DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
    .replace(/DEFAULT TRUE/gi, 'DEFAULT 1')
    .replace(/DEFAULT FALSE/gi, 'DEFAULT 0');
}

async function makePg() {
  const pg = (await import('pg')).default;
  // BIGINT (int8) como número JS: valores em centavos cabem com folga em Number.MAX_SAFE_INTEGER.
  pg.types.setTypeParser(20, (v) => Number(v));
  const pool = new pg.Pool({ connectionString: config.databaseUrl, max: 10 });
  const run = async (client, sql, params = []) => {
    const r = await client.query(sql, params && params.length ? params : undefined);
    return r.rows.map(normalizeRow);
  };
  return {
    kind: 'postgres',
    async query(sql, params) { return run(pool, sql, params); },
    async tx(fn) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const t = { query: (s, p) => run(client, s, p), kind: 'postgres' };
        const result = await fn(t);
        await client.query('COMMIT');
        return result;
      } catch (e) {
        await client.query('ROLLBACK').catch(() => {});
        throw e;
      } finally {
        client.release();
      }
    },
    async exec(sql) { await pool.query(sql); },
    async close() { await pool.end(); },
  };
}

async function makeSqlite() {
  const { DatabaseSync } = await import('node:sqlite');
  const file = config.sqlitePath;
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  // SQLite é síncrono: uma fila garante que transações nunca se intercalem (equivalente a lock global de escrita).
  let chain = Promise.resolve();
  const enqueue = (fn) => {
    const p = chain.then(fn, fn);
    chain = p.catch(() => {});
    return p;
  };
  const conv = (params) => (params || []).map((v) => (typeof v === 'boolean' ? (v ? 1 : 0) : v === undefined ? null : v));
  const run = (sql, params) => {
    const st = db.prepare(toSqlite(sql));
    const trimmed = sql.trim().toUpperCase();
    if (trimmed.startsWith('SELECT') || trimmed.startsWith('WITH') || /\bRETURNING\b/i.test(sql)) {
      return st.all(...conv(params)).map(normalizeRow);
    }
    st.run(...conv(params));
    return [];
  };
  let inTx = false;
  return {
    kind: 'sqlite',
    async query(sql, params) {
      if (inTx) return run(sql, params);
      return enqueue(() => run(sql, params));
    },
    async tx(fn) {
      return enqueue(async () => {
        db.exec('BEGIN IMMEDIATE');
        inTx = true;
        try {
          const t = { query: async (s, p) => run(s, p), kind: 'sqlite' };
          const result = await fn(t);
          db.exec('COMMIT');
          return result;
        } catch (e) {
          try { db.exec('ROLLBACK'); } catch {}
          throw e;
        } finally {
          inTx = false;
        }
      });
    },
    async exec(sql) { return enqueue(() => db.exec(sql)); },
    async close() { db.close(); },
  };
}

export async function initDb() {
  if (driver) return driver;
  driver = config.databaseUrl ? await makePg() : await makeSqlite();
  await migrate();
  return driver;
}

export function db() {
  if (!driver) throw new Error('Banco não inicializado');
  return driver;
}

async function migrate() {
  const d = driver;
  await d.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)`);
  const dir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  const done = new Set((await d.query('SELECT name FROM schema_migrations')).map((r) => r.name));
  for (const f of files) {
    if (done.has(f)) continue;
    let sql = fs.readFileSync(path.join(dir, f), 'utf8');
    // Blocos específicos de dialeto: -- @postgres ... -- @end  /  -- @sqlite ... -- @end
    const keep = d.kind;
    sql = sql.replace(/-- @(postgres|sqlite)\n([\s\S]*?)-- @end\n?/g, (_, k, body) => (k === keep ? body : ''));
    if (d.kind === 'sqlite') sql = translateDDL(sql);
    if (d.kind === 'sqlite') await d.exec(`BEGIN;\n${sql}\nCOMMIT;`);
    else await d.tx(async (t) => { await t.query(sql); });
    await d.query('INSERT INTO schema_migrations (name, applied_at) VALUES ($1, $2)', [f, new Date().toISOString()]);
    console.log(`[db] migração aplicada: ${f}`);
  }
}

/** Fecha a conexão (usado em testes de persistência e no desligamento). */
export async function closeDb() {
  if (driver) { await driver.close(); driver = null; }
}
