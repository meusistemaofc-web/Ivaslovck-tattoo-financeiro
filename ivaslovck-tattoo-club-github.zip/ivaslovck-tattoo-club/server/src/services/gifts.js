// Cartão Presente: o comprador paga um Pix, o servidor emite o cartão e um link de uso único.
// Quem recebe resgata na própria conta e o valor entra como saldo de benefício (bucket "gift"): sem saque, sem Pix, sem conversão.
import crypto from 'node:crypto';
import { db } from '../db.js';
import { bad, conflict, notFound } from '../http.js';
import * as mp from './mercadopago.js';
import { getSetting, setSetting, audit, notify } from './settings.js';
import * as wallet from './wallet.js';

const now = () => new Date().toISOString();
const addDays = (d) => new Date(Date.now() + d * 86400000).toISOString();

export const MODELS = [
  { key: 'midnight', name: 'Midnight', tagline: 'Preto profundo com azul elétrico', from: '#0b1226', to: '#087bff', ribbon: '#7cc4ff', active: true },
  { key: 'ink', name: 'Ink', tagline: 'Clássico em preto e prata', from: '#111111', to: '#4b4f58', ribbon: '#d9dde5', active: true },
  { key: 'aurora', name: 'Aurora', tagline: 'Azul e violeta', from: '#1b1464', to: '#6a3df0', ribbon: '#c9b8ff', active: true },
];
export const DEFAULT_MESSAGES = [
  'Para você realizar aquela tatuagem que não sai da cabeça. Com carinho!',
  'Um presente que fica para sempre. Escolha seu desenho e eternize sua história.',
  'Feliz aniversário! Que tal transformar uma ideia em arte na pele?',
  'Você merece um presente especial. Aproveite no estúdio!',
  'Parabéns pela conquista! Este presente é para celebrar com arte.',
  'Para você, com todo o meu carinho e a certeza de que vai amar.',
];
export const DEFAULT_TERMS = 'O cartão presente vira saldo de benefício para tatuagens e piercings elegíveis do estúdio. Não é dinheiro nem IVT COIN: não pode ser sacado, transferido por Pix ou convertido em dinheiro. O link funciona uma única vez e o cartão precisa ser resgatado dentro da validade.';
export const CONFIG_DEFAULTS = { enabled: true, notifyBuyerOnUse: true, amounts: [5000, 10000, 15000, 20000, 30000, 50000], inactiveAmounts: [], validityDays: 365, terms: DEFAULT_TERMS, defaultMessages: DEFAULT_MESSAGES, models: MODELS, pixCheck: null };
let MODEL_CACHE = MODELS;

export async function getGiftConfig(q = db()) {
  const saved = (await getSetting('giftConfig', q)) || {};
  const cfg = { ...CONFIG_DEFAULTS, ...saved };
  MODEL_CACHE = cfg.models;
  return cfg;
}
export async function catalog() {
  const cfg = await getGiftConfig();
  return { enabled: cfg.enabled, amounts: cfg.amounts.filter((a) => !cfg.inactiveAmounts.includes(a)), models: cfg.models.filter((m) => m.active), defaultMessages: cfg.defaultMessages, terms: cfg.terms, validityDays: cfg.validityDays };
}
const modelOf = (key) => MODEL_CACHE.find((m) => m.key === key) || MODEL_CACHE[0] || MODELS[0];
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newCode = () => `GIFT-${Array.from(crypto.randomBytes(8), (b) => alphabet[b % alphabet.length]).join('')}`;
const newToken = () => crypto.randomBytes(24).toString('base64url');
const event = (q, cardId, kind, actorId, detail) => q.query('INSERT INTO gift_events (card_id, kind, actor_id, detail, created_at) VALUES ($1,$2,$3,$4,$5)', [cardId, kind, actorId || null, detail || null, now()]);

export function cardView(c, { withToken = false, remainingCents } = {}) {
  const v = {
    id: Number(c.id), code: c.code, model: modelOf(c.model_key), amountCents: Number(c.amount_cents), recipientName: c.recipient_name, senderName: c.sender_name,
    message: c.message || '', status: c.status, delivery: c.delivery === 'later' ? 'later' : 'now', createdAt: c.created_at, paidAt: c.paid_at, expiresAt: c.expires_at, redeemedAt: c.redeemed_at,
  };
  if (withToken && ['paid', 'redeemed'].includes(c.status)) v.token = c.token;
  if (remainingCents !== undefined) v.remainingCents = remainingCents;
  return v;
}

export async function createCard(user, b) {
  const cfg = await getGiftConfig();
  if (!cfg.enabled) throw conflict('A venda de cartões presente está indisponível no momento.');
  const amount = Number(b.amountCents);
  const active = cfg.amounts.filter((a) => !cfg.inactiveAmounts.includes(a));
  if (!Number.isInteger(amount) || !active.includes(amount)) throw bad('Escolha um dos valores disponíveis.');
  if (!cfg.models.some((m) => m.active && m.key === b.modelKey)) throw bad('Escolha um modelo de cartão.');
  const recipientName = String(b.recipientName || '').trim(), senderName = String(b.senderName || '').trim(), message = String(b.message || '').trim();
  if (recipientName.length < 2 || recipientName.length > 60) throw bad('Informe o nome de quem vai receber (2 a 60 caracteres).');
  if (senderName.length < 2 || senderName.length > 60) throw bad('Informe como você quer assinar (2 a 60 caracteres).');
  if (message.length > 280) throw bad('A mensagem pode ter no máximo 280 caracteres.');
  const delivery = b.delivery === 'later' ? 'later' : 'now';
  const key = String(b.idempotencyKey || '');
  if (!key || key.length > 100) throw bad('Requisição inválida (chave de idempotência).');
  return db().tx(async (t) => {
    const dup = (await t.query('SELECT * FROM gift_cards WHERE buyer_id=$1 AND idempotency_key=$2', [user.id, key]))[0];
    if (dup) return dup;
    const ts = now();
    const rows = await t.query(
      `INSERT INTO gift_cards (code, token, buyer_id, recipient_name, sender_name, message, model_key, amount_cents, delivery, status, idempotency_key, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'awaiting_payment',$10,$11,$11) RETURNING *`,
      [newCode(), newToken(), user.id, recipientName, senderName, message, b.modelKey, amount, delivery, key, ts],
    );
    await event(t, rows[0].id, 'created', user.id, `Compra iniciada (${amount} centavos)`);
    await audit(t, 'gift_created', `Cartão presente ${rows[0].code} criado`, { userId: user.id, actorId: user.id, amountCents: amount });
    return rows[0];
  });
}

// Chamado na mesma transação em que o Pix é confirmado.
export async function markPaid(t, cardId, charge) {
  const c = (await t.query('SELECT * FROM gift_cards WHERE id=$1 FOR UPDATE', [cardId]))[0];
  if (!c) return;
  if (c.status !== 'awaiting_payment') {
    await event(t, c.id, 'payment_in_review', null, `Pagamento da cobrança #${charge.id} para cartão em situação ${c.status}`);
    await audit(t, 'gift_payment_review', `Pagamento para cartão ${c.code} já ${c.status}. Requer devolução/análise.`, { userId: c.buyer_id, amountCents: Number(charge.amount_cents) });
    await notify(t, c.buyer_id, 'Pagamento em análise', `O pagamento do cartão ${c.code} precisa de análise do estúdio.`, '/presentear/meus', 'gift_review', 'admin');
    return;
  }
  const cfg = await getGiftConfig(t);
  const ts = now();
  await t.query(`UPDATE gift_cards SET status='paid', paid_at=$1, expires_at=$2, updated_at=$1 WHERE id=$3`, [ts, addDays(cfg.validityDays), c.id]);
  await event(t, c.id, 'paid', c.buyer_id, 'Pagamento confirmado');
  await audit(t, 'gift_paid', `Cartão presente ${c.code} pago`, { userId: c.buyer_id, amountCents: Number(c.amount_cents) });
  await notify(t, c.buyer_id, 'Cartão presente pronto!', `Seu cartão ${c.code} para ${c.recipient_name} está pronto. Envie o link exclusivo.`, `/presentear/cartao/${c.id}`, 'gift_paid');
}

// Saldo restante por cartão resgatado: o saldo de presente da carteira é consumido do cartão mais antigo para o mais novo.
function allocate(cards, giftBalance) {
  const redeemed = cards.filter((c) => c.status === 'redeemed').sort((a, b) => Number(a.id) - Number(b.id));
  const total = redeemed.reduce((s, c) => s + Number(c.amount_cents), 0);
  let used = Math.max(0, total - Number(giftBalance));
  const out = {};
  for (const c of redeemed) { const u = Math.min(used, Number(c.amount_cents)); used -= u; out[c.id] = { usedCents: u, remainingCents: Number(c.amount_cents) - u }; }
  return out;
}

export async function expireDue() {
  await getGiftConfig();
  const ts = now();
  const due = await db().query(`SELECT id FROM gift_cards WHERE status='paid' AND expires_at IS NOT NULL AND expires_at < $1`, [ts]);
  for (const { id } of due) {
    await db().tx(async (t) => {
      const c = (await t.query(`SELECT * FROM gift_cards WHERE id=$1 AND status='paid' FOR UPDATE`, [id]))[0];
      if (!c) return;
      await t.query(`UPDATE gift_cards SET status='expired', updated_at=$1 WHERE id=$2`, [ts, id]);
      await event(t, id, 'expired', null, 'Validade encerrada sem resgate');
    });
  }
}

export async function listMine(user) {
  await expireDue();
  const sent = await db().query('SELECT * FROM gift_cards WHERE buyer_id=$1 ORDER BY id DESC', [user.id]);
  const received = await db().query('SELECT * FROM gift_cards WHERE recipient_id=$1 ORDER BY id DESC', [user.id]);
  const alloc = allocate(received, (await wallet.getWallet(db(), user.id)).gift_cents);
  return { sent: sent.map((c) => cardView(c)), received: received.map((c) => cardView(c, { remainingCents: alloc[c.id]?.remainingCents })) };
}

export async function getMine(user, id) {
  await expireDue();
  const c = (await db().query('SELECT * FROM gift_cards WHERE id=$1', [Number(id) || 0]))[0];
  if (!c) throw notFound('Cartão presente não encontrado.');
  const isBuyer = Number(c.buyer_id) === Number(user.id), isRecipient = c.recipient_id != null && Number(c.recipient_id) === Number(user.id);
  if (!isBuyer && !isRecipient) throw notFound('Cartão presente não encontrado.');
  let redeemedBy = null, pendingChargeId = null, remainingCents;
  if (isBuyer) {
    if (c.recipient_id) redeemedBy = (await db().query('SELECT name FROM users WHERE id=$1', [c.recipient_id]))[0]?.name ?? null;
    const p = (await db().query(`SELECT id FROM charges WHERE gift_card_id=$1 AND status='pending' AND expires_at > $2 ORDER BY id DESC LIMIT 1`, [c.id, now()]))[0];
    pendingChargeId = p ? Number(p.id) : null;
  }
  if (isRecipient) {
    const all = await db().query(`SELECT * FROM gift_cards WHERE recipient_id=$1`, [user.id]);
    remainingCents = allocate(all, (await wallet.getWallet(db(), user.id)).gift_cents)[c.id]?.remainingCents;
  }
  return { role: isBuyer ? 'buyer' : 'recipient', card: cardView(c, { withToken: isBuyer, remainingCents }), pendingChargeId, redeemedBy };
}

export async function publicByToken(token) {
  await expireDue();
  const c = (await db().query('SELECT * FROM gift_cards WHERE token=$1', [String(token).slice(0, 80)]))[0];
  if (!c || c.status === 'awaiting_payment' || c.status === 'cancelled') throw notFound('Presente não encontrado.');
  const open = c.status === 'paid';
  return { status: c.status, model: modelOf(c.model_key), recipientName: c.recipient_name, senderName: open ? c.sender_name : null, message: open ? c.message : '', amountCents: open ? Number(c.amount_cents) : null, expiresAt: c.expires_at, redeemedAt: c.redeemed_at };
}

export async function claim(user, token) {
  if (user.role !== 'client') throw conflict('Entre com uma conta de cliente para receber o presente.');
  return db().tx(async (t) => {
    const c = (await t.query('SELECT * FROM gift_cards WHERE token=$1 FOR UPDATE', [String(token).slice(0, 80)]))[0];
    if (!c || c.status === 'awaiting_payment' || c.status === 'cancelled') throw notFound('Presente não encontrado.');
    if (c.status === 'redeemed') { if (Number(c.recipient_id) === Number(user.id)) return { code: c.code, duplicate: true }; throw conflict('Este presente já foi recebido.'); }
    if (c.status === 'expired' || (c.expires_at && c.expires_at < now())) throw conflict('A validade deste presente terminou.');
    if (Number(c.buyer_id) === Number(user.id)) throw conflict('Você não pode resgatar o próprio presente. Envie o link para quem vai recebê-lo.');
    const res = await wallet.credit(t, { userId: user.id, amountCents: Number(c.amount_cents), bucket: 'gift', kind: 'gift_redeem', refType: 'gift_card', refId: c.id, key: `gift:${c.id}`, description: `Cartão Presente ${c.code}`, actorId: user.id });
    const ts = now();
    await t.query(`UPDATE gift_cards SET status='redeemed', recipient_id=$1, redeemed_at=$2, ledger_id=$3, updated_at=$2 WHERE id=$4`, [user.id, ts, res.entries[0].id, c.id]);
    await event(t, c.id, 'redeemed', user.id, 'Presente resgatado');
    await audit(t, 'gift_redeemed', `Cartão presente ${c.code} resgatado`, { userId: user.id, actorId: user.id, amountCents: Number(c.amount_cents) });
    await notify(t, c.buyer_id, 'Seu presente foi recebido!', `${String(user.name).split(' ')[0]} recebeu o cartão presente ${c.code}.`, `/presentear/cartao/${c.id}`, 'gift_redeemed');
    return { code: c.code };
  });
}

export async function receipt(user, code) {
  await getGiftConfig();
  const c = (await db().query('SELECT * FROM gift_cards WHERE code=$1', [String(code).slice(0, 30)]))[0];
  if (!c || (Number(c.buyer_id) !== Number(user.id) && Number(c.recipient_id) !== Number(user.id))) throw notFound('Comprovante não encontrado.');
  const all = c.recipient_id ? await db().query('SELECT * FROM gift_cards WHERE recipient_id=$1', [c.recipient_id]) : [];
  const alloc = c.recipient_id ? allocate(all, (await wallet.getWallet(db(), c.recipient_id)).gift_cents)[c.id] : null;
  return {
    receipt: {
      ...cardView(c), usedCents: alloc?.usedCents ?? 0, remainingCents: alloc ? alloc.remainingCents : Number(c.amount_cents),
      ledgerCode: c.ledger_id ? `LC-${String(c.ledger_id).padStart(6, '0')}` : null, entries: [],
    },
  };
}

// ---------- administração ----------
const eventView = (e) => ({ id: Number(e.id), createdAt: e.created_at, action: e.kind, code: e.code || null, message: e.detail || '', actorName: e.actor_name || null });
async function usageFor(recipientId) {
  if (!recipientId) return { all: [], bal: 0 };
  return { all: await db().query('SELECT * FROM gift_cards WHERE recipient_id=$1', [recipientId]), bal: (await wallet.getWallet(db(), recipientId)).gift_cents };
}

export async function adminOverview() {
  await expireDue();
  const cfg = await getGiftConfig();
  const cards = await db().query('SELECT * FROM gift_cards');
  const sum = (arr) => arr.reduce((a, c) => a + Number(c.amount_cents), 0);
  const paidCards = cards.filter((c) => c.paid_at);
  const unredeemed = cards.filter((c) => c.status === 'paid'), redeemed = cards.filter((c) => c.status === 'redeemed');
  let available = 0;
  for (const rid of new Set(redeemed.map((c) => Number(c.recipient_id)))) {
    const u = await usageFor(rid);
    for (const v of Object.values(allocate(u.all, u.bal))) available += v.remainingCents;
  }
  const inReview = Number((await db().query(`SELECT COUNT(*) AS n FROM gift_events WHERE kind='payment_in_review'`))[0].n);
  return {
    config: cfg,
    stats: {
      sold: paidCards.length, revenueCents: sum(paidCards), awaiting: cards.filter((c) => c.status === 'awaiting_payment').length,
      unredeemed: unredeemed.length, unredeemedCents: sum(unredeemed), redeemed: redeemed.length, redeemedCents: sum(redeemed),
      expired: cards.filter((c) => c.status === 'expired' && c.paid_at).length, availableCents: available, usedCents: sum(redeemed) - available, inReview,
    },
  };
}

export async function adminCards({ q = '', status = '' } = {}) {
  await expireDue();
  const term = `%${String(q).trim().toLowerCase().slice(0, 60)}%`;
  const rows = await db().query(
    `SELECT g.*, b.name AS buyer_name, b.code AS buyer_code, r.name AS recipient_user_name, r.code AS recipient_code
     FROM gift_cards g JOIN users b ON b.id=g.buyer_id LEFT JOIN users r ON r.id=g.recipient_id
     WHERE ($1 = '' OR g.status = $1)
       AND ($2 = '%%' OR LOWER(g.code) LIKE $2 OR LOWER(b.name) LIKE $2 OR LOWER(b.code) LIKE $2 OR LOWER(g.recipient_name) LIKE $2 OR LOWER(COALESCE(r.name,'')) LIKE $2 OR LOWER(COALESCE(r.code,'')) LIKE $2)
     ORDER BY g.id DESC LIMIT 300`, [String(status || ''), term]);
  const cache = new Map();
  const out = [];
  for (const g of rows) {
    let remaining = null;
    if (g.status === 'redeemed') {
      if (!cache.has(g.recipient_id)) { const u = await usageFor(g.recipient_id); cache.set(g.recipient_id, allocate(u.all, u.bal)); }
      remaining = cache.get(g.recipient_id)[g.id]?.remainingCents ?? null;
    }
    out.push({
      id: Number(g.id), code: g.code, buyer: { name: g.buyer_name, code: g.buyer_code }, recipient: g.recipient_id ? { name: g.recipient_user_name, code: g.recipient_code } : null,
      recipientName: g.recipient_name, amountCents: Number(g.amount_cents), remainingCents: remaining, status: g.status, createdAt: g.created_at,
    });
  }
  return { cards: out };
}

export async function adminCard(id) {
  await expireDue();
  const g = (await db().query('SELECT * FROM gift_cards WHERE id=$1', [Number(id) || 0]))[0];
  if (!g) throw notFound('Cartão presente não encontrado.');
  const cfg = await getGiftConfig();
  const buyer = (await db().query('SELECT name, code FROM users WHERE id=$1', [g.buyer_id]))[0];
  const recipient = g.recipient_id ? (await db().query('SELECT name, code FROM users WHERE id=$1', [g.recipient_id]))[0] : null;
  let usage = { usedCents: 0, remainingCents: Number(g.amount_cents), entries: [] };
  if (recipient) {
    const u = await usageFor(g.recipient_id);
    const a = allocate(u.all, u.bal)[g.id] || usage;
    const KIND = { gift_redeem: 'Cartão Presente recebido' };
    const entries = await db().query(`SELECT * FROM wallet_ledger WHERE user_id=$1 AND bucket='gift' ORDER BY id`, [g.recipient_id]);
    usage = { usedCents: a.usedCents, remainingCents: a.remainingCents, entries: entries.map((e) => ({ id: Number(e.id), createdAt: e.created_at, kindLabel: KIND[e.kind] || 'Utilização em serviço', amountCents: Number(e.amount_cents), description: e.description || '' })) };
  }
  const charges = await db().query('SELECT * FROM charges WHERE gift_card_id=$1 ORDER BY id DESC', [g.id]);
  const events = await db().query('SELECT * FROM gift_events WHERE card_id=$1 ORDER BY id DESC', [g.id]);
  return {
    card: { ...cardView(g), validityDays: cfg.validityDays }, buyer, recipient, usage,
    charges: charges.map((c) => ({ id: Number(c.id), amountCents: Number(c.amount_cents), status: c.status, providerPaymentId: c.provider_payment_id, paidAt: c.paid_at, createdAt: c.created_at })),
    events: events.map(eventView),
  };
}

export async function adminEvents() {
  const rows = await db().query(
    `SELECT e.*, g.code AS code, u.name AS actor_name FROM gift_events e LEFT JOIN gift_cards g ON g.id=e.card_id LEFT JOIN users u ON u.id=e.actor_id ORDER BY e.id DESC LIMIT 300`);
  return { events: rows.map(eventView) };
}

const colorOk = (c) => /^#[0-9a-fA-F]{6}$/.test(String(c || ''));
export function sanitizeGiftConfig(b = {}, current) {
  const int = (v, min, max, label) => { const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) throw bad(`${label}: informe um número inteiro entre ${min} e ${max}.`); return n; };
  if (!Array.isArray(b.amounts) || !b.amounts.length || b.amounts.length > 20) throw bad('Cadastre de 1 a 20 valores.');
  const amounts = [...new Set(b.amounts.map((a) => int(a, 100, 1000000, 'Valor do cartão')))].sort((x, y) => x - y);
  const inactiveAmounts = [...new Set((b.inactiveAmounts || []).map(Number))].filter((a) => amounts.includes(a));
  if (!Array.isArray(b.models) || !b.models.length || b.models.length > 12) throw bad('Cadastre de 1 a 12 modelos.');
  const keys = new Set();
  const models = b.models.map((m) => {
    const key = String(m.key || '').toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 40);
    if (!key || keys.has(key)) throw bad('Identificador de modelo inválido ou repetido.');
    keys.add(key);
    const name = String(m.name || '').trim();
    if (!name || name.length > 40) throw bad('Informe o nome do modelo (até 40 caracteres).');
    if (!colorOk(m.from) || !colorOk(m.to) || !colorOk(m.ribbon)) throw bad('Cores do modelo inválidas.');
    return { key, name, tagline: String(m.tagline || '').trim().slice(0, 80), from: m.from, to: m.to, ribbon: m.ribbon, active: !!m.active };
  });
  const msgs = Array.isArray(b.defaultMessages) ? b.defaultMessages.map((x) => String(x).trim()).filter(Boolean) : [];
  if (msgs.length > 20 || msgs.some((x) => x.length > 280)) throw bad('Mensagens padrão: até 20, com no máximo 280 caracteres cada.');
  const cfg = {
    enabled: !!b.enabled, notifyBuyerOnUse: !!b.notifyBuyerOnUse, amounts, inactiveAmounts, models, validityDays: int(b.validityDays, 1, 1825, 'Validade'),
    terms: String(b.terms || '').slice(0, 2000), defaultMessages: msgs, pixCheck: current.pixCheck || null,
  };
  if (cfg.enabled && !models.some((m) => m.active)) throw bad('Deixe ao menos um modelo disponível para compra.');
  if (cfg.enabled && amounts.every((a) => inactiveAmounts.includes(a))) throw bad('Deixe ao menos um valor ativo.');
  return cfg;
}

// Verifica no Mercado Pago se um Pix deste valor é aceito (cria e cancela a cobrança de teste).
export async function pixCheck(admin, cents) {
  const amount = Number(cents);
  if (!Number.isInteger(amount) || amount < 100) throw bad('Informe um valor a partir de R$ 1,00.');
  let ok = false, message = '';
  try {
    const pay = await mp.createPixPayment({ amountCents: amount, description: 'Conferência de valor mínimo', payerEmail: admin.email || `admin${admin.id}@ivaslovck.invalid`, payerName: admin.name, externalReference: `ivs-check-${Date.now()}`, expiresAt: new Date(Date.now() + 30 * 60000).toISOString(), idempotencyKey: `ivs-check-${admin.id}-${amount}-${Date.now()}` });
    ok = true; message = 'O Mercado Pago gerou o Pix deste valor.';
    try { await mp.cancelPayment(pay.id); } catch { /* a cobrança de teste expira sozinha */ }
  } catch (e) { message = String(e.message || 'O Mercado Pago recusou a cobrança.').slice(0, 200); }
  const result = { ok, cents: amount, checkedAt: now(), message };
  const cfg = await getGiftConfig();
  await setSetting('giftConfig', { ...cfg, pixCheck: result }, admin.id);
  await db().query('INSERT INTO gift_events (card_id, kind, actor_id, detail, created_at) VALUES (NULL,$1,$2,$3,$4)', ['pix_check', admin.id, `Conferência de ${amount} centavos: ${ok ? 'aceita' : 'recusada'}. ${message}`, now()]);
  return result;
}

export async function saveGiftConfig(admin, body) {
  const reason = String(body.reason || '').trim();
  if (reason.length < 5) throw bad('Informe a justificativa da alteração (mínimo de 5 caracteres).');
  const current = await getGiftConfig();
  const cfg = sanitizeGiftConfig(body, current);
  const smallest = cfg.amounts.find((a) => !cfg.inactiveAmounts.includes(a));
  if (cfg.enabled && smallest !== undefined && smallest < 1000 && !(current.pixCheck?.ok && current.pixCheck.cents <= smallest)) {
    const chk = await pixCheck(admin, smallest);
    cfg.pixCheck = chk;
    if (!chk.ok) throw bad(`O Mercado Pago recusou o valor de R$ ${(smallest / 100).toFixed(2).replace('.', ',')}. ${chk.message}`);
  }
  cfg.updatedAt = now();
  await setSetting('giftConfig', cfg, admin.id);
  await db().query('INSERT INTO gift_events (card_id, kind, actor_id, detail, created_at) VALUES (NULL,$1,$2,$3,$4)', ['config_updated', admin.id, `Configurações alteradas: ${reason}`.slice(0, 400), now()]);
  await audit(db(), 'gift_config_changed', `Configurações do Cartão Presente alteradas: ${reason}`, { actorId: admin.id });
  MODEL_CACHE = cfg.models;
  return cfg;
}
