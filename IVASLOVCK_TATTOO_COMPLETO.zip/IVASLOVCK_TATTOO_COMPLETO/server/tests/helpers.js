// Utilitários de teste.
// IMPORTANTE: o "FakeMercadoPago" abaixo é um DUBLÊ DE TESTE que imita o contrato HTTP da API do
// Mercado Pago (POST/GET /v1/payments, GET /users/me). Ele existe só para testar o servidor sem
// internet e sem cobranças reais. Em produção o servidor fala com https://api.mercadopago.com.
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export function startFakeMp() {
  const payments = new Map();
  const idem = new Map();
  let seq = 900000;
  const calls = [];
  const server = http.createServer(async (req, res) => {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : null;
    calls.push({ method: req.method, url: req.url, body, headers: req.headers });
    const send = (s, d) => { res.writeHead(s, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(d)); };
    if (req.headers.authorization !== 'Bearer TEST-fake-token-1234567890abcdef') return send(401, { message: 'invalid access token' });
    if (req.method === 'GET' && req.url === '/users/me') return send(200, { id: 1, nickname: 'ESTUDIO_TESTE' });
    if (req.method === 'POST' && req.url === '/v1/payments') {
      const k = req.headers['x-idempotency-key'];
      if (k && idem.has(k)) return send(201, payments.get(idem.get(k)));
      const id = ++seq;
      const p = {
        id, status: 'pending', status_detail: 'pending_waiting_transfer', transaction_amount: body.transaction_amount,
        external_reference: body.external_reference, description: body.description,
        point_of_interaction: { transaction_data: { qr_code: `00020126PIXFAKE${id}`, qr_code_base64: null, ticket_url: `https://fake/${id}` } },
      };
      payments.set(id, p);
      if (k) idem.set(k, id);
      return send(201, p);
    }
    const m = /^\/v1\/payments\/(\d+)$/.exec(req.url);
    if (m && req.method === 'GET') {
      const p = payments.get(Number(m[1]));
      return p ? send(200, p) : send(404, { message: 'not found' });
    }
    send(404, { message: 'rota inexistente no dublê' });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => {
    resolve({
      url: `http://127.0.0.1:${server.address().port}`, payments, calls,
      approve(id, overrides = {}) { Object.assign(payments.get(Number(id)), { status: 'approved', status_detail: 'accredited', date_approved: new Date().toISOString(), ...overrides }); },
      setStatus(id, status) { payments.get(Number(id)).status = status; },
      close: () => new Promise((r) => server.close(r)),
    });
  }));
}

export class Client {
  constructor(base) { this.base = base; this.cookie = ''; }
  async req(method, url, body, { headers = {}, raw } = {}) {
    const h = { ...headers };
    if (this.cookie) h.cookie = this.cookie;
    let payload;
    if (raw) { payload = raw; } else if (body !== undefined) { h['content-type'] = 'application/json'; payload = JSON.stringify(body); }
    const res = await fetch(this.base + url, { method, headers: h, body: payload });
    const sc = res.headers.getSetCookie?.() || [];
    for (const c of sc) {
      const [kv] = c.split(';');
      if (kv.startsWith('ivs_session=')) this.cookie = kv.endsWith('=') ? '' : kv;
    }
    const data = await res.json().catch(() => ({}));
    return { status: res.status, data };
  }
  get(u) { return this.req('GET', u); }
  post(u, b = {}, o) { return this.req('POST', u, b, o); }
  put(u, b = {}) { return this.req('PUT', u, b); }
  patch(u, b = {}) { return this.req('PATCH', u, b); }
}

export function tmpDbPath() {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'ivs-')), 'test.sqlite');
}
export const uuid = () => crypto.randomUUID();
