import { requireUser, requireAdmin, requireOwner } from '../auth.js';
import { bad, HttpError } from '../http.js';
import * as gifts from '../services/gifts.js';
import * as charges from '../services/charges.js';

const num = (v) => Number(v) || 0;

export default function register(r) {
  r.get('/api/gifts/presentation', async () => gifts.catalog());
  r.get('/api/gifts/catalog', async (req) => { requireUser(req); return gifts.catalog(); });

  r.post('/api/gifts/me', async (req) => {
    const u = requireUser(req);
    const card = await gifts.createCard(u, req.body || {});
    let chargeId = null;
    if (card.status === 'awaiting_payment') {
      try { chargeId = Number((await charges.createGiftCharge(u, card.id, `gift-${card.id}`)).id); } catch { /* o comprador gera o Pix depois, na tela do cartão */ }
    }
    return { card: gifts.cardView(card), chargeId };
  });
  r.get('/api/gifts/me', async (req) => gifts.listMine(requireUser(req)));
  r.get('/api/gifts/me/comprovante/:code', async (req) => gifts.receipt(requireUser(req), req.params.code));
  r.get('/api/gifts/me/:id', async (req) => gifts.getMine(requireUser(req), req.params.id));
  r.post('/api/gifts/me/:id/pay', async (req) => {
    const u = requireUser(req);
    const key = String(req.body?.idempotencyKey || '');
    const c = await charges.createGiftCharge(u, num(req.params.id), key);
    return { chargeId: Number(c.id) };
  });

  r.get('/api/gifts/public/:token', async (req) => gifts.publicByToken(req.params.token));
  r.post('/api/gifts/public/:token/claim', async (req) => gifts.claim(requireUser(req), req.params.token));

  // ---------- administração ----------
  r.get('/api/gifts/admin/overview', async (req) => { requireAdmin(req); return gifts.adminOverview(); });
  r.get('/api/gifts/admin/cards', async (req) => { requireAdmin(req); return gifts.adminCards({ q: req.query.get('q') || '', status: req.query.get('status') || '' }); });
  r.get('/api/gifts/admin/cards/:id', async (req) => { requireAdmin(req); return gifts.adminCard(req.params.id); });
  r.get('/api/gifts/admin/events', async (req) => { requireAdmin(req); return gifts.adminEvents(); });
  r.put('/api/gifts/admin/config', async (req) => ({ config: await gifts.saveGiftConfig(requireOwner(req), req.body || {}) }));
  r.post('/api/gifts/admin/pix-check', async (req) => ({ pixCheck: await gifts.pixCheck(requireOwner(req), req.body?.cents) }));

  // Cobranças Pix (compartilhadas com parcelamento, upgrade e taxa de cartão — esses módulos ainda não foram reconstruídos).
  r.post('/api/credit/me/charges', async (req) => {
    const u = requireUser(req); const b = req.body || {};
    if (b.giftCardId) return { charge: charges.chargeView(await charges.createGiftCharge(u, num(b.giftCardId), b.idempotencyKey)) };
    if (b.installmentId || b.upgradeRequestId || b.cardRequestId) throw new HttpError(501, 'Este tipo de cobrança ainda não foi reconstruído no servidor próprio.');
    throw bad('Informe o que será pago.');
  });
  r.get('/api/credit/me/charges/:id', async (req) => {
    const u = requireUser(req);
    const c = await charges.getOwnCharge(u, req.params.id);
    const out = { charge: charges.chargeView(c) };
    if (c.gift_card_id) { const g = await gifts.getMine(u, c.gift_card_id); out.giftCard = { id: g.card.id, code: g.card.code, recipientName: g.card.recipientName, status: g.card.status }; }
    return out;
  });
}
