// Testes de ponta a ponta dos fluxos financeiros. Rodam contra o servidor real (HTTP) e um banco real
// (SQLite temporário por padrão; PostgreSQL de teste se TEST_DATABASE_URL estiver definido).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { startFakeMp, Client, tmpDbPath, uuid } from './helpers.js';

const results = [];
const record = (n, name, ok, detail = '') => results.push({ n, name, ok, detail });

let fake, base, server, mod, dbmod, sqlitePath;
const SECRET = 'whsec_test_0123456789abcdef';

async function boot() {
  await dbmod.initDb();
  server = mod.createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
}
async function shutdown() {
  await new Promise((r) => server.close(r));
  await dbmod.closeDb();
}

before(async () => {
  fake = await startFakeMp();
  sqlitePath = tmpDbPath();
  if (process.env.TEST_DATABASE_URL) {
    if (!/test/i.test(process.env.TEST_DATABASE_URL)) throw new Error('TEST_DATABASE_URL precisa apontar para um banco de TESTE (nome contendo "test").');
    process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
  } else {
    process.env.DATABASE_URL = '';
  }
  Object.assign(process.env, {
    SQLITE_PATH: sqlitePath, MP_API_BASE: fake.url, MP_ACCESS_TOKEN: 'TEST-fake-token-1234567890abcdef',
    MP_WEBHOOK_SECRET: SECRET, ADMIN_SETUP_TOKEN: 'setup-token-teste', APP_SECRET: 'x'.repeat(40),
    APP_URL: 'http://localhost', UPLOADS_DIR: sqlitePath + '-uploads', JOBS_INTERVAL_MS: '3600000',
  });
  dbmod = await import('../src/db.js');
  if (process.env.TEST_DATABASE_URL) {
    const pg = (await import('pg')).default;
    const c = new pg.Client({ connectionString: process.env.TEST_DATABASE_URL });
    await c.connect(); await c.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;'); await c.end();
  }
  mod = await import('../src/index.js');
  await boot();
});

after(async () => {
  await shutdown().catch(() => {});
  await fake.close();
  console.log('\n===RESULTADOS===\n' + JSON.stringify(results, null, 1));
});

function signedWebhookHeaders(id) {
  const ts = String(Date.now());
  const reqId = uuid();
  const v1 = crypto.createHmac('sha256', SECRET).update(`id:${id};request-id:${reqId};ts:${ts};`).digest('hex');
  return { 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': reqId };
}
async function sendWebhook(id, headers = signedWebhookHeaders(id)) {
  return new Client(base).req('POST', `/api/webhooks/mercadopago?data.id=${id}&type=payment`, { action: 'payment.updated', type: 'payment', data: { id: String(id) } }, { headers });
}

const ctx = {};

test('01 cadastro de cliente (sem verificação de e-mail, sem duplicidade)', async () => {
  const c = new Client(base);
  const r = await c.post('/api/auth/register', { name: 'Maria Teste Silva', whatsapp: '(11) 98888-7777', email: 'Maria@Teste.com', password: 'segredo1' });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.user.email, 'maria@teste.com');
  assert.equal(r.data.user.code, 'IVT0001');
  const dupE = await new Client(base).post('/api/auth/register', { name: 'Outra Pessoa', whatsapp: '11977776666', email: 'maria@teste.com', password: 'segredo1' });
  assert.equal(dupE.status, 409);
  const dupW = await new Client(base).post('/api/auth/register', { name: 'Outra Pessoa', whatsapp: '11988887777', email: 'outra@teste.com', password: 'segredo1' });
  assert.equal(dupW.status, 409);
  ctx.client = c;
  ctx.clientId = r.data.user.id;
  record(1, 'Cadastro de cliente', true, 'código IVT0001; e-mail e WhatsApp duplicados recusados (409)');
});

test('02 login e logout', async () => {
  const c = new Client(base);
  assert.equal((await c.post('/api/auth/login', { login: 'maria@teste.com', password: 'errada' })).status, 401);
  const r = await c.post('/api/auth/login', { login: '11988887777', password: 'segredo1' });
  assert.equal(r.status, 200);
  assert.equal((await c.get('/api/auth/me')).status, 200);
  await c.post('/api/auth/logout');
  assert.equal((await c.get('/api/auth/me')).status, 401);
  record(2, 'Login e logout', true, 'login por WhatsApp; senha errada 401; sessão encerrada após logout');
});

test('admin: criação do primeiro administrador e configuração', async () => {
  const a = new Client(base);
  assert.equal((await a.get('/api/auth/admin-setup')).data.needed, true);
  assert.equal((await a.post('/api/auth/admin-setup', { name: 'Dono Estudio', whatsapp: '11911112222', email: 'dono@estudio.com', password: 'adminpass', setupToken: 'errado' })).status, 403);
  const r = await a.post('/api/auth/admin-setup', { name: 'Dono Estudio', whatsapp: '11911112222', email: 'dono@estudio.com', password: 'adminpass', setupToken: 'setup-token-teste' });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.user.role, 'owner');
  assert.equal((await a.get('/api/auth/admin-setup')).data.needed, false);
  const s = await a.get('/api/admin/settings');
  assert.equal(s.data.mpConfigured, true);
  assert.equal((await a.post('/api/admin/settings/test')).data.account, 'ESTUDIO_TESTE');
  ctx.admin = a;
});

test('14 gestão administrativa de planos', async () => {
  const a = ctx.admin;
  const p = await a.post('/api/admin/plans', { name: 'Tattoo 300', category: 'tatuagem', description: 'Plano de teste', totalCents: 30000, minPaymentCents: 1000, dailyOptions: [10000], allowCustom: false, period: 'weekly', allowAdvance: true, allowMultiple: true, featured: true, active: true });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  ctx.planId = p.data.plan.id;
  const p2 = await a.post('/api/admin/plans', { name: 'Piercing 50', category: 'piercing', totalCents: 5000, minPaymentCents: 5000, dailyOptions: [5000], period: 'monthly', allowMultiple: false, active: true });
  ctx.plan2 = p2.data.plan.id;
  assert.equal((await a.post(`/api/admin/plans/${ctx.plan2}/toggle`)).data.active, false);
  const pub = await new Client(base).get('/api/plans');
  assert.deepEqual(pub.data.plans.map((x) => x.id), [ctx.planId]);
  assert.equal((await a.post(`/api/admin/plans/${ctx.plan2}/toggle`)).data.active, true);
  assert.equal((await a.post('/api/admin/plans', { name: 'Inválido', category: 'tatuagem', totalCents: 0, minPaymentCents: 1, period: 'daily' })).status, 400);
  record(14, 'Gestão administrativa', true, 'criar/editar/pausar/reativar planos; validação; configurações e teste de credencial MP');
});

test('03/04 criação e consulta de carteira e saldo', async () => {
  const c = ctx.client;
  const s = await c.get('/api/me/summary');
  assert.equal(s.status, 200);
  assert.equal(s.data.balanceCents, 0);
  const w = await c.get('/api/me/wallet');
  assert.equal(w.data.totalCents, 0);
  record(3, 'Criação e consulta de carteira', true, 'carteira criada sob demanda, saldo inicial 0');
  record(4, 'Consulta de saldo', true, 'summary e wallet retornam saldo 0 antes de qualquer pagamento');
});

test('12 contratação de plano (aceite de termos com hash)', async () => {
  const c = ctx.client;
  const terms = await c.post('/api/policies/preview', { kind: 'plan', planId: ctx.planId, dailyCents: 10000, benefitCents: 0 });
  assert.equal(terms.status, 200);
  const bad = await c.post('/api/me/subscriptions', { planId: ctx.planId, dailyCents: 10000, acceptTerms: true, termsVersion: terms.data.termsVersion, contractHash: 'adulterado' });
  assert.equal(bad.status, 409);
  const notAllowed = await c.post('/api/me/subscriptions', { planId: ctx.planId, dailyCents: 7000, acceptTerms: true, termsVersion: terms.data.termsVersion, contractHash: terms.data.contractHash });
  assert.equal(notAllowed.status, 400);
  const r = await c.post('/api/me/subscriptions', { planId: ctx.planId, dailyCents: 10000, acceptTerms: true, termsVersion: terms.data.termsVersion, contractHash: terms.data.contractHash });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.subscription.status, 'awaiting_first_payment');
  ctx.subId = r.data.subscription.id;
  const again = await c.post('/api/me/subscriptions', { planId: ctx.planId, dailyCents: 10000, acceptTerms: true, termsVersion: terms.data.termsVersion, contractHash: terms.data.contractHash });
  assert.equal(again.status, 409);
  record(12, 'Contratação de plano', true, 'hash do contrato validado; valor fora das opções recusado; uma contratação aberta por cliente');
});

test('05/06 recarga (parcela) e Pix: QR Code e copia-e-cola', async () => {
  const c = ctx.client;
  const sub = (await c.get(`/api/me/subscriptions/${ctx.subId}`)).data.subscription;
  assert.equal(sub.minPayCents, 10000);
  const tooMuch = await c.post('/api/me/payments', { subscriptionId: ctx.subId, amountCents: 40000, expectedChargesCents: 0, idempotencyKey: uuid() });
  assert.equal(tooMuch.status, 400);
  const key = uuid();
  const r = await c.post('/api/me/payments', { subscriptionId: ctx.subId, amountCents: 10000, expectedChargesCents: 0, idempotencyKey: key });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.payment.status, 'pending');
  assert.match(r.data.payment.qrCode, /^00020126PIXFAKE/);
  assert.ok('qrCodeBase64' in r.data.payment);
  const same = await c.post('/api/me/payments', { subscriptionId: ctx.subId, amountCents: 10000, expectedChargesCents: 0, idempotencyKey: key });
  assert.equal(same.data.payment.id, r.data.payment.id, 'mesma chave de idempotência deve devolver o mesmo Pix');
  assert.equal(fake.calls.filter((x) => x.method === 'POST' && x.url === '/v1/payments').length, 1);
  ctx.pay1 = r.data.payment;
  const s = await c.get('/api/me/summary');
  assert.equal(s.data.balanceCents, 0, 'Pix pendente não gera saldo');
  record(5, 'Recarga (pagamento de parcela)', true, 'limites mínimo/máximo validados no servidor; Pix pendente não gera saldo');
  record(6, 'Pagamento via Pix', true, 'QR Code base64 + copia-e-cola retornados; clique duplo/retentativa não cria segundo Pix (idempotência)');
});

test('07/08/09 webhook, confirmação e proteção contra duplicidade', async () => {
  const c = ctx.client;
  // webhook com assinatura inválida é recusado
  const forged = await sendWebhook(ctx.pay1.providerId, { 'x-signature': 'ts=1,v1=deadbeef', 'x-request-id': 'x' });
  assert.equal(forged.status, 401);
  // webhook válido mas pagamento ainda pendente no MP -> nada muda
  assert.equal((await sendWebhook(ctx.pay1.providerId)).status, 200);
  assert.equal((await c.get(`/api/me/payments/${ctx.pay1.id}`)).data.payment.status, 'pending');
  // banco confirma
  fake.approve(ctx.pay1.providerId);
  const many = await Promise.all(Array.from({ length: 6 }, () => sendWebhook(ctx.pay1.providerId)));
  assert.ok(many.every((x) => x.status === 200));
  const p = await c.get(`/api/me/payments/${ctx.pay1.id}`);
  assert.equal(p.data.payment.status, 'approved');
  const sub = (await c.get(`/api/me/subscriptions/${ctx.subId}`)).data.subscription;
  assert.equal(sub.status, 'active');
  assert.equal(sub.paidCents, 10000, 'seis webhooks simultâneos devem aplicar o pagamento uma única vez');
  assert.equal((await c.get('/api/me/summary')).data.balanceCents, 0, 'crédito só é liberado na quitação');
  record(7, 'Recebimento de webhook', true, 'assinatura x-signature validada (forjada = 401); servidor consulta a API antes de aplicar');
  record(9, 'Proteção contra pagamento duplicado', true, '6 webhooks simultâneos → pagamento aplicado 1 vez (paidCents = 10000)');
});

test('08 crédito liberado somente após quitação confirmada', async () => {
  const c = ctx.client;
  const r = await c.post('/api/me/payments', { subscriptionId: ctx.subId, amountCents: 20000, expectedChargesCents: 0, idempotencyKey: uuid() });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  // enquanto há Pix pendente cobrindo o restante, um novo Pix é bloqueado
  const blocked = await c.post('/api/me/payments', { subscriptionId: ctx.subId, amountCents: 10000, expectedChargesCents: 0, idempotencyKey: uuid() });
  assert.equal(blocked.status, 409);
  fake.approve(r.data.payment.providerId);
  // confirmação via sincronização administrativa (caminho alternativo ao webhook)
  const sy = await ctx.admin.post(`/api/admin/payments/${r.data.payment.id}/sync`);
  assert.equal(sy.data.payment.status, 'approved');
  await sendWebhook(r.data.payment.providerId); // webhook atrasado não duplica
  const s = await c.get('/api/me/summary');
  assert.equal(s.data.balanceCents, 30000);
  assert.equal(s.data.planCreditCents, 30000);
  const sub = (await c.get(`/api/me/subscriptions/${ctx.subId}`)).data.subscription;
  assert.equal(sub.status, 'completed');
  record(8, 'Crédito após confirmação de pagamento', true, 'saldo 0 durante o plano; R$ 300,00 liberados apenas na quitação; webhook atrasado não duplica');
});

test('pagamento com valor divergente vai para conciliação (não credita)', async () => {
  // novo cliente com plano
  const c = new Client(base);
  await c.post('/api/auth/register', { name: 'Joao Divergente', whatsapp: '11955554444', email: 'joao@teste.com', password: 'segredo1' });
  const t = (await c.post('/api/policies/preview', { planId: ctx.plan2, dailyCents: 5000 })).data;
  const s = (await c.post('/api/me/subscriptions', { planId: ctx.plan2, dailyCents: 5000, acceptTerms: true, termsVersion: t.termsVersion, contractHash: t.contractHash })).data.subscription;
  const p = (await c.post('/api/me/payments', { subscriptionId: s.id, amountCents: 5000, expectedChargesCents: 0, idempotencyKey: uuid() })).data.payment;
  fake.approve(p.providerId, { transaction_amount: 1.0 });
  await sendWebhook(p.providerId);
  assert.equal((await c.get(`/api/me/payments/${p.id}`)).data.payment.status, 'reconciliation');
  assert.equal((await c.get('/api/me/summary')).data.balanceCents, 0);
  const list = await ctx.admin.get('/api/admin/payments?status=reconciliation');
  assert.equal(list.data.payments.length, 1);
  assert.equal((await ctx.admin.post(`/api/admin/payments/${p.id}/reconcile`, { note: 'Devolvido via Pix' })).status, 200);
  ctx.client2 = c;
});

test('10 débito de saldo (cobrança de resgate) e proteção contra gasto duplo', async () => {
  const a = ctx.admin, c = ctx.client;
  const over = await a.post(`/api/admin/clients/${ctx.clientId}/redemptions`, { amountCents: 30001, description: 'Excesso' });
  assert.equal(over.status, 409);
  const r1 = (await a.post(`/api/admin/clients/${ctx.clientId}/redemptions`, { amountCents: 20000, description: 'Tatuagem antebraço' })).data.redemption;
  const r2 = await a.post(`/api/admin/clients/${ctx.clientId}/redemptions`, { amountCents: 20000, description: 'Segunda' });
  assert.equal(r2.status, 409, 'saldo reservado pela primeira cobrança impede a segunda');
  assert.equal((await a.post(`/api/admin/redemptions/${r1.id}/confirm`, { code: 'ERRADO12' })).status, 400);
  const pend = (await c.get('/api/me/redemptions')).data.redemptions;
  assert.equal(pend.length, 1);
  const both = await Promise.all([
    c.post(`/api/me/redemptions/${r1.id}/authorize`, {}),
    a.post(`/api/admin/redemptions/${r1.id}/confirm`, { code: pend[0].code }),
  ]);
  assert.ok(both.every((x) => x.status === 200), JSON.stringify(both.map((x) => x.data)));
  const s = await c.get('/api/me/summary');
  assert.equal(s.data.balanceCents, 10000, 'débito aplicado uma única vez mesmo com confirmação simultânea');
  const h = await c.get('/api/me/history');
  assert.equal(h.data.redemptions.length, 1);
  record(10, 'Débito de saldo', true, 'saldo insuficiente recusado; reserva de saldo; código errado recusado; autorização simultânea (app + código) debita 1 vez');
});

test('11 movimentação de IVT COIN (separada dos reais)', async () => {
  const a = ctx.admin, c = ctx.client;
  const key = uuid();
  const g = await a.post('/api/coins/admin/grant', { userId: ctx.clientId, amount: 500, note: 'Bônus de teste', idempotencyKey: key });
  assert.equal(g.status, 200, JSON.stringify(g.data));
  await a.post('/api/coins/admin/grant', { userId: ctx.clientId, amount: 500, note: 'Bônus de teste', idempotencyKey: key });
  let w = (await c.get('/api/coins/me/wallet')).data;
  assert.equal(w.wallet.balance, 500, 'lançamento repetido com a mesma chave não duplica');
  assert.equal((await a.post('/api/coins/admin/debit', { userId: ctx.clientId, amount: 501, note: 'x', idempotencyKey: uuid() })).status, 409);
  assert.equal((await a.post('/api/coins/admin/debit', { userId: ctx.clientId, amount: 100, note: 'Ajuste', destination: 'burn', idempotencyKey: uuid() })).status, 200);
  w = (await c.get('/api/coins/me/wallet')).data;
  assert.equal(w.wallet.balance, 400);
  assert.equal((await c.get('/api/me/summary')).data.balanceCents, 10000, 'IVT COIN não altera o saldo em reais');
  // conversão desabilitada por padrão
  assert.equal((await c.post('/api/coins/me/convert', { coins: 100, idempotencyKey: uuid() })).status, 409);
  // estúdio configura cotação (100 IVT = R$ 1,00) e habilita
  assert.equal((await a.put('/api/coins/admin/conversion-config', { enabled: true, rateCoins: 100, rateCents: 100, minCoins: 100 })).status, 200);
  const ck = uuid();
  const cv = await c.post('/api/coins/me/convert', { coins: 200, idempotencyKey: ck });
  assert.equal(cv.status, 200, JSON.stringify(cv.data));
  await c.post('/api/coins/me/convert', { coins: 200, idempotencyKey: ck });
  const s = (await c.get('/api/me/summary')).data;
  assert.equal(s.balanceCents, 10200);
  assert.equal(s.coinCreditCents, 200);
  assert.equal((await c.get('/api/coins/me/wallet')).data.wallet.balance, 200);
  const ov = (await a.get('/api/coins/admin/overview')).data;
  assert.equal(ov.supply.consistent, true);
  record(11, 'Movimentação de IVT COIN', true, 'crédito/débito idempotentes; saldo insuficiente recusado; reais intocados; conversão só após configuração explícita, com dupla escrituração');
});

test('13 benefícios: cartões digitais e elegibilidade', async () => {
  const a = ctx.admin, c = ctx.client;
  const models = (await a.get('/api/admin/card-models')).data.models;
  assert.deepEqual(models.map((m) => m.code).sort(), ['black', 'gold', 'silver']);
  const gold = models.find((m) => m.code === 'gold');
  await a.put(`/api/admin/card-models/${gold.id}`, { name: gold.name, description: '', eligibility: 'completed_plan', minCreditCents: 0 });
  const users = (await a.get('/api/admin/clients?q=joao')).data.clients;
  const el = (await a.get(`/api/admin/card-models/${gold.id}/eligibility?userId=${users[0].id}`)).data;
  assert.equal(el.eligible, false);
  const issue = await a.post('/api/admin/cards', { userId: ctx.clientId, modelId: gold.id, validityMonths: 36 });
  assert.equal(issue.status, 200, JSON.stringify(issue.data));
  const cards = (await c.get('/api/me/cards')).data;
  assert.equal(cards.cards.length, 1);
  assert.equal(cards.cards[0].balanceCents, 10200);
  assert.equal((await c.post(`/api/me/cards/${cards.cards[0].id}/block`)).status, 200);
  assert.equal((await c.post(`/api/me/cards/${cards.cards[0].id}/unblock`)).status, 200);
  record(13, 'Consulta de benefícios (cartões/categorias)', true, 'modelos BLACK/GOLD/SILVER; regra de elegibilidade "plano quitado" aplicada; emissão, bloqueio e desbloqueio');
});

test('15 histórico financeiro e painel', async () => {
  const c = ctx.client, a = ctx.admin;
  const h = (await c.get('/api/me/history')).data;
  assert.equal(h.payments.length, 2);
  const st = (await a.get('/api/admin/stats')).data;
  assert.equal(st.receivedCents, 30000, 'receita = só Pix aprovados (não inclui conciliação, coins ou créditos)');
  assert.equal(st.creditsReleasedCents, 30000);
  assert.equal(st.creditsUsedCents, 20000);
  assert.equal(st.reconciliationCents, 0);
  const ops = (await a.get('/api/admin/operations')).data.operations;
  assert.ok(ops.some((o) => o.type === 'payment_approved') && ops.some((o) => o.type === 'credit_released'));
  const detail = (await a.get(`/api/admin/clients/${ctx.clientId}`)).data;
  assert.equal(detail.wallet.totalCents, 10200);
  record(15, 'Histórico financeiro', true, 'histórico do cliente, operações auditadas e indicadores do painel separados por natureza');
});

test('17 controle de permissões', async () => {
  const c = ctx.client;
  assert.equal((await c.get('/api/admin/stats')).status, 403);
  assert.equal((await c.post('/api/coins/admin/grant', { userId: ctx.clientId, amount: 1000, idempotencyKey: uuid() })).status, 403);
  assert.equal((await new Client(base).get('/api/me/summary')).status, 401);
  // cliente 2 não enxerga pagamento do cliente 1
  assert.equal((await ctx.client2.get(`/api/me/payments/${ctx.pay1.id}`)).status, 404);
  assert.equal((await ctx.client2.get(`/api/me/subscriptions/${ctx.subId}`)).status, 404);
  // cliente não consegue logar no painel
  assert.equal((await new Client(base).post('/api/auth/login', { login: 'maria@teste.com', password: 'segredo1', admin: true })).status, 403);
  // requisição de outra origem é recusada
  const cross = await c.req('POST', '/api/me/payments', {}, { headers: { origin: 'https://site-malicioso.com' } });
  assert.equal(cross.status, 403);
  record(17, 'Controle de permissões', true, 'cliente sem acesso ao admin (403); sem sessão (401); isolamento entre contas (404); origem cruzada bloqueada');
});

test('18 integridade das transações', async () => {
  const a = ctx.admin;
  const integ = (await a.get('/api/admin/integrity')).data;
  assert.equal(integ.ok, true, JSON.stringify(integ));
  // livro-razão imutável no próprio banco
  await assert.rejects(dbmod.db().query('UPDATE wallet_ledger SET amount_cents = 999999'));
  await assert.rejects(dbmod.db().query('DELETE FROM coin_ledger'));
  // saldo negativo impossível mesmo por SQL direto
  await assert.rejects(dbmod.db().query('UPDATE wallets SET balance_cents = -1, plan_cents = -1'));
  // frontend não consegue creditar: não existe rota de crédito para o cliente e rotas desconhecidas não fazem nada
  const c = ctx.client;
  const before = (await c.get('/api/me/summary')).data.balanceCents;
  await c.post('/api/me/wallet', { balanceCents: 999999 });
  await c.post('/api/me/payments/1/approve', {});
  assert.equal((await c.get('/api/me/summary')).data.balanceCents, before);
  record(18, 'Integridade das transações', true, 'saldos = livro-razão; UPDATE/DELETE em ledgers bloqueados por trigger; saldo negativo bloqueado por CHECK; frontend não credita');
});

test('expiração: contratação sem primeiro pagamento é cancelada', async () => {
  const c = new Client(base);
  await c.post('/api/auth/register', { name: 'Ana Prazo Teste', whatsapp: '11933332222', email: 'ana@teste.com', password: 'segredo1' });
  const t = (await c.post('/api/policies/preview', { planId: ctx.plan2, dailyCents: 5000 })).data;
  const s = (await c.post('/api/me/subscriptions', { planId: ctx.plan2, dailyCents: 5000, acceptTerms: true, termsVersion: t.termsVersion, contractHash: t.contractHash })).data.subscription;
  await dbmod.db().query('UPDATE subscriptions SET first_payment_due_at=$1 WHERE id=$2', [new Date(Date.now() - 60000).toISOString(), s.id]);
  const subsMod = await import('../src/services/subscriptions.js');
  await subsMod.expireDue(true);
  assert.equal((await c.get(`/api/me/subscriptions/${s.id}`)).data.subscription.status, 'cancelled_unpaid');
});

test('16 persistência após reinicialização', async () => {
  await shutdown();
  await boot();
  for (const k of ['admin', 'client', 'client2']) ctx[k].base = base; // nova porta após reiniciar
  const c = new Client(base);
  const r = await c.post('/api/auth/login', { login: 'maria@teste.com', password: 'segredo1' });
  assert.equal(r.status, 200);
  const s = (await c.get('/api/me/summary')).data;
  assert.equal(s.balanceCents, 10200);
  assert.equal((await c.get('/api/coins/me/wallet')).data.wallet.balance, 200);
  const integ = (await ctx.admin.get('/api/admin/integrity'));
  assert.equal(integ.status, 200, 'sessão do admin sobrevive à reinicialização');
  assert.equal(integ.data.ok, true);
  record(16, 'Persistência após reinicialização', true, 'servidor e banco reiniciados; saldos, moedas e sessões preservados');
});

test('módulos não reconstruídos respondem 501 (sem dados falsos)', async () => {
  const r = await ctx.client.get('/api/market/me/home');
  assert.equal(r.status, 501);
  assert.match(r.data.error, /Marketplace/);
});
