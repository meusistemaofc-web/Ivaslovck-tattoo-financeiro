import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { db } from '../db.js';
import { config } from '../config.js';
import { bad, conflict, notFound } from '../http.js';
import { requireUser, publicUser } from '../auth.js';
import { getSetting, audit } from '../services/settings.js';
import * as subs from '../services/subscriptions.js';
import * as wallet from '../services/wallet.js';
import * as red from '../services/redemptions.js';
import * as coins from '../services/coins.js';
import { cardView } from './cards.js';

const bool = (v) => v === true || v === 1;
const STATEMENT_TITLE = { plan_release: 'Crédito de plano liberado', redemption: 'Utilização no estúdio', coin_conversion: 'Conversão de IVT COINS' };
const STATEMENT_ORIGIN = { plan: 'Plano quitado', gift: 'Cartão Presente', conversion: 'IVT COIN' };

async function loadSub(userId, id) {
  const s = (await db().query('SELECT * FROM subscriptions WHERE id=$1 AND user_id=$2', [id, userId]))[0];
  if (!s) throw notFound('Plano não encontrado.');
  return s;
}

export async function walletView(userId) {
  const w = await wallet.getWallet(db(), userId);
  return { totalCents: w.balance_cents, planCents: w.plan_cents, giftCents: w.gift_cents, conversionCents: w.conversion_cents };
}

export default function register(r) {
  // ---------- Planos (público) ----------
  r.get('/api/plans', async () => {
    const rows = await db().query('SELECT * FROM plans WHERE active = TRUE ORDER BY sort_order, id');
    return { plans: rows.map((p) => subs.planView(p)) };
  });
  r.get('/api/plans/:id', async (req) => {
    const p = (await db().query('SELECT * FROM plans WHERE id=$1', [Number(req.params.id) || 0]))[0];
    if (!p || !bool(p.active)) throw notFound('Plano não encontrado.');
    return { plan: subs.planView(p) };
  });

  // ---------- Resumo / carteira ----------
  r.get('/api/me/summary', async (req) => {
    const u = requireUser(req);
    await subs.expireDue();
    await red.expireRedemptions();
    const w = await wallet.getWallet(db(), u.id);
    const open = await db().query(`SELECT * FROM subscriptions WHERE user_id=$1 AND status IN ('awaiting_first_payment','active') ORDER BY id DESC`, [u.id]);
    const active = open.find((s) => s.status === 'active');
    const pending = open.find((s) => s.status === 'awaiting_first_payment');
    const view = async (s) => (s ? subs.subscriptionView(s, { pendingCents: await subs.pendingCentsFor(db(), s.id) }) : null);
    const recent = await db().query(
      `SELECT p.id, p.amount_cents, p.paid_at, s.plan_name FROM payments p JOIN subscriptions s ON s.id=p.subscription_id
       WHERE p.user_id=$1 AND p.status='approved' ORDER BY p.paid_at DESC LIMIT 5`, [u.id]);
    const pendRed = await db().query(`SELECT COUNT(*) AS c FROM redemptions WHERE user_id=$1 AND status='pending'`, [u.id]);
    return {
      user: publicUser(u),
      balanceCents: w.balance_cents, planCreditCents: w.plan_cents, giftCreditCents: w.gift_cents, coinCreditCents: w.conversion_cents,
      activeSubscription: await view(active), pendingSubscription: await view(pending),
      recentPayments: recent.map((p) => ({ id: p.id, amountCents: p.amount_cents, paidAt: p.paid_at, planName: p.plan_name })),
      pendingRedemptions: Number(pendRed[0].c), lateCharges: null,
      firstPaymentHours: Number(await getSetting('firstPaymentHours')) || 24,
    };
  });

  r.get('/api/me/wallet', async (req) => {
    const u = requireUser(req);
    const v = await walletView(u.id);
    const entries = await db().query('SELECT * FROM wallet_ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 100', [u.id]);
    return {
      ...v,
      entries: entries.map((e) => ({ id: e.id, amountCents: e.amount_cents, bucket: e.bucket, kind: e.kind, description: e.description, balanceAfter: e.balance_after, createdAt: e.created_at })),
      statement: entries.map((e) => ({
        id: e.id, type: e.kind, gift: e.bucket === 'gift', amountCents: e.amount_cents, at: e.created_at,
        title: e.description || STATEMENT_TITLE[e.kind] || e.kind, origin: STATEMENT_ORIGIN[e.bucket] || e.bucket, status: 'Concluído',
        detail: `Saldo após: R$ ${(e.balance_after / 100).toFixed(2).replace('.', ',')}`, code: `#${e.id}`,
      })),
      gifts: [], conversions: [], benefitReservedCents: 0, otherBenefitCents: 0,
    };
  });

  r.get('/api/me/history', async (req) => {
    const u = requireUser(req);
    const pays = await db().query(
      `SELECT p.*, s.plan_name FROM payments p JOIN subscriptions s ON s.id=p.subscription_id WHERE p.user_id=$1 AND p.status='approved' ORDER BY p.paid_at DESC`, [u.id]);
    const reds = await db().query(`SELECT * FROM redemptions WHERE user_id=$1 AND status='confirmed' ORDER BY confirmed_at DESC`, [u.id]);
    return {
      payments: pays.map((p) => ({ id: p.id, amountCents: p.amount_cents, paidAt: p.paid_at, planName: p.plan_name })),
      redemptions: reds.map((x) => red.redemptionView(x)),
    };
  });

  // ---------- Contratações ----------
  r.get('/api/me/subscriptions', async (req) => {
    const u = requireUser(req);
    await subs.expireDue();
    const rows = await db().query('SELECT * FROM subscriptions WHERE user_id=$1 ORDER BY id DESC', [u.id]);
    const out = [];
    for (const s of rows) out.push(subs.subscriptionView(s, { pendingCents: await subs.pendingCentsFor(db(), s.id) }));
    return { subscriptions: out };
  });
  r.get('/api/me/subscriptions/:id', async (req) => {
    const u = requireUser(req);
    await subs.expireDue();
    const s = await loadSub(u.id, Number(req.params.id) || 0);
    const plan = (await db().query('SELECT image_url FROM plans WHERE id=$1', [s.plan_id]))[0];
    const pays = await db().query(`SELECT * FROM payments WHERE subscription_id=$1 AND status='approved' ORDER BY paid_at DESC`, [s.id]);
    return { subscription: subs.subscriptionView(s, { pendingCents: await subs.pendingCentsFor(db(), s.id) }), imageUrl: plan?.image_url || null, payments: pays.map(subs.paymentView) };
  });
  r.post('/api/me/subscriptions', async (req) => {
    const u = requireUser(req);
    const s = await subs.createSubscription(u, req.body);
    return { subscription: subs.subscriptionView(s) };
  });
  r.post('/api/me/subscriptions/:id/cancel', async (req) => {
    const u = requireUser(req);
    await subs.cancelSubscriptionByClient(u, Number(req.params.id) || 0);
    return { ok: true };
  });

  // Termo de contratação (texto gerado a partir do plano + cláusulas configuradas pelo estúdio)
  r.post('/api/policies/preview', async (req) => {
    requireUser(req);
    const { planId, dailyCents } = req.body || {};
    const p = (await db().query('SELECT * FROM plans WHERE id=$1', [Number(planId) || 0]))[0];
    if (!p) throw notFound('Plano não encontrado.');
    const d = Number(dailyCents);
    if (!Number.isInteger(d) || d <= 0) throw bad('Escolha o valor da contribuição.');
    return subs.buildTerms(p, d);
  });

  // Multas e juros: o módulo original não foi recuperado e NENHUMA regra está configurada.
  r.get('/api/late-fees/me/subscriptions/:id', async (req) => {
    const u = requireUser(req);
    await loadSub(u.id, Number(req.params.id) || 0);
    return { open: [], totals: { count: 0, principalCents: 0, chargesCents: 0, fineDueCents: 0, interestDueCents: 0, correctionDueCents: 0, discountCents: 0, totalCents: 0 }, ruleLines: [] };
  });

  // ---------- Pagamentos ----------
  r.get('/api/me/payments', async (req) => {
    const u = requireUser(req);
    const rows = await db().query('SELECT * FROM payments WHERE user_id=$1 ORDER BY id DESC LIMIT 200', [u.id]);
    return { payments: rows.map(subs.paymentView) };
  });
  r.post('/api/me/payments', async (req) => {
    const u = requireUser(req);
    const b = req.body || {};
    if (Number(b.expectedChargesCents || 0) !== 0) throw conflict('Os encargos mudaram. Atualize a página.');
    const p = await subs.createPayment(u, { subscriptionId: Number(b.subscriptionId), amountCents: b.amountCents, idempotencyKey: b.idempotencyKey });
    return { payment: subs.paymentView(p) };
  });
  r.get('/api/me/payments/:id', async (req) => {
    const u = requireUser(req);
    let p = (await db().query('SELECT * FROM payments WHERE id=$1 AND user_id=$2', [Number(req.params.id) || 0, u.id]))[0];
    if (!p) throw notFound('Pagamento não encontrado.');
    // Enquanto pendente, consulta o provedor no máximo a cada 15 s (o crédito só muda com a confirmação do servidor).
    if (p.status === 'pending' && p.provider_payment_id && Date.now() - new Date(p.updated_at).getTime() > 15000) {
      try { await subs.syncPaymentFromProvider(p.provider_payment_id, { source: 'consulta' }); } catch {}
      p = (await db().query('SELECT * FROM payments WHERE id=$1', [p.id]))[0];
    }
    await subs.expireDue();
    p = (await db().query('SELECT * FROM payments WHERE id=$1', [p.id]))[0];
    const s = (await db().query('SELECT * FROM subscriptions WHERE id=$1', [p.subscription_id]))[0];
    return { payment: subs.paymentView(p), subscription: subs.subscriptionView(s) };
  });

  // ---------- Resgates (utilização do crédito) ----------
  r.get('/api/me/redemptions', async (req) => {
    const u = requireUser(req);
    await red.expireRedemptions();
    const rows = await db().query(`SELECT * FROM redemptions WHERE user_id=$1 AND status='pending' ORDER BY id DESC`, [u.id]);
    const w = await wallet.getWallet(db(), u.id);
    return { redemptions: rows.map((x) => red.redemptionView(x)), balanceCents: w.balance_cents };
  });
  r.post('/api/me/redemptions/:id/:action', async (req) => {
    const u = requireUser(req);
    const id = Number(req.params.id) || 0;
    if (req.params.action === 'authorize') {
      const x = await red.confirmRedemption({ id, actor: u, via: 'client_app', userId: u.id, cardId: req.body?.cardId ? Number(req.body.cardId) : null });
      return { redemption: red.redemptionView(x) };
    }
    if (req.params.action === 'decline') {
      await red.closeRedemption({ id, actor: u, status: 'declined', userId: u.id });
      return { ok: true };
    }
    throw notFound();
  });

  // ---------- Cartões do cliente ----------
  r.get('/api/me/cards', async (req) => {
    const u = requireUser(req);
    const rows = await db().query(
      `SELECT c.*, m.code AS model_code, m.name AS model_name FROM cards c JOIN card_models m ON m.id=c.model_id
       WHERE c.user_id=$1 AND c.status <> 'cancelled' ORDER BY c.id DESC`, [u.id]);
    const w = await wallet.getWallet(db(), u.id);
    return { cards: rows.map((c) => cardView(c, { balanceCents: w.balance_cents })), balanceCents: w.balance_cents };
  });
  r.get('/api/me/cards/:id', async (req) => {
    const u = requireUser(req);
    const c = (await db().query(
      `SELECT c.*, m.code AS model_code, m.name AS model_name FROM cards c JOIN card_models m ON m.id=c.model_id WHERE c.id=$1 AND c.user_id=$2`,
      [Number(req.params.id) || 0, u.id]))[0];
    if (!c) throw notFound('Cartão não encontrado.');
    const w = await wallet.getWallet(db(), u.id);
    const pend = await db().query(`SELECT * FROM redemptions WHERE user_id=$1 AND status='pending' ORDER BY id DESC`, [u.id]);
    const tx = await db().query(`SELECT * FROM redemptions WHERE card_id=$1 AND status='confirmed' ORDER BY id DESC LIMIT 50`, [c.id]);
    return { card: cardView(c, { balanceCents: w.balance_cents }), cardId: c.id, clientCode: u.code, pending: pend.map((x) => red.redemptionView(x)), redemptions: pend.map((x) => red.redemptionView(x)), transactions: tx.map((x) => red.redemptionView(x)), request: null };
  });
  r.post('/api/me/cards/:id/:action', async (req) => {
    const u = requireUser(req);
    const { action } = req.params;
    if (!['block', 'unblock'].includes(action)) throw notFound();
    const c = (await db().query('SELECT * FROM cards WHERE id=$1 AND user_id=$2', [Number(req.params.id) || 0, u.id]))[0];
    if (!c || c.status === 'cancelled') throw notFound('Cartão não encontrado.');
    if (action === 'unblock' && c.blocked_by === 'admin') throw conflict('Este cartão foi bloqueado pelo estúdio. Fale com o atendimento.');
    await db().query('UPDATE cards SET status=$1, blocked_by=$2 WHERE id=$3', [action === 'block' ? 'blocked' : 'active', action === 'block' ? 'client' : null, c.id]);
    await audit(db(), action === 'block' ? 'card_blocked' : 'card_unblocked', `Cartão ${c.last4} ${action === 'block' ? 'bloqueado' : 'desbloqueado'} pelo cliente`, { userId: u.id, actorId: u.id });
    return { ok: true };
  });

  // ---------- Perfil ----------
  r.patch('/api/me/profile', async (req) => {
    const u = requireUser(req);
    const b = req.body || {};
    const name = String(b.name ?? u.name).trim().replace(/\s+/g, ' ');
    if (name.length < 3) throw bad('Informe seu nome completo.');
    let email = String(b.email ?? '').trim().toLowerCase() || null;
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw bad('Informe um e-mail válido.');
    if (email) {
      const d = await db().query('SELECT id FROM users WHERE email=$1 AND id<>$2', [email, u.id]);
      if (d.length) throw conflict('Este e-mail já está em uso por outra conta.');
    }
    const a = b.address && typeof b.address === 'object' ? b.address : null;
    const address = a ? JSON.stringify(Object.fromEntries(['cep', 'state', 'street', 'number', 'complement', 'district', 'city'].map((k) => [k, String(a[k] || '').slice(0, 120)]))) : u.address;
    await db().query('UPDATE users SET name=$1, email=$2, address=$3, updated_at=$4 WHERE id=$5', [name.slice(0, 120), email, address, new Date().toISOString(), u.id]);
    const nu = (await db().query('SELECT * FROM users WHERE id=$1', [u.id]))[0];
    return { user: publicUser(nu) };
  });

  // ---------- Avatares ----------
  r.get('/api/avatars', async () => {
    const dir = path.join(config.publicDir, 'avatars');
    const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith('.webp')).sort() : [];
    return { avatars: files.map((f, i) => ({ id: f.replace(/\.webp$/, ''), label: `Avatar ${i + 1}`, url: `/avatars/${f}` })) };
  });
  r.put('/api/avatars/me/avatar', async (req) => {
    const u = requireUser(req);
    const id = String(req.body?.avatarId || '');
    if (!/^avatar_\d{2}$/.test(id) || !fs.existsSync(path.join(config.publicDir, 'avatars', `${id}.webp`))) throw bad('Avatar inválido.');
    await db().query('UPDATE users SET avatar_key=$1 WHERE id=$2', [id, u.id]);
    return { user: publicUser({ ...u, avatar_key: id }) };
  });
  r.post('/api/avatars/me/photo', async (req) => {
    const u = requireUser(req);
    const buf = req.rawBody;
    if (!buf || buf.length < 100) throw bad('Envie uma foto.');
    if (!(buf[0] === 0xff && buf[1] === 0xd8)) throw bad('Formato de imagem inválido (JPEG esperado).');
    if (buf.length > 3 * 1024 * 1024) throw bad('Foto muito grande.');
    const key = `photos/${u.id}-${crypto.randomBytes(6).toString('hex')}.jpg`;
    fs.mkdirSync(path.join(config.uploadsDir, 'photos'), { recursive: true });
    fs.writeFileSync(path.join(config.uploadsDir, key), buf);
    await db().query(`UPDATE users SET photo_key=$1, avatar_key='photo' WHERE id=$2`, [key, u.id]);
    return { user: publicUser({ ...u, photo_key: key, avatar_key: 'photo' }) };
  });
  r.put('/api/avatars/me/photo', async (req) => {
    const u = requireUser(req);
    if (!u.photo_key) throw bad('Você ainda não enviou uma foto.');
    await db().query(`UPDATE users SET avatar_key='photo' WHERE id=$1`, [u.id]);
    return { user: publicUser({ ...u, avatar_key: 'photo' }) };
  });
  r.delete('/api/avatars/me', async (req) => {
    const u = requireUser(req);
    await db().query('UPDATE users SET avatar_key=NULL WHERE id=$1', [u.id]);
    return { user: publicUser({ ...u, avatar_key: null }) };
  });
  r.get('/api/avatars/me', async (req) => ({ user: publicUser(requireUser(req)) }));

  // ---------- Notificações ----------
  const notifList = async (req, audience) => {
    const u = requireUser(req);
    const before = Number(req.query.get('before')) || null;
    const filter = req.query.get('filter');
    const params = [u.id, audience];
    let sql = 'SELECT * FROM notifications WHERE user_id=$1 AND audience=$2';
    if (filter === 'unread') sql += ' AND read_at IS NULL';
    if (before) { params.push(before); sql += ` AND id < $${params.length}`; }
    sql += ' ORDER BY id DESC LIMIT 30';
    const rows = await db().query(sql, params);
    return {
      items: rows.map((n) => ({ id: n.id, title: n.title, body: n.body, url: n.link, category: n.kind, read: !!n.read_at, createdAt: n.created_at })),
      next: rows.length === 30 ? rows[rows.length - 1].id : null,
    };
  };
  const notifCount = async (req, audience) => {
    const u = requireUser(req);
    const r1 = await db().query('SELECT COUNT(*) AS c FROM notifications WHERE user_id=$1 AND audience=$2 AND read_at IS NULL', [u.id, audience]);
    const r2 = await db().query('SELECT MAX(id) AS m FROM notifications WHERE user_id=$1 AND audience=$2', [u.id, audience]);
    return { unread: Number(r1[0].c), latestId: r2[0].m == null ? null : Number(r2[0].m), count: Number(r1[0].c) };
  };
  r.get('/api/notifications', (req) => notifList(req, 'client'));
  r.get('/api/notifications/count', (req) => notifCount(req, 'client'));
  r.post('/api/notifications/read-all', async (req) => {
    const u = requireUser(req);
    await db().query(`UPDATE notifications SET read_at=$1 WHERE user_id=$2 AND audience='client' AND read_at IS NULL`, [new Date().toISOString(), u.id]);
    return notifCount(req, 'client');
  });
  r.post('/api/notifications/:id/read', async (req) => {
    const u = requireUser(req);
    await db().query('UPDATE notifications SET read_at=$1 WHERE id=$2 AND user_id=$3 AND read_at IS NULL', [new Date().toISOString(), Number(req.params.id) || 0, u.id]);
    return notifCount(req, 'client');
  });
  r.delete('/api/notifications/:id', async (req) => {
    const u = requireUser(req);
    await db().query('DELETE FROM notifications WHERE id=$1 AND user_id=$2', [Number(req.params.id) || 0, u.id]);
    return notifCount(req, 'client');
  });
  r.get('/api/admin-notifications', (req) => notifList(req, 'admin'));
  r.get('/api/admin-notifications/count', (req) => notifCount(req, 'admin'));
  r.post('/api/admin-notifications/read-all', async (req) => {
    const u = requireUser(req);
    await db().query(`UPDATE notifications SET read_at=$1 WHERE user_id=$2 AND audience='admin' AND read_at IS NULL`, [new Date().toISOString(), u.id]);
    return notifCount(req, 'admin');
  });
  r.post('/api/admin-notifications/:id/read', async (req) => {
    const u = requireUser(req);
    await db().query('UPDATE notifications SET read_at=$1 WHERE id=$2 AND user_id=$3', [new Date().toISOString(), Number(req.params.id) || 0, u.id]);
    return notifCount(req, 'admin');
  });

  // ---------- IVT COIN (cliente) ----------
  r.get('/api/coins/me/wallet', async (req) => coins.walletPayload(requireUser(req).id));
  r.get('/api/coins/me/history', async (req) => {
    const u = requireUser(req);
    const type = req.query.get('type') || 'received';
    if (type === 'conversions') {
      const rows = await db().query(`SELECT * FROM coin_ledger WHERE user_id=$1 AND kind='redeem' ORDER BY id DESC LIMIT 100`, [u.id]);
      const entries = await db().query(`SELECT * FROM wallet_ledger WHERE user_id=$1 AND kind='coin_conversion'`, [u.id]);
      const byRef = Object.fromEntries(entries.map((e) => [String(e.ref_id), e]));
      return { conversions: rows.map((e) => ({ id: e.id, coins: -e.amount, cents: byRef[String(e.id)]?.amount_cents ?? 0, amountCents: byRef[String(e.id)]?.amount_cents ?? 0, status: 'completed', code: `CNV${e.id}`, createdAt: e.created_at, description: 'Conversão em crédito' })) };
    }
    if (type === 'benefit') return { entries: [] };
    const sql = type === 'redeemed'
      ? 'SELECT * FROM coin_ledger WHERE user_id=$1 AND amount < 0 ORDER BY id DESC LIMIT 200'
      : type === 'all' ? 'SELECT * FROM coin_ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 200'
        : 'SELECT * FROM coin_ledger WHERE user_id=$1 AND amount > 0 ORDER BY id DESC LIMIT 200';
    const rows = await db().query(sql, [u.id]);
    return { transactions: rows.map((e) => coins.txView(e)) };
  });
  r.get('/api/coins/me/index', async (req) => {
    requireUser(req);
    return { series: [], lastValuation: null, economy: { reference: { indexLinked: false }, formula: 'O índice interno de valorização do sistema original não foi recuperado nesta versão. O valor permanece fixo em 1,0000 e não altera a cotação.' } };
  });
  r.get('/api/coins/me/convert', async (req) => coins.convertQuote(requireUser(req).id));
  r.get('/api/coins/me/receipt', async (req) => ({ receipt: await coins.receipt(requireUser(req).id, req.query.get('code')) }));
  r.post('/api/coins/me/convert', async (req) => {
    const u = requireUser(req);
    const r2 = await coins.convert(u, { coins: req.body?.coins ?? req.body?.amount, idempotencyKey: req.body?.idempotencyKey });
    return { ok: true, ...r2, wallet: (await coins.walletPayload(u.id)).wallet };
  });
  // Benefício IVT COIN em planos: módulo não recuperado -> sem saldo de benefício disponível.
  r.get('/api/coins/me/benefit-quote', async (req) => { requireUser(req); return { quote: { availableCents: 0, maxCents: 0, giftCents: 0 } }; });
}
