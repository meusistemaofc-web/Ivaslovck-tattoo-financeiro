-- IVASLOVCK Tattoo Club — esquema inicial (dialeto PostgreSQL; traduzido automaticamente para SQLite nos testes).
-- Valores monetários SEMPRE em centavos inteiros (BIGINT). IVT COIN em unidades inteiras, em tabelas separadas.

CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  whatsapp TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'client' CHECK (role IN ('client','admin','owner')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','blocked')),
  avatar_key TEXT,
  address TEXT,
  photo_key TEXT,
  referral_code TEXT UNIQUE,
  referred_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE sessions (
  id BIGSERIAL PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  user_id BIGINT NOT NULL REFERENCES users(id),
  expires_at TIMESTAMPTZ NOT NULL,
  ip TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_by BIGINT REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE plans (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('tatuagem','piercing','outros')),
  description TEXT,
  image_key TEXT,
  image_url TEXT,
  total_cents BIGINT NOT NULL CHECK (total_cents > 0),
  min_payment_cents BIGINT NOT NULL CHECK (min_payment_cents > 0),
  daily_options TEXT NOT NULL DEFAULT '[]',
  allow_custom BOOLEAN NOT NULL DEFAULT TRUE,
  period TEXT NOT NULL CHECK (period IN ('daily','weekly','biweekly','monthly')),
  allow_advance BOOLEAN NOT NULL DEFAULT TRUE,
  allow_multiple BOOLEAN NOT NULL DEFAULT TRUE,
  allow_early_payoff BOOLEAN NOT NULL DEFAULT TRUE,
  featured BOOLEAN NOT NULL DEFAULT FALSE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  payoff_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  accepts_benefit BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Adesão a plano (contratação). Snapshot das condições no momento da contratação.
CREATE TABLE subscriptions (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  plan_id BIGINT NOT NULL REFERENCES plans(id),
  plan_name TEXT NOT NULL,
  plan_category TEXT NOT NULL,
  period TEXT NOT NULL,
  total_cents BIGINT NOT NULL CHECK (total_cents > 0),
  list_total_cents BIGINT NOT NULL,
  daily_cents BIGINT NOT NULL CHECK (daily_cents > 0),
  min_payment_cents BIGINT NOT NULL,
  allow_multiple BOOLEAN NOT NULL,
  allow_advance BOOLEAN NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('awaiting_first_payment','active','completed','cancelled','cancelled_unpaid')),
  paid_cents BIGINT NOT NULL DEFAULT 0,
  first_payment_cents BIGINT NOT NULL,
  first_payment_due_at TIMESTAMPTZ,
  activated_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  cancel_reason TEXT,
  terms_version TEXT NOT NULL,
  contract_hash TEXT NOT NULL,
  contract_text TEXT NOT NULL,
  accepted_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (paid_cents >= 0 AND paid_cents <= total_cents)
);
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id);
-- No máximo UMA contratação em aberto por cliente (regra do frontend original).
CREATE UNIQUE INDEX uq_subscriptions_open ON subscriptions(user_id) WHERE status IN ('awaiting_first_payment','active');

-- Cobranças Pix (Mercado Pago).
CREATE TABLE payments (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  subscription_id BIGINT NOT NULL REFERENCES subscriptions(id),
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  status TEXT NOT NULL CHECK (status IN ('pending','approved','rejected','cancelled','expired','refunded','reconciliation','reconciled')),
  provider TEXT NOT NULL DEFAULT 'mercadopago',
  provider_payment_id TEXT UNIQUE,
  idempotency_key TEXT NOT NULL,
  qr_code TEXT,
  qr_code_base64 TEXT,
  ticket_url TEXT,
  expires_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  provider_status TEXT,
  provider_status_detail TEXT,
  provider_amount_cents BIGINT,
  applied BOOLEAN NOT NULL DEFAULT FALSE,
  reconciliation_note TEXT,
  reconciled_at TIMESTAMPTZ,
  reconciled_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, idempotency_key)
);
CREATE INDEX idx_payments_sub ON payments(subscription_id);
CREATE INDEX idx_payments_status ON payments(status);

-- Notificações recebidas do Mercado Pago (deduplicação / rastreabilidade).
CREATE TABLE webhook_events (
  id BIGSERIAL PRIMARY KEY,
  provider TEXT NOT NULL,
  event_key TEXT NOT NULL UNIQUE,
  resource_id TEXT,
  payload TEXT,
  signature_valid BOOLEAN,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  processed_at TIMESTAMPTZ,
  result TEXT
);

-- Carteira em REAIS (crédito para uso no estúdio). O saldo é um cache do livro-razão, protegido por CHECK.
CREATE TABLE wallets (
  user_id BIGINT PRIMARY KEY REFERENCES users(id),
  balance_cents BIGINT NOT NULL DEFAULT 0 CHECK (balance_cents >= 0),
  plan_cents BIGINT NOT NULL DEFAULT 0 CHECK (plan_cents >= 0),
  gift_cents BIGINT NOT NULL DEFAULT 0 CHECK (gift_cents >= 0),
  conversion_cents BIGINT NOT NULL DEFAULT 0 CHECK (conversion_cents >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (balance_cents = plan_cents + gift_cents + conversion_cents)
);

-- Livro-razão imutável da carteira em reais.
CREATE TABLE wallet_ledger (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  amount_cents BIGINT NOT NULL CHECK (amount_cents <> 0),
  bucket TEXT NOT NULL CHECK (bucket IN ('plan','gift','conversion')),
  kind TEXT NOT NULL,
  ref_type TEXT,
  ref_id TEXT,
  idempotency_key TEXT NOT NULL UNIQUE,
  balance_after BIGINT NOT NULL CHECK (balance_after >= 0),
  description TEXT,
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_wallet_ledger_user ON wallet_ledger(user_id);

CREATE TABLE credit_releases (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  subscription_id BIGINT NOT NULL UNIQUE REFERENCES subscriptions(id),
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  ledger_id BIGINT NOT NULL REFERENCES wallet_ledger(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Cobranças de resgate (utilização do crédito no estúdio).
CREATE TABLE redemptions (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  description TEXT NOT NULL,
  attendance TEXT NOT NULL,
  code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','confirmed','cancelled','declined','expired')),
  expires_at TIMESTAMPTZ NOT NULL,
  created_by BIGINT NOT NULL REFERENCES users(id),
  created_by_name TEXT NOT NULL,
  confirmed_at TIMESTAMPTZ,
  confirmed_via TEXT,
  card_id BIGINT,
  ledger_id BIGINT REFERENCES wallet_ledger(id),
  closed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_redemptions_user ON redemptions(user_id);

-- IVT COIN: carteira e livro-razão TOTALMENTE separados dos reais.
CREATE TABLE coin_wallets (
  user_id BIGINT PRIMARY KEY REFERENCES users(id),
  balance BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
  total_earned BIGINT NOT NULL DEFAULT 0 CHECK (total_earned >= 0),
  total_spent BIGINT NOT NULL DEFAULT 0 CHECK (total_spent >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE coin_ledger (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  amount BIGINT NOT NULL CHECK (amount <> 0),
  kind TEXT NOT NULL,
  reason TEXT,
  ref_type TEXT,
  ref_id TEXT,
  idempotency_key TEXT NOT NULL UNIQUE,
  balance_after BIGINT NOT NULL CHECK (balance_after >= 0),
  expires_at TIMESTAMPTZ,
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_coin_ledger_user ON coin_ledger(user_id);

-- Cartões digitais internos (não bancários). Usam o saldo da carteira em reais.
CREATE TABLE card_models (
  id BIGSERIAL PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  eligibility TEXT NOT NULL DEFAULT 'all' CHECK (eligibility IN ('all','completed_plan','min_credit')),
  min_credit_cents BIGINT NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE cards (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  model_id BIGINT NOT NULL REFERENCES card_models(id),
  identifier TEXT NOT NULL UNIQUE,
  last4 TEXT NOT NULL,
  holder_name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('active','blocked','cancelled')),
  expires_on TEXT,
  issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  issued_by BIGINT REFERENCES users(id),
  issued_by_name TEXT,
  blocked_by TEXT,
  cancelled_at TIMESTAMPTZ,
  cancel_reason TEXT
);
CREATE INDEX idx_cards_user ON cards(user_id);

-- Auditoria administrativa / histórico de operações (imutável).
CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  type TEXT NOT NULL,
  message TEXT NOT NULL,
  user_id BIGINT REFERENCES users(id),
  actor_id BIGINT REFERENCES users(id),
  amount_cents BIGINT,
  meta TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_user ON audit_log(user_id);

CREATE TABLE notifications (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  audience TEXT NOT NULL DEFAULT 'client',
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  kind TEXT,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notifications_user ON notifications(user_id);

-- Imutabilidade dos registros financeiros: UPDATE e DELETE são bloqueados pelo próprio banco.
-- @postgres
CREATE OR REPLACE FUNCTION forbid_change() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'Registro financeiro imutável: % não permitido em %', TG_OP, TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER wallet_ledger_immutable BEFORE UPDATE OR DELETE ON wallet_ledger FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER coin_ledger_immutable BEFORE UPDATE OR DELETE ON coin_ledger FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER audit_log_immutable BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER credit_releases_immutable BEFORE UPDATE OR DELETE ON credit_releases FOR EACH ROW EXECUTE FUNCTION forbid_change();
-- @end
-- @sqlite
CREATE TRIGGER wallet_ledger_no_update BEFORE UPDATE ON wallet_ledger BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
CREATE TRIGGER wallet_ledger_no_delete BEFORE DELETE ON wallet_ledger BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
CREATE TRIGGER coin_ledger_no_update BEFORE UPDATE ON coin_ledger BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
CREATE TRIGGER coin_ledger_no_delete BEFORE DELETE ON coin_ledger BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
CREATE TRIGGER audit_log_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
CREATE TRIGGER audit_log_no_delete BEFORE DELETE ON audit_log BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
CREATE TRIGGER credit_releases_no_update BEFORE UPDATE ON credit_releases BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
CREATE TRIGGER credit_releases_no_delete BEFORE DELETE ON credit_releases BEGIN SELECT RAISE(ABORT, 'Registro financeiro imutável'); END;
-- @end

INSERT INTO card_models (code, name, description, eligibility, min_credit_cents, active, sort_order) VALUES
  ('black', 'IVASLOVCK BLACK', NULL, 'all', 0, TRUE, 1),
  ('gold', 'IVASLOVCK GOLD', NULL, 'all', 0, TRUE, 2),
  ('silver', 'IVASLOVCK SILVER', NULL, 'all', 0, TRUE, 3);
