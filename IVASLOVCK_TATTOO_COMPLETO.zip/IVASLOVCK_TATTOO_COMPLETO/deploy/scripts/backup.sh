#!/usr/bin/env bash
# Backup do banco PostgreSQL + fotos enviadas. Mantém os últimos 14 dias em ./backups
set -euo pipefail
cd "$(dirname "$0")/../.."
set -a; . ./.env; set +a
mkdir -p backups
STAMP=$(date +%Y%m%d-%H%M%S)
docker compose exec -T db pg_dump -U "${POSTGRES_USER:-ivaslovck}" -d "${POSTGRES_DB:-ivaslovck}" --format=custom > "backups/banco-$STAMP.dump"
docker compose exec -T app tar -czf - -C /app/data uploads > "backups/uploads-$STAMP.tar.gz" 2>/dev/null || true
find backups -name 'banco-*.dump' -mtime +14 -delete
find backups -name 'uploads-*.tar.gz' -mtime +14 -delete
echo "Backup criado: backups/banco-$STAMP.dump"
