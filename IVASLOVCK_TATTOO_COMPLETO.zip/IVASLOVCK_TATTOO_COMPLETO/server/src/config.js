import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const env = process.env;
const bool = (v, d = false) => (v == null || v === '' ? d : /^(1|true|yes|sim)$/i.test(v));

export const config = {
  env: env.NODE_ENV || 'development',
  isProd: env.NODE_ENV === 'production',
  port: Number(env.PORT || 3000),
  host: env.HOST || '0.0.0.0',
  appUrl: (env.APP_URL || 'http://localhost:3000').replace(/\/$/, ''),
  // Postgres em produção. Sem DATABASE_URL o servidor usa SQLite (somente desenvolvimento/testes).
  databaseUrl: env.DATABASE_URL || '',
  sqlitePath: env.SQLITE_PATH || path.join(__dirname, '..', 'data', 'dev.sqlite'),
  appSecret: env.APP_SECRET || '',
  adminSetupToken: env.ADMIN_SETUP_TOKEN || '',
  cookieSecure: bool(env.COOKIE_SECURE, env.NODE_ENV === 'production'),
  sessionDays: Number(env.SESSION_DAYS || 30),
  publicDir: env.PUBLIC_DIR || path.join(__dirname, '..', '..', 'public'),
  uploadsDir: env.UPLOADS_DIR || path.join(__dirname, '..', 'data', 'uploads'),
  // Mercado Pago. As variáveis de ambiente têm prioridade sobre o token salvo pelo painel.
  mpAccessToken: env.MP_ACCESS_TOKEN || '',
  mpWebhookSecret: env.MP_WEBHOOK_SECRET || '',
  mpApiBase: (env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, ''),
  jobsIntervalMs: Number(env.JOBS_INTERVAL_MS || 60000),
  trustProxy: bool(env.TRUST_PROXY, true),
};

export function assertProdConfig() {
  const problems = [];
  if (!config.appSecret || config.appSecret.length < 32) problems.push('APP_SECRET ausente ou curto (mínimo 32 caracteres)');
  if (config.isProd && !config.databaseUrl) problems.push('DATABASE_URL obrigatório em produção (PostgreSQL)');
  if (problems.length) {
    const msg = 'Configuração inválida:\n - ' + problems.join('\n - ');
    if (config.isProd) throw new Error(msg);
    console.warn('[config] ' + msg);
  }
}
