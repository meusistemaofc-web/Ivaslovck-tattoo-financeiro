# IVASLOVCK Tattoo Club — versão independente da Netlify

Plataforma de crédito programado para tatuagem e piercing:
- planos pagos via Pix (Mercado Pago), com crédito liberado na quitação;
- carteira digital e uso do crédito no estúdio;
- IVT COIN;
- cartões BLACK, GOLD e SILVER;
- painel administrativo.

## Estrutura
```
public/        Frontend ORIGINAL (compilado), identidade visual preservada
server/        Backend novo (Node.js 22 + PostgreSQL) — substitui as Netlify Functions
  src/         Código (rotas, serviços financeiros, migrações)
  tests/       Testes automáticos, teste no navegador e varredura de telas
  scripts/     integrity (conferência de saldos), set-contract (cláusulas)
deploy/        Nginx e scripts: instalar, atualizar, backup, restaurar
docs/          Relatórios e guia de instalação
legacy/        netlify.toml original (referência)
Dockerfile, docker-compose.yml, .env.example
```

## Começar
- **Produção (VPS Hostinger):** siga `docs/GUIA_INSTALACAO_VPS.md` e rode `sudo bash deploy/scripts/instalar.sh`.
- **Desenvolvimento local:** precisa de Node 22.5+. Sem `DATABASE_URL`, o servidor usa SQLite apenas para desenvolvimento.
  ```bash
  cd server && npm install
  APP_SECRET=$(openssl rand -hex 32) ADMIN_SETUP_TOKEN=dev npm run dev
  ```
  Depois abra http://localhost:3000.
- **Testes:** `cd server && npm test`

## Documentos
- `docs/RELATORIO_RECONSTRUCAO.md` — o que existia, o que foi reconstruído e o que ficou pendente
- `docs/RELATORIO_FINANCEIRO_E_INTEGRIDADE.md` — carteira, IVT COIN, pagamentos e segurança
- `docs/RELATORIO_TESTES.md` — testes executados e resultados
- `docs/GUIA_INSTALACAO_VPS.md` — instalação passo a passo
- `docs/CHECKLIST_GITHUB_VPS.md` — checklist de publicação
