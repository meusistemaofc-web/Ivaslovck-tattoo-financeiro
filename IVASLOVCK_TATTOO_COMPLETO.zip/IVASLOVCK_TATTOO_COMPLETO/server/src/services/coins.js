// IVT COIN — moeda interna. Livro-razão próprio (coin_ledger), carteira própria (coin_wallets).
// Nunca é misturada ao saldo em reais. A ÚNICA ponte é a conversão explícita, que só existe se o
// estúdio configurar taxa e habilitar; ela registra débito em moedas e crédito no balde "conversion"
// da carteira em reais, na MESMA transação e com referências cruzadas.
import { db } from '../db.js';
import { bad, conflict, HttpError } from '../http.js';
import { getSetting, audit } from './settings.js';
import * as wallet from './wallet.js';

const now = () => new Date().toISOString();
export const KIND_LABEL = {
  distribute: 'Distribuição', debit: 'Ajuste (débito)', redeem: 'Conversão em crédito', refund: 'Estorno',
};

export async function lockCoinWallet(t, userId) {
  await t.query('INSERT INTO coin_wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING', [userId]);
  return (await t.query('SELECT * FROM coin_wallets WHERE user_id=$1 FOR UPDATE', [userId]))[0];
}
export async function getCoinWallet(q, userId) {
  const r = await q.query('SELECT * FROM coin_wallets WHERE user_id=$1', [userId]);
  return r[0] || { user_id: userId, balance: 0, total_earned: 0, total_spent: 0 };
}

async function move(t, { userId, amount, kind, reason, refType, refId, key, actorId }) {
  if (!key) throw new Error('idempotency key obrigatória');
  const dup = await t.query('SELECT * FROM coin_ledger WHERE idempotency_key=$1', [key]);
  if (dup.length) return { entry: dup[0], duplicate: true };
  const w = await lockCoinWallet(t, userId);
  const balance = w.balance + amount;
  if (balance < 0) throw conflict('Saldo de IVT COIN insuficiente.');
  const earned = w.total_earned + (amount > 0 && kind !== 'refund' ? amount : 0);
  const spent = w.total_spent + (amount < 0 ? -amount : 0) - (kind === 'refund' ? amount : 0);
  const rows = await t.query(
    `INSERT INTO coin_ledger (user_id, amount, kind, reason, ref_type, ref_id, idempotency_key, balance_after, created_by, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [userId, amount, kind, reason || null, refType || null, refId == null ? null : String(refId), key, balance, actorId || null, now()],
  );
  await t.query('UPDATE coin_wallets SET balance=$1, total_earned=$2, total_spent=$3, updated_at=$4 WHERE user_id=$5',
    [balance, earned, Math.max(0, spent), now(), userId]);
  return { entry: rows[0], duplicate: false };
}

function validAmount(a) {
  a = Number(a);
  if (!Number.isInteger(a) || a <= 0 || a > 1e9) throw bad('Informe uma quantidade inteira de moedas.');
  return a;
}

export async function grant(admin, { userId, amount, note, idempotencyKey }) {
  amount = validAmount(amount);
  if (!idempotencyKey) throw bad('Requisição inválida (chave de idempotência).');
  return db().tx(async (t) => {
    const u = (await t.query(`SELECT id, name FROM users WHERE id=$1 AND role='client'`, [userId]))[0];
    if (!u) throw new HttpError(404, 'Cliente não encontrado.');
    const r = await move(t, { userId, amount, kind: 'distribute', reason: note || 'Lançamento manual', refType: 'admin', refId: admin.id, key: `coin:grant:${admin.id}:${idempotencyKey}`, actorId: admin.id });
    if (!r.duplicate) await audit(t, 'coins_granted', `${amount} IVT COINS creditadas a ${u.name}${note ? ` (${note})` : ''}`, { userId, actorId: admin.id, meta: { coins: amount } });
    return r;
  });
}

export async function adminDebit(admin, { userId, amount, note, destination, idempotencyKey }) {
  amount = validAmount(amount);
  if (!idempotencyKey) throw bad('Requisição inválida (chave de idempotência).');
  if (!note || !String(note).trim()) throw bad('Informe o motivo do débito.');
  const dest = destination === 'burn' ? 'burn' : 'return';
  return db().tx(async (t) => {
    const r = await move(t, { userId, amount: -amount, kind: 'debit', reason: note, refType: `debit:${dest}`, refId: admin.id, key: `coin:debit:${admin.id}:${idempotencyKey}`, actorId: admin.id });
    if (!r.duplicate) await audit(t, 'coins_debited', `${amount} IVT COINS debitadas (${note})`, { userId, actorId: admin.id, meta: { coins: amount, destination: dest } });
    return r;
  });
}

export const CONVERSION_DEFAULTS = {
  enabled: false, rateCoins: 0, rateCents: 0, minCoins: 0, stepCoins: 0, maxCoinsPerOp: 0,
  dailyLimitCoins: 0, weeklyLimitCoins: 0, monthlyLimitCoins: 0,
  // Campos do painel original que dependem de módulos não reconstruídos: mantidos desligados.
  indexLinked: false, validityDays: 0, allowMultiple: true, useEnabled: false, maxPercentBp: 0, globalCapCents: 0,
};
export async function coinConfig() {
  const c = { ...CONVERSION_DEFAULTS, ...((await getSetting('coinConversion')) || {}) };
  c.configured = c.rateCoins > 0 && c.rateCents > 0;
  c.conversionEnabled = !!c.enabled;
  c.minConversion = c.minCoins || 0;
  return c;
}
export function sanitizeConversionConfig(b) {
  const n = (v) => Math.max(0, Math.floor(Number(v) || 0));
  return {
    ...CONVERSION_DEFAULTS,
    enabled: !!b.enabled, rateCoins: n(b.rateCoins), rateCents: n(b.rateCents), minCoins: n(b.minCoins), stepCoins: n(b.stepCoins),
    maxCoinsPerOp: n(b.maxCoinsPerOp), dailyLimitCoins: n(b.dailyLimitCoins), weeklyLimitCoins: n(b.weeklyLimitCoins), monthlyLimitCoins: n(b.monthlyLimitCoins),
  };
}

export const coinsToCents = (cfg, coins) => (cfg.configured ? Math.floor((coins * cfg.rateCents) / cfg.rateCoins) : 0);

export async function convert(user, { coins, idempotencyKey }) {
  coins = validAmount(coins);
  if (!idempotencyKey) throw bad('Requisição inválida (chave de idempotência).');
  const cfg = await coinConfig();
  if (!cfg.configured || !cfg.conversionEnabled) throw conflict('A conversão de IVT COINS não está habilitada pelo estúdio.');
  if (coins < cfg.minConversion) throw bad(`A conversão mínima é de ${cfg.minConversion} IVT COINS.`);
  if (cfg.stepCoins > 0 && coins % cfg.stepCoins !== 0) throw bad(`Converta em múltiplos de ${cfg.stepCoins} IVT COINS.`);
  if (cfg.maxCoinsPerOp > 0 && coins > cfg.maxCoinsPerOp) throw bad(`O máximo por conversão é de ${cfg.maxCoinsPerOp} IVT COINS.`);
  const cents = coinsToCents(cfg, coins);
  if (cents <= 0) throw bad('Quantidade insuficiente para gerar crédito.');
  return db().tx(async (t) => {
    const key = `coin:convert:${user.id}:${idempotencyKey}`;
    for (const [days, lim, label] of [[1, cfg.dailyLimitCoins, 'diário'], [7, cfg.weeklyLimitCoins, 'semanal'], [30, cfg.monthlyLimitCoins, 'mensal']]) {
      if (!lim) continue;
      const since = new Date(Date.now() - days * 86400000).toISOString();
      const used = Number((await t.query(`SELECT COALESCE(SUM(-amount),0) AS c FROM coin_ledger WHERE user_id=$1 AND kind='redeem' AND created_at >= $2`, [user.id, since]))[0].c);
      if (used + coins > lim) throw conflict(`Limite ${label} de conversão atingido (${lim} IVT COINS).`);
    }
    const r = await move(t, { userId: user.id, amount: -coins, kind: 'redeem', reason: 'Conversão em crédito', refType: 'conversion', refId: null, key, actorId: user.id });
    if (r.duplicate) return { duplicate: true, cents, coins, receipt: { code: `CNV${r.entry.id}` } };
    await wallet.credit(t, {
      userId: user.id, amountCents: cents, bucket: 'conversion', kind: 'coin_conversion', refType: 'coin_ledger', refId: r.entry.id,
      key: `wallet:${key}`, description: `Conversão de ${coins} IVT COINS`, actorId: user.id,
    });
    await audit(t, 'coins_converted', `${coins} IVT COINS convertidas em R$ ${(cents / 100).toFixed(2)}`, { userId: user.id, actorId: user.id, amountCents: cents, meta: { coins, rateCoins: cfg.rateCoins, rateCents: cfg.rateCents } });
    return { duplicate: false, cents, coins, entryId: r.entry.id, receipt: { code: `CNV${r.entry.id}` } };
  });
}

export function txView(e, extra = {}) {
  return {
    id: e.id, userId: e.user_id, amount: Math.abs(e.amount), walletDelta: e.amount, kind: e.kind,
    kindLabel: KIND_LABEL[e.kind] || e.kind, description: e.reason || KIND_LABEL[e.kind] || e.kind,
    balanceAfter: e.balance_after, createdAt: e.created_at,
    destination: e.ref_type?.startsWith('debit:') ? e.ref_type.slice(6) : null, availableDelta: null, ...extra,
  };
}

export async function walletPayload(userId) {
  const w = await getCoinWallet(db(), userId);
  const cfg = await coinConfig();
  const recent = await db().query('SELECT * FROM coin_ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 10', [userId]);
  let reason = null;
  if (!cfg.configured) reason = 'A cotação da IVT COIN ainda não foi definida pelo estúdio.';
  else if (!cfg.conversionEnabled) reason = 'A conversão em crédito está desativada no momento.';
  else if (w.balance < cfg.minConversion) reason = `A conversão mínima é de ${cfg.minConversion} IVT COINS.`;
  const rw = (await db().query('SELECT conversion_cents FROM wallets WHERE user_id=$1', [userId]))[0];
  return {
    wallet: { balance: w.balance, totalEarned: w.total_earned, totalSpent: w.total_spent },
    // O "índice interno de valorização" do sistema original não foi recuperado: valor neutro e fixo (1,0000; 0%).
    index: { value: 10000, changePct: 0, reconstructed: false },
    benefit: { availableCents: rw?.conversion_cents || 0, nextExpiry: null },
    coupons: [], rewards: [], series: [], ownBalanceCents: rw?.conversion_cents || 0,
    quote: { rateCoins: cfg.rateCoins || 1, rateCents: cfg.rateCents || 0, indexLinked: false, indexValue: 10000 },
    conversion: { enabled: cfg.configured && cfg.conversionEnabled, equivalentCents: coinsToCents(cfg, w.balance), minCoins: cfg.minConversion, reason },
    recent: recent.map((e) => txView(e)),
  };
}

export async function supply(q = db()) {
  const r = (await q.query(`SELECT
      COALESCE(SUM(CASE WHEN kind='distribute' THEN amount ELSE 0 END),0) AS distributed,
      COALESCE(SUM(CASE WHEN kind='redeem' THEN -amount ELSE 0 END),0) AS redeemed,
      COALESCE(SUM(CASE WHEN kind='refund' THEN amount ELSE 0 END),0) AS refunded,
      COALESCE(SUM(CASE WHEN kind='debit' AND ref_type='debit:burn' THEN -amount ELSE 0 END),0) AS burned,
      COALESCE(SUM(CASE WHEN kind='debit' AND ref_type='debit:return' THEN -amount ELSE 0 END),0) AS returned
    FROM coin_ledger`))[0];
  const w = (await q.query('SELECT COALESCE(SUM(balance),0) AS c, COUNT(CASE WHEN balance > 0 THEN 1 END) AS h FROM coin_wallets'))[0];
  const circulation = Number(w.c);
  const expected = Number(r.distributed) + Number(r.refunded) - Number(r.redeemed) - Number(r.burned) - Number(r.returned);
  return {
    totalIssued: Number(r.distributed), distributed: Number(r.distributed), redeemed: Number(r.redeemed),
    burned: Number(r.burned), retired: Number(r.burned), returned: Number(r.returned), circulation,
    holders: Number(w.h), available: null, consistent: circulation === expected,
  };
}

export async function convertQuote(userId) {
  const cfg = await coinConfig();
  const w = await getCoinWallet(db(), userId);
  let maxNow = w.balance;
  if (cfg.maxCoinsPerOp) maxNow = Math.min(maxNow, cfg.maxCoinsPerOp);
  if (cfg.stepCoins) maxNow -= maxNow % cfg.stepCoins;
  let reason = null;
  if (!cfg.configured) reason = 'A cotação da IVT COIN ainda não foi definida pelo estúdio.';
  else if (!cfg.conversionEnabled) reason = 'A conversão em crédito está desativada no momento.';
  else if (w.balance < (cfg.minCoins || 1)) reason = `Você precisa de pelo menos ${cfg.minCoins || 1} IVT COINS para converter.`;
  const step = cfg.stepCoins || cfg.minCoins || 100;
  const options = [];
  for (const mult of [1, 2, 5, 10]) { const c = step * mult; if (c <= maxNow) options.push({ coins: c, cents: coinsToCents(cfg, c) }); }
  if (maxNow > 0 && !options.some((o) => o.coins === maxNow)) options.push({ coins: maxNow, cents: coinsToCents(cfg, maxNow) });
  const { configured, conversionEnabled, minConversion, ...config } = cfg;
  const usage = {};
  for (const [k, days] of [['day', 1], ['week', 7], ['month', 30]]) {
    const since = new Date(Date.now() - days * 86400000).toISOString();
    usage[k] = Number((await db().query(`SELECT COALESCE(SUM(-amount),0) AS c FROM coin_ledger WHERE user_id=$1 AND kind='redeem' AND created_at >= $2`, [userId, since]))[0].c);
  }
  const rw = (await db().query('SELECT conversion_cents FROM wallets WHERE user_id=$1', [userId]))[0];
  return { usage, benefit: { availableCents: rw?.conversion_cents || 0, nextExpiry: null }, equivalentCents: coinsToCents(cfg, w.balance), config: { ...config, rateCoins: cfg.rateCoins || 1, stepCoins: cfg.stepCoins || 1 }, options, reason, maxCoinsNow: Math.max(0, maxNow), indexValue: 10000, balance: w.balance, wallet: { balance: w.balance, totalEarned: w.total_earned, totalSpent: w.total_spent } };
}

export async function receipt(userId, code) {
  const id = Number(String(code || '').replace(/^CNV/, '')) || 0;
  const e = (await db().query(`SELECT * FROM coin_ledger WHERE id=$1 AND user_id=$2 AND kind='redeem'`, [id, userId]))[0];
  if (!e) throw new HttpError(404, 'Comprovante não encontrado.');
  const wl = (await db().query(`SELECT * FROM wallet_ledger WHERE kind='coin_conversion' AND ref_id=$1`, [String(e.id)]))[0];
  const meta = (await db().query(`SELECT meta FROM audit_log WHERE type='coins_converted' AND user_id=$1 AND created_at >= $2 ORDER BY id LIMIT 1`, [userId, e.created_at]))[0];
  let m = {}; try { m = JSON.parse(meta?.meta || '{}'); } catch {}
  return { code: `CNV${e.id}`, coins: -e.amount, cents: wl?.amount_cents || 0, rateCoins: m.rateCoins || null, rateCents: m.rateCents || null, createdAt: e.created_at, expiresAt: null, status: 'completed', reversalReason: null };
}
