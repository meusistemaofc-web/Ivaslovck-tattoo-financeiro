// Cobranças Pix genéricas. O valor é fixado no servidor, o pagamento só é aplicado depois que o servidor
// consulta o Mercado Pago (webhook, consulta ou expiração) e confere status, valor e referência.
import { db } from '../db.js';
import { bad, conflict, notFound } from '../http.js';
import { getSetting, audit } from './settings.js';
import * as mp from './mercadopago.js';
import * as gifts from './gifts.js';

const now = () => new Date().toISOString();
const MP_FINAL = { approved: 'approved', rejected: 'failed', cancelled: 'cancelled', refunded: 'failed', charged_back: 'failed' };

export function chargeView(c) {
  return {
    id: Number(c.id), kind: c.kind, status: c.status, amountCents: Number(c.amount_cents), qrCode: c.qr_code, qrCodeBase64: c.qr_code_base64,
    ticketUrl: c.ticket_url, expiresAt: c.expires_at, paidAt: c.paid_at, createdAt: c.created_at,
    giftCardId: c.gift_card_id == null ? null : Number(c.gift_card_id), installmentId: c.installment_id == null ? null : Number(c.installment_id),
    upgradeRequestId: c.upgrade_request_id == null ? null : Number(c.upgrade_request_id), cardRequestId: c.card_request_id == null ? null : Number(c.card_request_id),
  };
}

// Cria (ou reaproveita) a cobrança Pix de um cartão presente ainda não pago.
export async function createGiftCharge(user, giftCardId, idempotencyKey) {
  if (!idempotencyKey || String(idempotencyKey).length > 100) throw bad('Requisição inválida (chave de idempotência).');
  const reservation = await db().tx(async (t) => {
    const dup = await t.query('SELECT * FROM charges WHERE user_id=$1 AND idempotency_key=$2', [user.id, idempotencyKey]);
    if (dup.length) return { charge: dup[0], duplicate: true };
    const card = (await t.query('SELECT * FROM gift_cards WHERE id=$1 AND buyer_id=$2 FOR UPDATE', [giftCardId, user.id]))[0];
    if (!card) throw notFound('Cartão presente não encontrado.');
    if (card.status !== 'awaiting_payment') throw conflict('Este cartão presente não está aguardando pagamento.');
    const open = (await t.query(`SELECT * FROM charges WHERE gift_card_id=$1 AND status='pending' AND expires_at > $2 ORDER BY id DESC LIMIT 1`, [card.id, now()]))[0];
    if (open) return { charge: open, duplicate: true };
    const minutes = Number(await getSetting('pixExpirationMinutes')) || 30;
    const ins = await t.query(
      `INSERT INTO charges (user_id, kind, status, amount_cents, gift_card_id, idempotency_key, expires_at, created_at, updated_at)
       VALUES ($1,'gift_card','pending',$2,$3,$4,$5,$6,$6) RETURNING *`,
      [user.id, card.amount_cents, card.id, idempotencyKey, new Date(Date.now() + minutes * 60000).toISOString(), now()],
    );
    return { charge: ins[0], duplicate: false };
  });
  const c = reservation.charge;
  if (c.provider_payment_id || c.status !== 'pending') return c;
  let mpPay;
  try {
    mpPay = await mp.createPixPayment({
      amountCents: Number(c.amount_cents), description: 'IVASLOVCK Tattoo Club · Cartão Presente', payerEmail: user.email || `cliente${user.id}@ivaslovck.invalid`,
      payerName: user.name, externalReference: `ivs-charge-${c.id}`, expiresAt: c.expires_at, idempotencyKey: `ivs-charge-${c.id}`,
    });
  } catch (e) {
    await db().query(`UPDATE charges SET status='failed', note=$1, updated_at=$2 WHERE id=$3 AND status='pending' AND provider_payment_id IS NULL`, ['create_failed', now(), c.id]);
    throw e;
  }
  const pix = mp.pixData(mpPay);
  await db().query('UPDATE charges SET provider_payment_id=$1, qr_code=$2, qr_code_base64=$3, ticket_url=$4, provider_status=$5, updated_at=$6 WHERE id=$7',
    [String(mpPay.id), pix.qrCode, pix.qrCodeBase64, pix.ticketUrl, mpPay.status, now(), c.id]);
  await audit(db(), 'charge_created', `Pix gerado para Cartão Presente (cobrança #${c.id})`, { userId: user.id, actorId: user.id, amountCents: Number(c.amount_cents), meta: { chargeId: c.id } });
  return (await db().query('SELECT * FROM charges WHERE id=$1', [c.id]))[0];
}

export async function getOwnCharge(user, id) {
  let c = (await db().query('SELECT * FROM charges WHERE id=$1 AND user_id=$2', [Number(id) || 0, user.id]))[0];
  if (!c) throw notFound('Cobrança não encontrada.');
  if (c.status === 'pending' && c.provider_payment_id && Date.now() - new Date(c.updated_at).getTime() > 15000) {
    try { await syncChargeFromProvider(c.provider_payment_id, { source: 'consulta' }); } catch { /* provedor indisponível: tenta de novo na próxima consulta */ }
    c = (await db().query('SELECT * FROM charges WHERE id=$1', [c.id]))[0];
  }
  if (c.status === 'pending' && c.expires_at < now()) {
    await expirePending();
    c = (await db().query('SELECT * FROM charges WHERE id=$1', [c.id]))[0];
  }
  return c;
}

export async function syncChargeFromProvider(providerId, { source = 'webhook' } = {}) {
  const mpPay = await mp.getPayment(providerId);
  const m = /^ivs-charge-(\d+)$/.exec(String(mpPay.external_reference || ''));
  if (!m) return { ignored: true, reason: 'external_reference desconhecida' };
  return applyChargeState(Number(m[1]), mpPay, { source });
}

export async function applyChargeState(chargeId, mpPay, { source } = {}) {
  return db().tx(async (t) => {
    const c = (await t.query('SELECT * FROM charges WHERE id=$1 FOR UPDATE', [chargeId]))[0];
    if (!c) return { ignored: true, reason: 'cobrança inexistente' };
    if (c.provider_payment_id && String(c.provider_payment_id) !== String(mpPay.id)) {
      await audit(t, 'charge_mismatch', `ID do provedor divergente na cobrança #${c.id}`, { userId: c.user_id, meta: { expected: c.provider_payment_id, got: String(mpPay.id) } });
      return { ignored: true, reason: 'id divergente' };
    }
    const cents = Math.round(Number(mpPay.transaction_amount) * 100);
    await t.query('UPDATE charges SET provider_status=$1, provider_amount_cents=$2, updated_at=$3 WHERE id=$4', [mpPay.status, cents, now(), c.id]);
    const target = MP_FINAL[mpPay.status];
    if (!target) return { status: c.status, unchanged: true };
    if (target !== 'approved') {
      if (c.status === 'pending') await t.query('UPDATE charges SET status=$1, updated_at=$2 WHERE id=$3', [target, now(), c.id]);
      return { status: target };
    }
    if (c.status === 'approved') return { status: 'approved', duplicate: true };
    if (cents !== Number(c.amount_cents)) {
      await t.query(`UPDATE charges SET status='failed', note=$1, updated_at=$2 WHERE id=$3`, [`valor pago (${cents}) difere do cobrado`, now(), c.id]);
      await audit(t, 'charge_mismatch', `Valor pago (${cents}) difere do cobrado (${c.amount_cents}) na cobrança #${c.id}. Requer análise.`, { userId: c.user_id, amountCents: cents });
      return { status: 'failed' };
    }
    await t.query(`UPDATE charges SET status='approved', paid_at=$1, updated_at=$1 WHERE id=$2`, [mpPay.date_approved || now(), c.id]);
    if (c.kind === 'gift_card') await gifts.markPaid(t, c.gift_card_id, c);
    await audit(t, 'charge_approved', `Cobrança #${c.id} paga (${c.kind}) via ${source || 'sistema'}`, { userId: c.user_id, amountCents: Number(c.amount_cents), meta: { chargeId: c.id } });
    return { status: 'approved' };
  });
}

export async function expirePending() {
  const stale = await db().query(`SELECT * FROM charges WHERE status='pending' AND expires_at < $1`, [new Date(Date.now() - 5 * 60000).toISOString()]);
  for (const c of stale) {
    if (c.provider_payment_id) {
      try { const r = await syncChargeFromProvider(c.provider_payment_id, { source: 'expiração' }); if (r.status && r.status !== 'pending' && !r.unchanged) continue; } catch { continue; }
    }
    await db().query(`UPDATE charges SET status='expired', updated_at=$1 WHERE id=$2 AND status='pending'`, [now(), c.id]);
  }
}
