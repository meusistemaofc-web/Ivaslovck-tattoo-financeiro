// Núcleo financeiro: contratação de planos, cobranças Pix e liberação de crédito.
// Crédito NUNCA é concedido por informação do frontend: somente após o servidor consultar o
// Mercado Pago (webhook ou sincronização) e confirmar status "approved" com valor e referência corretos.
import crypto from 'node:crypto';
import { db } from '../db.js';
import { HttpError, bad, conflict, notFound } from '../http.js';
import { getSetting, audit, notify } from './settings.js';
import * as wallet from './wallet.js';
import * as mp from './mercadopago.js';

export const PERIODS = {
  daily: { days: 1, per: 'por dia', label: 'Diário' },
  weekly: { days: 7, per: 'por semana', label: 'Semanal' },
  biweekly: { days: 15, per: 'por quinzena', label: 'Quinzenal' },
  monthly: { days: 30, per: 'por mês', label: 'Mensal' },
};
const OPEN = ['awaiting_first_payment', 'active'];
const now = () => new Date().toISOString();
const bool = (v) => v === true || v === 1 || v === '1';

export function planView(p, extra = {}) {
  let opts = [];
  try { opts = JSON.parse(p.daily_options || '[]'); } catch {}
  return {
    id: p.id, name: p.name, category: p.category, description: p.description || '',
    imageKey: p.image_key, imageUrl: p.image_url, totalCents: p.total_cents, minPaymentCents: p.min_payment_cents,
    dailyOptions: opts, allowCustom: bool(p.allow_custom), period: p.period, allowAdvance: bool(p.allow_advance),
    allowMultiple: bool(p.allow_multiple), allowEarlyPayoff: bool(p.allow_early_payoff), featured: bool(p.featured),
    active: bool(p.active), sortOrder: p.sort_order, payoffEnabled: bool(p.payoff_enabled), acceptsBenefit: bool(p.accepts_benefit),
    createdAt: p.created_at, updatedAt: p.updated_at, ...extra,
  };
}

function periodMs(period) { return (PERIODS[period] || PERIODS.daily).days * 86400000; }

/** Visão de uma contratação, com regras de pagamento calculadas pelo servidor. */
export function subscriptionView(s, { pendingCents = 0, at = new Date() } = {}) {
  const total = s.total_cents, paid = s.paid_cents, remaining = total - paid;
  const daily = s.daily_cents;
  const totalPeriods = Math.ceil(total / daily);
  const paidPeriods = Math.floor(paid / daily);
  const percent = Math.floor((paid * 100) / total);
  const allowMultiple = bool(s.allow_multiple), allowAdvance = bool(s.allow_advance);
  let dueNow = 0, upcoming = [];
  if (s.status === 'awaiting_first_payment') {
    dueNow = s.first_payment_cents;
  } else if (s.status === 'active' && s.activated_at) {
    const pm = periodMs(s.period);
    const start = new Date(s.activated_at).getTime();
    const elapsed = Math.max(0, Math.floor((at.getTime() - start) / pm));
    // parcela 1 foi paga na ativação; a parcela k vence em start + (k-1)*período
    const expected = Math.min(total, (elapsed + 1) * daily);
    dueNow = Math.max(0, expected - paid);
    let covered = paid;
    for (let k = 1; k <= totalPeriods && upcoming.length < 5; k++) {
      const endOfK = Math.min(total, k * daily);
      if (endOfK <= covered) continue;
      const amount = endOfK - Math.max(covered, (k - 1) * daily);
      covered = endOfK;
      const date = new Date(start + (k - 1) * pm);
      upcoming.push({ date: date.toISOString(), amountCents: amount, overdue: date.getTime() + pm < at.getTime() });
    }
  }
  const room = Math.max(0, remaining - pendingCents);
  let minPay = Math.min(daily, remaining);
  let maxPay;
  if (s.status === 'awaiting_first_payment') {
    minPay = s.first_payment_cents;
    maxPay = allowMultiple ? room : Math.min(room, s.first_payment_cents);
  } else if (!allowMultiple) {
    maxPay = Math.min(room, daily);
  } else if (!allowAdvance) {
    maxPay = Math.min(room, Math.max(dueNow, minPay));
  } else {
    maxPay = room;
  }
  let payReason = null;
  if (OPEN.includes(s.status)) {
    if (room <= 0) payReason = 'Já existe um Pix gerado cobrindo o valor restante. Aguarde a confirmação do banco ou a expiração do código.';
    else if (maxPay < minPay) payReason = `Existe um Pix pendente. O próximo pagamento poderá ser gerado após a confirmação ou expiração dele.`;
  }
  return {
    id: s.id, userId: s.user_id, planId: s.plan_id, planName: s.plan_name, planCategory: s.plan_category,
    period: s.period, periodLabel: (PERIODS[s.period] || PERIODS.daily).per,
    status: s.status, totalCents: total, listTotalCents: s.list_total_cents, paidCents: paid, remainingCents: remaining,
    percent, periodCents: daily, dailyCents: daily, totalPeriods, paidPeriods,
    firstPaymentCents: s.first_payment_cents, firstPaymentDueAt: s.first_payment_due_at,
    minPayCents: minPay, maxPayCents: maxPay, dueNowCents: dueNow, payReason,
    allowMultiple, allowAdvance, upcoming, carriedCents: 0, benefitCents: 0, loyaltyBenefitCents: 0,
    createdAt: s.created_at, activatedAt: s.activated_at, completedAt: s.completed_at,
    cancelledAt: s.cancelled_at, cancelReason: s.cancel_reason, termsVersion: s.terms_version,
  };
}

export async function pendingCentsFor(q, subscriptionId) {
  const r = await q.query(
    `SELECT COALESCE(SUM(amount_cents),0) AS c FROM payments WHERE subscription_id=$1 AND status='pending' AND (expires_at IS NULL OR expires_at > $2)`,
    [subscriptionId, now()],
  );
  return Number(r[0].c);
}

export function paymentView(p) {
  return {
    id: p.id, subscriptionId: p.subscription_id, userId: p.user_id, amountCents: p.amount_cents, chargesCents: 0,
    status: p.status, qrCode: p.status === 'pending' ? p.qr_code : null,
    qrCodeBase64: p.status === 'pending' ? p.qr_code_base64 : null, ticketUrl: p.status === 'pending' ? p.ticket_url : null,
    expiresAt: p.expires_at, paidAt: p.paid_at, createdAt: p.created_at, providerId: p.provider_payment_id,
    providerStatus: p.provider_status, reconciliationNote: p.reconciliation_note,
  };
}

// ---------- Termos de contratação ----------
export async function buildTerms(plan, dailyCents) {
  const version = String(await getSetting('termsVersion'));
  const clauses = String(await getSetting('contractClauses') || '').trim();
  const per = PERIODS[plan.period] || PERIODS.daily;
  const periods = Math.ceil(plan.total_cents / dailyCents);
  const brl = (c) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const conditions = {
    kind: 'plan', planName: plan.name, totalCents: plan.total_cents, paymentMethod: 'Pix',
    periodicity: per.label, periodsLabel: `${periods} × ${brl(dailyCents)}`,
  };
  const lines = [
    `CONTRATO DE CRÉDITO PROGRAMADO — IVASLOVCK TATTOO CLUB (versão ${version})`, '',
    `Plano: ${plan.name}`, `Valor total: ${brl(plan.total_cents)}`, `Forma de pagamento: Pix`,
    `Periodicidade: ${per.label}`, `Contribuição: ${brl(dailyCents)} ${per.per} (${periods} períodos)`, '',
    'O crédito é liberado somente após a quitação total do plano. Pagamentos parciais não geram crédito para utilização.',
    'A contratação aguarda a confirmação do primeiro Pix; sem o pagamento no prazo, ela é cancelada automaticamente.',
  ];
  if (clauses) lines.push('', clauses);
  const contractText = lines.join('\n');
  const contractHash = crypto.createHash('sha256').update(contractText).digest('hex');
  const sections = [];
  if (clauses) sections.push({ title: 'Cláusulas do estúdio', lines: clauses.split('\n').filter(Boolean) });
  sections.push({ title: '7. Utilização dos créditos', lines: ['O crédito é liberado somente após a quitação total do plano.'] });
  return {
    termsVersion: version, contractHash, contractText, conditions, sections,
    summary: { cancellation: [], consumerRights: [] },
    acceptanceText: `Li e concordo com o contrato (versão ${version}) e com as condições acima.`,
    configured: !!clauses,
  };
}

// ---------- Contratação ----------
export async function createSubscription(user, { planId, dailyCents, acceptTerms, termsVersion, contractHash }) {
  const plans = await db().query('SELECT * FROM plans WHERE id=$1', [planId]);
  const plan = plans[0];
  if (!plan || !bool(plan.active)) throw notFound('Plano não encontrado ou indisponível.');
  dailyCents = Number(dailyCents);
  if (!Number.isInteger(dailyCents) || dailyCents <= 0) throw bad('Escolha o valor da contribuição.');
  const opts = JSON.parse(plan.daily_options || '[]');
  if (!opts.includes(dailyCents) && !bool(plan.allow_custom)) throw bad('Valor de contribuição não permitido neste plano.');
  if (dailyCents < plan.min_payment_cents) throw bad('Valor abaixo do pagamento mínimo do plano.');
  if (dailyCents > plan.total_cents) throw bad('O valor não pode ser maior que o total do plano.');
  if (!acceptTerms) throw bad('Para contratar, aceite os termos e políticas.');
  const terms = await buildTerms(plan, dailyCents);
  if (termsVersion !== terms.termsVersion || contractHash !== terms.contractHash) {
    throw conflict('Os termos foram atualizados. Revise o contrato novamente antes de contratar.');
  }
  const hours = Number(await getSetting('firstPaymentHours')) || 24;
  return db().tx(async (t) => {
    const open = await t.query(`SELECT id FROM subscriptions WHERE user_id=$1 AND status IN ('awaiting_first_payment','active')`, [user.id]);
    if (open.length) throw conflict('Você já possui um plano em andamento ou aguardando pagamento.');
    const w = await wallet.getWallet(t, user.id);
    if (w.plan_cents > 0) throw conflict('Você ainda possui crédito disponível. Utilize todo o saldo antes de contratar um novo plano.');
    const ts = now();
    const rows = await t.query(
      `INSERT INTO subscriptions (user_id, plan_id, plan_name, plan_category, period, total_cents, list_total_cents, daily_cents,
        min_payment_cents, allow_multiple, allow_advance, status, paid_cents, first_payment_cents, first_payment_due_at,
        terms_version, contract_hash, contract_text, accepted_at, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'awaiting_first_payment',0,$12,$13,$14,$15,$16,$17,$17,$17) RETURNING *`,
      [user.id, plan.id, plan.name, plan.category, plan.period, plan.total_cents, plan.total_cents, dailyCents,
        plan.min_payment_cents, bool(plan.allow_multiple), bool(plan.allow_advance), Math.min(dailyCents, plan.total_cents),
        new Date(Date.now() + hours * 3600000).toISOString(), terms.termsVersion, terms.contractHash, terms.contractText, ts],
    );
    await audit(t, 'subscription_created', `Contratação do plano ${plan.name}`, { userId: user.id, actorId: user.id, amountCents: plan.total_cents, meta: { subscriptionId: rows[0].id, contractHash: terms.contractHash } });
    return rows[0];
  });
}

export async function cancelSubscriptionByClient(user, id) {
  return db().tx(async (t) => {
    const rows = await t.query('SELECT * FROM subscriptions WHERE id=$1 AND user_id=$2 FOR UPDATE', [id, user.id]);
    const s = rows[0];
    if (!s) throw notFound();
    if (s.status !== 'awaiting_first_payment' || s.paid_cents > 0) {
      throw conflict('Somente contratações que ainda aguardam o primeiro pagamento podem ser canceladas pelo app. Fale com o estúdio.');
    }
    await t.query(`UPDATE subscriptions SET status='cancelled', cancelled_at=$1, cancel_reason=$2, updated_at=$1 WHERE id=$3`, [now(), 'Cancelada pelo cliente', id]);
    await audit(t, 'subscription_cancelled', `Contratação #${id} cancelada pelo cliente`, { userId: user.id, actorId: user.id });
  });
}

// ---------- Cobranças Pix ----------
export async function createPayment(user, { subscriptionId, amountCents, idempotencyKey }) {
  amountCents = Number(amountCents);
  if (!Number.isInteger(amountCents) || amountCents <= 0) throw bad('Informe o valor do pagamento.');
  if (!idempotencyKey || String(idempotencyKey).length > 100) throw bad('Requisição inválida (chave de idempotência).');
  await expireDue();
  // 1) Reserva local (transação): valida regras e cria o registro "pending" antes de chamar o provedor.
  const reservation = await db().tx(async (t) => {
    const dup = await t.query('SELECT * FROM payments WHERE user_id=$1 AND idempotency_key=$2', [user.id, idempotencyKey]);
    if (dup.length) return { payment: dup[0], duplicate: true };
    const rows = await t.query('SELECT * FROM subscriptions WHERE id=$1 AND user_id=$2 FOR UPDATE', [subscriptionId, user.id]);
    const s = rows[0];
    if (!s) throw notFound('Plano não encontrado.');
    if (!OPEN.includes(s.status)) throw conflict('Este plano não está disponível para pagamento.');
    const view = subscriptionView(s, { pendingCents: await pendingCentsFor(t, s.id) });
    if (view.payReason) throw conflict(view.payReason);
    if (amountCents < view.minPayCents) throw bad(`O valor mínimo é R$ ${(view.minPayCents / 100).toFixed(2).replace('.', ',')}.`);
    if (amountCents > view.maxPayCents) throw bad(`O valor máximo permitido agora é R$ ${(view.maxPayCents / 100).toFixed(2).replace('.', ',')}.`);
    const minutes = Number(await getSetting('pixExpirationMinutes')) || 30;
    const ins = await t.query(
      `INSERT INTO payments (user_id, subscription_id, amount_cents, status, idempotency_key, expires_at, created_at, updated_at)
       VALUES ($1,$2,$3,'pending',$4,$5,$6,$6) RETURNING *`,
      [user.id, s.id, amountCents, idempotencyKey, new Date(Date.now() + minutes * 60000).toISOString(), now()],
    );
    return { payment: ins[0], sub: s, duplicate: false };
  });
  if (reservation.duplicate && (reservation.payment.provider_payment_id || reservation.payment.status !== 'pending')) return reservation.payment;
  const p = reservation.payment;
  const sub = reservation.sub || (await db().query('SELECT * FROM subscriptions WHERE id=$1', [p.subscription_id]))[0];
  // 2) Cria o Pix no Mercado Pago (idempotência do provedor = id interno do pagamento).
  let mpPay;
  try {
    mpPay = await mp.createPixPayment({
      amountCents: p.amount_cents,
      description: `IVASLOVCK Tattoo Club · ${sub.plan_name}`,
      payerEmail: user.email || `cliente${user.id}@ivaslovck.invalid`,
      payerName: user.name,
      externalReference: `ivs-payment-${p.id}`,
      expiresAt: p.expires_at,
      idempotencyKey: `ivs-payment-${p.id}`,
    });
  } catch (e) {
    await db().query(`UPDATE payments SET status='cancelled', provider_status=$1, updated_at=$2 WHERE id=$3 AND status='pending' AND provider_payment_id IS NULL`, ['create_failed', now(), p.id]);
    throw e;
  }
  const pix = mp.pixData(mpPay);
  await db().query(
    `UPDATE payments SET provider_payment_id=$1, qr_code=$2, qr_code_base64=$3, ticket_url=$4, provider_status=$5, provider_status_detail=$6, updated_at=$7 WHERE id=$8`,
    [String(mpPay.id), pix.qrCode, pix.qrCodeBase64, pix.ticketUrl, mpPay.status, mpPay.status_detail || null, now(), p.id],
  );
  await audit(db(), 'payment_created', `Pix gerado para ${sub.plan_name}`, { userId: user.id, actorId: user.id, amountCents: p.amount_cents, meta: { paymentId: p.id, providerId: String(mpPay.id) } });
  return (await db().query('SELECT * FROM payments WHERE id=$1', [p.id]))[0];
}

const MP_FINAL = { approved: 'approved', rejected: 'rejected', cancelled: 'cancelled', refunded: 'refunded', charged_back: 'refunded' };

/**
 * Consulta o pagamento no Mercado Pago e aplica o resultado. Idempotente: pode ser chamado
 * quantas vezes for (webhooks repetidos, sincronização manual, polling) sem duplicar crédito.
 */
export async function syncPaymentFromProvider(providerId, { actorId = null, source = 'webhook' } = {}) {
  const mpPay = await mp.getPayment(providerId);
  const ref = String(mpPay.external_reference || '');
  const m = /^ivs-payment-(\d+)$/.exec(ref);
  if (!m) return { ignored: true, reason: 'external_reference desconhecida' };
  return applyProviderState(Number(m[1]), mpPay, { actorId, source });
}

export async function applyProviderState(paymentId, mpPay, { actorId = null, source } = {}) {
  return db().tx(async (t) => {
    const rows = await t.query('SELECT * FROM payments WHERE id=$1 FOR UPDATE', [paymentId]);
    const p = rows[0];
    if (!p) return { ignored: true, reason: 'pagamento interno inexistente' };
    if (p.provider_payment_id && String(p.provider_payment_id) !== String(mpPay.id)) {
      await audit(t, 'payment_mismatch', `ID do provedor divergente no pagamento #${p.id}`, { userId: p.user_id, meta: { expected: p.provider_payment_id, got: String(mpPay.id) } });
      return { ignored: true, reason: 'id divergente' };
    }
    const providerCents = Math.round(Number(mpPay.transaction_amount) * 100);
    await t.query('UPDATE payments SET provider_status=$1, provider_status_detail=$2, provider_amount_cents=$3, updated_at=$4 WHERE id=$5',
      [mpPay.status, mpPay.status_detail || null, providerCents, now(), p.id]);
    const target = MP_FINAL[mpPay.status];
    if (!target) return { status: p.status, unchanged: true };
    if (target !== 'approved') {
      if (p.status === 'pending') {
        await t.query('UPDATE payments SET status=$1, updated_at=$2 WHERE id=$3', [target, now(), p.id]);
        await audit(t, `payment_${target}`, `Pix #${p.id} ${target === 'rejected' ? 'recusado' : target === 'cancelled' ? 'cancelado' : 'estornado'} pelo provedor`, { userId: p.user_id, amountCents: p.amount_cents });
      } else if (p.applied && target === 'refunded') {
        // Estorno após crédito: NÃO alteramos saldos automaticamente; fica registrado para tratamento manual auditável.
        await audit(t, 'payment_refunded_after_credit', `Pix #${p.id} estornado no provedor após ter sido aplicado. Requer análise.`, { userId: p.user_id, amountCents: p.amount_cents });
        await notify(t, p.user_id, 'Estorno de Pix em análise', null, null, 'payment_refund', 'admin');
      }
      return { status: target };
    }
    // ---------- aprovado ----------
    if (p.applied || ['approved', 'reconciliation', 'reconciled'].includes(p.status)) return { status: p.status, duplicate: true };
    const paidAt = mpPay.date_approved || now();
    if (providerCents !== p.amount_cents) {
      await t.query(`UPDATE payments SET status='reconciliation', paid_at=$1, applied=$2, updated_at=$3 WHERE id=$4`, [paidAt, true, now(), p.id]);
      await audit(t, 'payment_mismatch', `Valor pago (${providerCents}) difere do cobrado (${p.amount_cents}) no Pix #${p.id}. Encaminhado para conciliação.`, { userId: p.user_id, amountCents: providerCents });
      return { status: 'reconciliation' };
    }
    const subs = await t.query('SELECT * FROM subscriptions WHERE id=$1 FOR UPDATE', [p.subscription_id]);
    const s = subs[0];
    if (!OPEN.includes(s.status) || s.paid_cents + p.amount_cents > s.total_cents) {
      await t.query(`UPDATE payments SET status='reconciliation', paid_at=$1, applied=$2, updated_at=$3 WHERE id=$4`, [paidAt, true, now(), p.id]);
      await audit(t, 'payment_reconciliation', `Pix #${p.id} pago com a contratação ${s.status === 'active' ? 'já coberta' : 'encerrada'}. Encaminhado para conciliação.`, { userId: p.user_id, amountCents: p.amount_cents });
      await notify(t, p.user_id, 'Pix recebido para conciliação', `Pix #${p.id}`, '/admin/pagamentos?status=reconciliation', 'payment_reconciliation', 'admin');
      return { status: 'reconciliation' };
    }
    await t.query(`UPDATE payments SET status='approved', paid_at=$1, applied=$2, updated_at=$3 WHERE id=$4`, [paidAt, true, now(), p.id]);
    const newPaid = s.paid_cents + p.amount_cents;
    const ts = now();
    let status = s.status === 'awaiting_first_payment' ? 'active' : s.status;
    const activatedAt = s.activated_at || ts;
    let completedAt = null;
    if (newPaid === s.total_cents) { status = 'completed'; completedAt = ts; }
    await t.query('UPDATE subscriptions SET paid_cents=$1, status=$2, activated_at=$3, completed_at=$4, updated_at=$5 WHERE id=$6',
      [newPaid, status, activatedAt, completedAt, ts, s.id]);
    await audit(t, 'payment_approved', `Pix #${p.id} confirmado (${s.plan_name}) via ${source}`, { userId: p.user_id, actorId, amountCents: p.amount_cents, meta: { providerId: String(mpPay.id) } });
    await notify(t, p.user_id, 'Pagamento confirmado', `Recebemos seu Pix de R$ ${(p.amount_cents / 100).toFixed(2).replace('.', ',')}.`, `/meus-planos/${s.id}`, 'payment_approved');
    if (status === 'completed') {
      const r = await wallet.credit(t, {
        userId: s.user_id, amountCents: s.total_cents, bucket: 'plan', kind: 'plan_release',
        refType: 'subscription', refId: s.id, key: `release:subscription:${s.id}`, description: `Crédito liberado · ${s.plan_name}`,
      });
      if (!r.duplicate) {
        await t.query('INSERT INTO credit_releases (user_id, subscription_id, amount_cents, ledger_id, created_at) VALUES ($1,$2,$3,$4,$5)',
          [s.user_id, s.id, s.total_cents, r.entries[0].id, ts]);
        await audit(t, 'credit_released', `Crédito de ${s.plan_name} liberado`, { userId: s.user_id, amountCents: s.total_cents });
        await audit(t, 'subscription_completed', `Plano ${s.plan_name} quitado`, { userId: s.user_id, amountCents: s.total_cents });
        await notify(t, s.user_id, 'Plano quitado! Crédito liberado', `Seu crédito de R$ ${(s.total_cents / 100).toFixed(2).replace('.', ',')} já pode ser usado no estúdio.`, '/meu-credito', 'credit_released');
      }
    }
    return { status: 'approved', subscriptionStatus: status };
  });
}

// ---------- Rotinas de expiração ----------
let lastExpire = 0;
export async function expireDue(force = false) {
  if (!force && Date.now() - lastExpire < 15000) return;
  lastExpire = Date.now();
  const ts = now();
  // Pix vencidos: antes de marcar como expirado, consulta o provedor (o cliente pode ter pago no último minuto).
  const stale = await db().query(`SELECT * FROM payments WHERE status='pending' AND expires_at < $1`, [new Date(Date.now() - 5 * 60000).toISOString()]);
  for (const p of stale) {
    if (p.provider_payment_id) {
      try {
        const r = await syncPaymentFromProvider(p.provider_payment_id, { source: 'expiração' });
        if (r.status && r.status !== 'pending' && !r.unchanged) continue;
      } catch { continue; } // provedor fora do ar: tenta de novo na próxima rodada
    }
    await db().query(`UPDATE payments SET status='expired', updated_at=$1 WHERE id=$2 AND status='pending'`, [ts, p.id]);
  }
  // Contratações sem primeiro pagamento no prazo (sem Pix pendente válido) -> cancelled_unpaid
  const subs = await db().query(`SELECT * FROM subscriptions WHERE status='awaiting_first_payment' AND first_payment_due_at < $1`, [ts]);
  for (const s of subs) {
    await db().tx(async (t) => {
      const cur = (await t.query('SELECT * FROM subscriptions WHERE id=$1 FOR UPDATE', [s.id]))[0];
      if (cur.status !== 'awaiting_first_payment') return;
      const pend = await t.query(`SELECT id FROM payments WHERE subscription_id=$1 AND status='pending'`, [s.id]);
      if (pend.length) return; // aguarda o desfecho do Pix pendente
      await t.query(`UPDATE subscriptions SET status='cancelled_unpaid', cancelled_at=$1, cancel_reason=$2, updated_at=$1 WHERE id=$3`,
        [ts, 'Primeira parcela não paga no prazo', s.id]);
      await audit(t, 'subscription_cancelled_unpaid', `Contratação #${s.id} (${s.plan_name}) cancelada por falta de pagamento`, { userId: s.user_id });
    });
  }
}

export async function reconcilePayment(admin, id, note) {
  if (!note || !String(note).trim()) throw bad('Descreva como o valor foi resolvido.');
  return db().tx(async (t) => {
    const p = (await t.query('SELECT * FROM payments WHERE id=$1 FOR UPDATE', [id]))[0];
    if (!p) throw notFound();
    if (p.status !== 'reconciliation') throw conflict('Este pagamento não está em conciliação.');
    await t.query(`UPDATE payments SET status='reconciled', reconciliation_note=$1, reconciled_at=$2, reconciled_by=$3, updated_at=$2 WHERE id=$4`,
      [String(note).slice(0, 500), now(), admin.id, id]);
    await audit(t, 'payment_reconciled', `Conciliação do Pix #${id}: ${String(note).slice(0, 200)}`, { userId: p.user_id, actorId: admin.id, amountCents: p.amount_cents });
  });
}

export { HttpError };
