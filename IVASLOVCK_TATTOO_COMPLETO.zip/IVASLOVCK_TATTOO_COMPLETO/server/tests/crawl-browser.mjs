// Percorre as telas do app e do painel com dados reais e registra erros de JavaScript (telas que travam).
import fs from 'node:fs';
import path from 'node:path';
import { startFakeMp, Client, tmpDbPath, uuid } from './helpers.js';

const outDir = process.argv[2] || '/tmp/crawl';
fs.mkdirSync(outDir, { recursive: true });
const fake = await startFakeMp();
const dbPath = tmpDbPath();
Object.assign(process.env, {
  DATABASE_URL: '', SQLITE_PATH: dbPath, MP_API_BASE: fake.url, MP_ACCESS_TOKEN: 'TEST-fake-token-1234567890abcdef',
  ADMIN_SETUP_TOKEN: 'setup', APP_SECRET: 'y'.repeat(40), UPLOADS_DIR: dbPath + '-up', PORT: '4322', HOST: '127.0.0.1', APP_URL: 'http://127.0.0.1:4322',
});
const { start } = await import('../src/index.js');
await start();
const base = 'http://127.0.0.1:4322';

// ---- dados: admin, plano, cliente com plano quitado, resgate, moedas, cartão
const admin = new Client(base);
await admin.post('/api/auth/admin-setup', { name: 'Dono Estudio', whatsapp: '11911112222', email: 'dono@estudio.com', password: 'adminpass', setupToken: 'setup' });
const plan = (await admin.post('/api/admin/plans', { name: 'Plano Teste', category: 'tatuagem', totalCents: 10000, minPaymentCents: 5000, dailyOptions: [5000], period: 'weekly', allowAdvance: true, allowMultiple: true, active: true, featured: true })).data.plan;
const cli = new Client(base);
const u = (await cli.post('/api/auth/register', { name: 'Cliente Varredura', whatsapp: '11977776666', email: 'v@teste.com', password: 'segredo1' })).data.user;
const t = (await cli.post('/api/policies/preview', { planId: plan.id, dailyCents: 5000 })).data;
const sub = (await cli.post('/api/me/subscriptions', { planId: plan.id, dailyCents: 5000, acceptTerms: true, termsVersion: t.termsVersion, contractHash: t.contractHash })).data.subscription;
const pay = (await cli.post('/api/me/payments', { subscriptionId: sub.id, amountCents: 10000, expectedChargesCents: 0, idempotencyKey: uuid() })).data.payment;
fake.approve(pay.providerId);
await admin.post(`/api/admin/payments/${pay.id}/sync`);
await admin.post('/api/coins/admin/grant', { userId: u.id, amount: 300, note: 'teste', idempotencyKey: uuid() });
const models = (await admin.get('/api/admin/card-models')).data.models;
const card = await admin.post('/api/admin/cards', { userId: u.id, modelId: models[0].id, validityMonths: 36 });
await admin.post(`/api/admin/clients/${u.id}/redemptions`, { amountCents: 2000, description: 'Sessão teste' });
const cards = (await cli.get('/api/me/cards')).data.cards;

const { chromium } = await import('/opt/npm-tools/node_modules/playwright/index.mjs');
const browser = await chromium.launch();
async function login(page, login, pw, adminLogin) {
  await page.goto(base + (adminLogin ? '/admin/entrar' : '/entrar'), { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);
  const pwd = page.locator('input[type="password"]').first();
  const userInput = page.locator('input:not([type="password"]):not([type="checkbox"])').first();
  await userInput.fill(login);
  await pwd.fill(pw);
  await page.locator('button[type="submit"]').first().click();
  await page.waitForTimeout(2500);
}
const results = [];
async function crawl(page, routes, prefix) {
  for (const r of routes) {
    const errs = [];
    const h = (e) => errs.push(e.message);
    const hc = (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); };
    page.on('pageerror', h);
    page.on('console', hc);
    await page.goto(base + r, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2200);
    page.off('pageerror', h);
    page.off('console', hc);
    const text = (await page.textContent('#root').catch(() => '')) || '';
    const name = `${prefix}${r.replace(/[\/?=&:]+/g, '_')}`;
    await page.screenshot({ path: path.join(outDir, `${name}.png`) });
    const notRebuilt = /ainda não foi reconstruído/.test(text);
    results.push({ route: r, crash: errs.length > 0, blank: text.trim().length < 20, notRebuilt, errors: errs.slice(0, 2) });
    console.log(errs.length && text.trim().length < 20 ? 'TRAVA ' : errs.length ? 'AVISO ' : text.trim().length < 20 ? 'VAZIA ' : notRebuilt ? '501   ' : 'OK    ', r, errs[0] ? errs[0].slice(0, 120) : '');
  }
}
const cp = await browser.newPage({ viewport: { width: 400, height: 860 } });
await login(cp, 'v@teste.com', 'segredo1');
await crawl(cp, ['/inicio', '/planos', `/planos/${plan.id}`, `/planos/${plan.id}/revisar?diario=5000`, '/meus-planos', `/meus-planos/${sub.id}`, '/pagar',
  `/pagar?assinatura=${sub.id}&pagamento=${pay.id}`, '/historico', '/meu-credito', '/creditos', `/creditos/cartoes/${cards[0]?.id}`, '/ivt-coin', '/ivt-coin/converter',
  '/ivt-coin/ganhar', '/perfil', '/perfil/dados', '/perfil/avatar', '/perfil/notificacoes', '/notificacoes', '/suporte', '/meus-contratos', '/termos', '/privacidade',
  '/indique', '/sorteios', '/ivt-market', '/ivt-pay', '/presentear', '/parcelamentos', '/upgrades', '/liberacao-antecipada', '/limite-de-confianca'], 'cli');
const ap = await browser.newPage({ viewport: { width: 1280, height: 900 } });
await login(ap, 'dono@estudio.com', 'adminpass', true);
await crawl(ap, ['/admin', '/admin/clientes', `/admin/clientes/${u.id}`, '/admin/planos', `/admin/planos/${plan.id}`, '/admin/planos/novo', '/admin/pagamentos',
  '/admin/resgates', '/admin/historico', '/admin/configuracoes', '/admin/cartoes', '/admin/ivt-coin', '/admin/ivt-coin?aba=movimentacoes', '/admin/notificacoes',
  '/admin/credito', '/admin/sorteios', '/admin/indicacoes', '/admin/ivt-market', '/admin/atendimentos', '/admin/cartoes-presente', '/admin/multas-e-juros', '/admin/politicas'], 'adm');
fs.writeFileSync(path.join(outDir, 'crawl.json'), JSON.stringify(results, null, 1));
await browser.close();
await fake.close();
process.exit(0);
