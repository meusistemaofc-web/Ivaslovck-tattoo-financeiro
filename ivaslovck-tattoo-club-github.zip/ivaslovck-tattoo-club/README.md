# IVASLOVCK Tattoo Club

Plataforma de crédito programado para tatuagem e piercing, com painel administrativo. Versão independente da Netlify: o backend roda em Node.js com PostgreSQL, e o frontend original é servido pelo próprio backend.

## O que está funcionando

| Área | Situação |
|---|---|
| Cadastro, login, logout, sessão, primeiro administrador | Pronto e testado |
| Planos, contratação, termo com hash, **Meus contratos** | Pronto e testado |
| Pix (Mercado Pago), webhook, conciliação, carteira, extrato | Pronto e testado |
| Resgates (uso do crédito), cartões BLACK/GOLD/SILVER | Pronto e testado |
| IVT COIN (núcleo), perfil, avatares, notificações | Pronto e testado |
| **Indicações** (link, validação, antifraude, campanhas, painel admin) | Pronto e testado |
| **Cartão Presente** (compra, Pix, link único, resgate, painel admin) | Pronto e testado |
| **Mensagem de divulgação**, **Canais oficiais e agendamento** | Pronto e testado |
| Cobrança Pix genérica (`/cobranca/:id`) | Pronto (base para parcelas, upgrade e taxas) |
| Sorteios, Marketplace, IVT PAY, Limite de confiança, Parcelamento, Upgrade, Multas, Liberação antecipada, Quitação especial, Suporte, Push, Identidade, Landing pages | **Não reconstruídos.** A rota responde HTTP 501 com aviso claro. Nada é simulado. |

Detalhes e limitações: [`FINAL_AUDITORIA.md`](FINAL_AUDITORIA.md).

## Tecnologias

- Node.js 22.5 ou superior (ESM, sem framework), PostgreSQL 16 em produção.
- SQLite embutido do Node (`node:sqlite`) apenas para desenvolvimento e testes.
- Frontend original em React/Vite, **somente compilado** (pasta `public/`).
- Docker, Docker Compose, Nginx e Certbot para a implantação.

## Estrutura

```
public/          Frontend original compilado (identidade visual preservada)
server/
  src/           Código: rotas, serviços financeiros, migrações SQL
  tests/         Testes automáticos (25) e testes de navegador
  scripts/       integrity (conferência de saldos), set-contract (cláusulas) e reset-password (senha de cliente)
deploy/          Nginx e scripts: instalar, atualizar, backup, restaurar
docs/            Relatórios e guias complementares
legacy/          netlify.toml original (referência)
.github/         CI: testes em SQLite, em PostgreSQL e build da imagem Docker
Dockerfile, docker-compose.yml, .env.example
DEPLOY_HOSTINGER.md   Guia completo de implantação
PUBLICAR_GITHUB.md    Como enviar este projeto ao GitHub
FINAL_AUDITORIA.md    Problemas, correções, arquivos e testes
```

## Requisitos

- Node.js 22.5+ (para desenvolvimento e testes).
- Docker e Docker Compose (para produção).
- Conta do Mercado Pago com Access Token (para cobrar Pix).

## Desenvolvimento local

```bash
cd server
npm install
APP_SECRET=$(openssl rand -hex 32) ADMIN_SETUP_TOKEN=dev COOKIE_SECURE=false npm run dev
```

Abra http://localhost:3000. Sem `DATABASE_URL`, o servidor usa SQLite local (`server/data/`). Crie o primeiro administrador em `/admin/entrar`, na aba “Configuração inicial”, com o código definido em `ADMIN_SETUP_TOKEN`.

## Testes

```bash
cd server
npm test                                  # SQLite temporário
TEST_DATABASE_URL=postgres://usuario:senha@localhost:5432/ivaslovck_test npm run test:pg
```

O teste em PostgreSQL **apaga todo o schema do banco informado** e só roda se o nome do banco contiver `test`. Nunca aponte para o banco de produção.

## Variáveis de ambiente

Copie `.env.example` para `.env` e preencha. O arquivo `.env` nunca vai para o GitHub.

| Variável | Para que serve |
|---|---|
| `APP_URL` | Endereço público com `https://`. Usado em links e no webhook do Mercado Pago. |
| `APP_SECRET` | Segredo (mín. 32 caracteres) que cifra dados sensíveis no banco. Gere com `openssl rand -hex 32`. **Se perdê-lo, os dados cifrados ficam ilegíveis.** |
| `ADMIN_SETUP_TOKEN` | Código para criar o primeiro administrador. Apague depois de usar. |
| `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` | Banco do `docker-compose`. |
| `DATABASE_URL` | Conexão PostgreSQL. No Docker é montada sozinha. |
| `MP_ACCESS_TOKEN`, `MP_WEBHOOK_SECRET` | Mercado Pago. Também podem ser cadastrados no painel. |
| `APP_PORT` | Porta publicada em 127.0.0.1 (padrão 3000). |
| `COOKIE_SECURE`, `TRUST_PROXY`, `SESSION_DAYS`, `JOBS_INTERVAL_MS` | Ajustes opcionais de sessão e rotinas. |

## Banco de dados

As migrações ficam em `server/src/migrations/` (`001_init`, `002_referrals`, `003_charges_gifts`) e rodam sozinhas na inicialização, uma única vez cada. Cada atualização em produção faz backup antes (`deploy/scripts/atualizar.sh`). Os valores em centavos têm proteção contra saldo negativo no próprio banco.

## Implantação

Siga [`DEPLOY_HOSTINGER.md`](DEPLOY_HOSTINGER.md). Para publicar o código, siga [`PUBLICAR_GITHUB.md`](PUBLICAR_GITHUB.md).

## Limitações importantes

- O **código-fonte do frontend não existe neste repositório**: só a versão compilada. Mudanças visuais exigem o projeto Vite original.
- Os módulos listados como não reconstruídos respondem 501.
- Os dados reais do sistema antigo (clientes, saldos, pagamentos) não faziam parte do material recebido.
