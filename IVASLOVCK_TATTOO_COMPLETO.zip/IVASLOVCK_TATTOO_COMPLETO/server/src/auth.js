import crypto from 'node:crypto';
import { promisify } from 'node:util';
import { db } from './db.js';
import { config } from './config.js';
import { HttpError, forbidden } from './http.js';

const scrypt = promisify(crypto.scrypt);
export const SESSION_COOKIE = 'ivs_session';

export async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$16384$8$1$${salt.toString('base64')}$${key.toString('base64')}`;
}

export async function verifyPassword(pw, stored) {
  try {
    const [alg, N, r, p, saltB64, keyB64] = stored.split('$');
    if (alg !== 'scrypt') return false;
    const key = Buffer.from(keyB64, 'base64');
    const test = await scrypt(pw, Buffer.from(saltB64, 'base64'), key.length, { N: +N, r: +r, p: +p });
    return crypto.timingSafeEqual(key, test);
  } catch {
    return false;
  }
}

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

export async function createSession(res, user, req) {
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + config.sessionDays * 86400000);
  await db().query(
    'INSERT INTO sessions (token_hash, user_id, expires_at, ip, user_agent) VALUES ($1,$2,$3,$4,$5)',
    [sha256(token), user.id, expires.toISOString(), req.ip || null, String(req.headers['user-agent'] || '').slice(0, 300)],
  );
  setCookie(res, token, expires);
}

export function setCookie(res, token, expires) {
  const parts = [`${SESSION_COOKIE}=${token}`, 'Path=/', 'HttpOnly', 'SameSite=Lax'];
  if (config.cookieSecure) parts.push('Secure');
  parts.push(expires ? `Expires=${expires.toUTCString()}` : 'Max-Age=0');
  const prev = res.getHeader('Set-Cookie');
  res.setHeader('Set-Cookie', [...(Array.isArray(prev) ? prev : prev ? [prev] : []), parts.join('; ')]);
}

export async function destroySession(req, res) {
  const token = req.cookies[SESSION_COOKIE];
  if (token) await db().query('DELETE FROM sessions WHERE token_hash = $1', [sha256(token)]);
  setCookie(res, '', null);
}

export async function loadUser(req) {
  const token = req.cookies[SESSION_COOKIE];
  if (!token) return null;
  const rows = await db().query(
    `SELECT u.* , s.expires_at AS session_expires FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = $1`,
    [sha256(token)],
  );
  const u = rows[0];
  if (!u) return null;
  if (new Date(u.session_expires) < new Date() || u.status !== 'active') return null;
  return u;
}

export const isAdmin = (u) => u && (u.role === 'admin' || u.role === 'owner');

export function requireUser(req) {
  if (!req.user) throw new HttpError(401, 'Faça login para continuar.');
  return req.user;
}
export function requireClient(req) {
  return requireUser(req);
}
export function requireAdmin(req) {
  const u = requireUser(req);
  if (!isAdmin(u)) throw forbidden('Acesso restrito à administração do estúdio.');
  return u;
}
export function requireOwner(req) {
  const u = requireAdmin(req);
  if (u.role !== 'owner') throw forbidden('Somente o administrador principal pode realizar esta ação.');
  return u;
}

// avatar_key: 'photo' (usa photo_key) | id de avatar da galeria (ex.: avatar_01) | null (iniciais)
export function avatarUrlOf(u) {
  if (u.avatar_key === 'photo' && u.photo_key) return `/uploads/${u.photo_key}`;
  if (u.avatar_key && u.avatar_key !== 'photo') return `/avatars/${u.avatar_key}.webp`;
  return null;
}

export function publicUser(u) {
  if (!u) return null;
  let address = null;
  try { address = u.address ? JSON.parse(u.address) : null; } catch {}
  return {
    id: u.id,
    code: u.code,
    name: u.name,
    email: u.email,
    whatsapp: u.whatsapp,
    role: u.role,
    avatarUrl: avatarUrlOf(u),
    avatarMode: u.avatar_key === 'photo' && u.photo_key ? 'photo' : u.avatar_key && u.avatar_key !== 'photo' ? 'avatar' : 'initials',
    avatarId: u.avatar_key && u.avatar_key !== 'photo' ? u.avatar_key : null,
    hasPhoto: !!u.photo_key,
    address,
    referralCode: u.referral_code,
    createdAt: u.created_at,
  };
}

// Limitador simples em memória contra força bruta no login.
const attempts = new Map();
export function checkRateLimit(key, max = 10, windowMs = 15 * 60000) {
  const now = Date.now();
  const rec = attempts.get(key) || { n: 0, at: now };
  if (now - rec.at > windowMs) { rec.n = 0; rec.at = now; }
  rec.n += 1;
  attempts.set(key, rec);
  if (rec.n > max) throw new HttpError(429, 'Muitas tentativas. Aguarde alguns minutos e tente novamente.');
}
export function resetRateLimit(key) { attempts.delete(key); }
