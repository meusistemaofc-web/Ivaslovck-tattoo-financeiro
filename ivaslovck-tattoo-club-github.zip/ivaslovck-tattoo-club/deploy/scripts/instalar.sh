#!/usr/bin/env bash
# Instalação completa na VPS (Ubuntu 22.04/24.04 da Hostinger). Rode como root, dentro da pasta do projeto:
#   sudo bash deploy/scripts/instalar.sh
set -euo pipefail
cd "$(dirname "$0")/../.."
PROJ="$(pwd)"

read -rp "Domínio (ex.: ivaslovck.com.br, sem https): " DOMINIO
read -rp "E-mail para o certificado HTTPS: " EMAIL
[ -z "$DOMINIO" ] && { echo "Domínio obrigatório."; exit 1; }

# Proteção: este script é para uma VPS NOVA. Em servidor que já hospeda outros projetos ele pode atrapalhá-los
# (firewall, site padrão do Nginx, portas). Nesse caso use o caminho manual do DEPLOY_HOSTINGER.md (seção 4B).
OUTROS_SITES=$(ls /etc/nginx/sites-enabled 2>/dev/null | grep -v '^default$' || true)
CONTAINERS=$(command -v docker >/dev/null 2>&1 && docker ps -q 2>/dev/null || true)
PORTAS=$(ss -ltn 2>/dev/null | grep -E ':(80|443)\s' || true)
if [ -z "${INSTALACAO_FORCADA:-}" ] && { [ -n "$OUTROS_SITES" ] || [ -n "$CONTAINERS" ] || [ -n "$PORTAS" ]; }; then
  echo "ATENÇÃO: este servidor já tem outros serviços (sites Nginx, containers ou portas 80/443 em uso)."
  echo "O instalador automático não será executado para não alterar o que já funciona."
  echo "Siga o caminho manual: DEPLOY_HOSTINGER.md, seção 4B."
  echo "(Se tiver certeza de que o servidor está limpo: INSTALACAO_FORCADA=1 sudo -E bash deploy/scripts/instalar.sh)"
  exit 2
fi

echo "==> Instalando Docker, Nginx e Certbot"
apt-get update -y
apt-get install -y ca-certificates curl nginx certbot python3-certbot-nginx openssl ufw
if ! command -v docker >/dev/null; then curl -fsSL https://get.docker.com | sh; fi

echo "==> Firewall (SSH, HTTP, HTTPS)"
ufw allow OpenSSH >/dev/null; ufw allow 'Nginx Full' >/dev/null; ufw --force enable >/dev/null

if [ ! -f .env ]; then
  echo "==> Gerando .env com segredos aleatórios"
  cp .env.example .env
  SETUP=$(openssl rand -hex 12)
  sed -i "s|^APP_URL=.*|APP_URL=https://$DOMINIO|" .env
  sed -i "s|^APP_SECRET=.*|APP_SECRET=$(openssl rand -hex 32)|" .env
  sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$(openssl rand -hex 24)|" .env
  sed -i "s|^ADMIN_SETUP_TOKEN=.*|ADMIN_SETUP_TOKEN=$SETUP|" .env
  chmod 600 .env
else
  echo "==> .env já existe — mantido sem alterações"
  SETUP=$(grep '^ADMIN_SETUP_TOKEN=' .env | cut -d= -f2)
fi

echo "==> Subindo banco e aplicação"
docker compose up -d --build

echo "==> Configurando Nginx"
PORTA=$(grep '^APP_PORT=' .env | cut -d= -f2); PORTA=${PORTA:-3000}
sed -e "s/SEU_DOMINIO/$DOMINIO/g" -e "s/127.0.0.1:3000/127.0.0.1:$PORTA/" deploy/nginx/ivaslovck.conf > /etc/nginx/sites-available/ivaslovck.conf
ln -sf /etc/nginx/sites-available/ivaslovck.conf /etc/nginx/sites-enabled/ivaslovck.conf
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "==> Certificado HTTPS (o domínio precisa já apontar para este servidor)"
certbot --nginx -d "$DOMINIO" -d "www.$DOMINIO" --non-interactive --agree-tos -m "$EMAIL" --redirect \
  || certbot --nginx -d "$DOMINIO" --non-interactive --agree-tos -m "$EMAIL" --redirect \
  || echo "AVISO: HTTPS não configurado agora. Aponte o DNS e rode: certbot --nginx -d $DOMINIO"

echo "==> Backup diário às 03:30"
( crontab -l 2>/dev/null | grep -v 'deploy/scripts/backup.sh'; echo "30 3 * * * cd $PROJ && bash deploy/scripts/backup.sh >> $PROJ/backups/backup.log 2>&1" ) | crontab -
mkdir -p backups

sleep 5
curl -fsS "http://127.0.0.1:${PORTA:-3000}/api/health" && echo
echo
echo "============================================================"
echo " Pronto! Acesse https://$DOMINIO/admin/entrar"
echo " Chave de configuração do primeiro administrador: $SETUP"
echo " Depois de criar o administrador, apague ADMIN_SETUP_TOKEN no .env"
echo " e rode: docker compose up -d"
echo "============================================================"
