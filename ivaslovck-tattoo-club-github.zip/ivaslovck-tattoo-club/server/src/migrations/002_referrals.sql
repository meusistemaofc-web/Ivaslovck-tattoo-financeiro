-- Programa de indicação: acessos aos links, indicações (uma por indicado) e campanhas de recompensa.
CREATE TABLE referral_visits (
  id BIGSERIAL PRIMARY KEY,
  code TEXT NOT NULL,
  visitor_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (code, visitor_hash)
);

CREATE TABLE referral_campaigns (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  reward_coins BIGINT NOT NULL CHECK (reward_coins > 0),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE referrals (
  id BIGSERIAL PRIMARY KEY,
  referrer_id BIGINT NOT NULL REFERENCES users(id),
  referred_id BIGINT NOT NULL UNIQUE REFERENCES users(id),
  code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'registered' CHECK (status IN ('registered','qualified','review','capped','approved','rejected','expired')),
  reward_coins BIGINT NOT NULL CHECK (reward_coins > 0),
  paid_coins BIGINT NOT NULL DEFAULT 0,
  campaign_id BIGINT REFERENCES referral_campaigns(id),
  campaign_name TEXT,
  flags TEXT NOT NULL DEFAULT '[]',
  signup_ip TEXT,
  qualified_at TIMESTAMPTZ,
  release_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  approved_at TIMESTAMPTZ,
  decided_by BIGINT REFERENCES users(id),
  note TEXT,
  ledger_id BIGINT REFERENCES coin_ledger(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (referrer_id <> referred_id)
);
CREATE INDEX idx_referrals_referrer ON referrals(referrer_id);
CREATE INDEX idx_referrals_status ON referrals(status);
